from tkinter import *
import tkinter as tk
import random
from operator import itemgetter

def thisFunction():
    global qq1, qq2, qq3, qq4, qq5, qq6, qq7, qq8, qq9, qq10, qq11, qq12, qq13, qq14, qq15, qq16, qq17, qq18, qq19, qq20, qq21, qq22, qq23, qq24, qq25, qq26, qq27, qq28
    
    value1 = str(random.randint(0, 27))
    value2 = str(random.randint(0, 27))
    value3 = str(random.randint(0, 27))
    value4 = str(random.randint(0, 27))
    value5 = str(random.randint(0, 27))
    value6 = str(random.randint(0, 27))
    value7 = str(random.randint(0, 27))
    value8 = str(random.randint(0, 27))
    value9 = str(random.randint(0, 27))
    value10 = str(random.randint(0, 27))
    value11 = str(random.randint(0, 27))
    value12 = str(random.randint(0, 27))
    value13 = str(random.randint(0, 27))
    value14 = str(random.randint(0, 27))
    value15 = str(random.randint(0, 27))
    value16 = str(random.randint(0, 27))
    value17 = str(random.randint(0, 27))
    value18 = str(random.randint(0, 27))
    value19 = str(random.randint(0, 27))
    value20 = str(random.randint(0, 27))
    value21 = str(random.randint(0, 27))
    value22 = str(random.randint(0, 27))
    value23 = str(random.randint(0, 27))
    value24 = str(random.randint(0, 27))
    value25 = str(random.randint(0, 27))
    value26 = str(random.randint(0, 27))
    value27 = str(random.randint(0, 27))
    value28 = str(random.randint(0, 27))
    
    image1 = PhotoImage(file="zero-zero.gif", format="GIF")

    image2 = PhotoImage(file="zero-one.gif", format="GIF")

    image3 = PhotoImage(file="zero-two.gif", format="GIF")

    image4 = PhotoImage(file="zero-three.gif", format="GIF")

    image5 = PhotoImage(file="zero-four.gif", format="GIF")

    image6 = PhotoImage(file="zero-five.gif", format="GIF")

    image7 = PhotoImage(file="zero-six.gif", format="GIF")

    image8 = PhotoImage(file="one-one.gif", format="GIF")

    image9 = PhotoImage(file="two-one.gif", format="GIF")

    image10 = PhotoImage(file="three-two.gif", format="GIF")

    image11 = PhotoImage(file="four-one.gif", format="GIF")

    image12 = PhotoImage(file="five-one.gif", format="GIF")

    image13 = PhotoImage(file="six-one.gif", format="GIF")

    image14 = PhotoImage(file="two-two.gif", format="GIF")

    image15 = PhotoImage(file="three-two.gif", format="GIF")

    image16 = PhotoImage(file="four-two.gif", format="GIF")

    image17 = PhotoImage(file="five-two.gif", format="GIF")

    image18 = PhotoImage(file="six-two.gif", format="GIF")

    image19 = PhotoImage(file="three-three.gif", format="GIF")

    image20 = PhotoImage(file="four-three.gif", format="GIF")

    image21 = PhotoImage(file="four-four.gif", format="GIF")

    image22 = PhotoImage(file="six-three.gif", format="GIF")

    image23 = PhotoImage(file="three-one.gif", format="GIF")

    image24 = PhotoImage(file="two-two.gif", format="GIF")

    image25 = PhotoImage(file="five-five.gif", format="GIF")

    image26 = PhotoImage(file="five-three.gif", format="GIF")

    image27 = PhotoImage(file="six-five.gif", format="GIF")

    image28 = PhotoImage(file="six-six.gif", format="GIF")

    aValue = image1
    aValue = Label(App, image=image1)
    aValue.image1 = image1
    bValue = image2
    bValue = Label(App, image=image2)
    bValue.image2 = image2
    cValue = image3
    cValue = Label(App, image=image3)
    cValue.image3 = image3
    dValue = image4
    dValue = Label(App, image=image4)
    dValue.image4 = image4
    eValue = image5
    eValue = Label(App, image=image5)
    eValue.image5 = image5
    fValue = image6
    fValue = Label(App, image=image6)
    fValue.image6 = image6
    gValue = image7
    gValue = Label(App, image=image7)
    gValue.image7 = image7
    hValue = image8
    hValue = Label(App, image=image8)
    hValue.image8 = image8
    iValue = image9
    iValue = Label(App, image=image9)
    iValue.image9 = image9
    jValue = image10
    jValue = Label(App, image=image10)
    jValue.image10 = image10
    kValue = image11
    kValue = Label(App, image=image11)
    kValue.image11 = image11
    lValue = image12
    lValue = Label(App, image=image12)
    lValue.image12 = image12
    mValue = image13
    mValue = Label(App, image=image13)
    mValue.image13 = image13
    nValue = image14
    nValue = Label(App, image=image14)
    nValue.image14 = image14
    oValue = image15
    oValue = Label(App, image=image15)
    oValue.image15 = image15
    pValue = image16
    pValue = Label(App, image=image16)
    pValue.image16 = image16
    qValue = image17
    qValue = Label(App, image=image17)
    qValue.image17 = image17
    rValue = image18
    rValue = Label(App, image=image18)
    rValue.image18 = image18
    sValue = image19
    sValue = Label(App, image=image19)
    sValue.image19 = image19
    tValue = image20
    tValue = Label(App, image=image20)
    tValue.image20 = image20
    uValue = image21
    uValue = Label(App, image=image21)
    uValue.image21 = image21
    vValue = image22
    vValue = Label(App, image=image22)
    vValue.image22 = image22
    wValue = image23
    wValue = Label(App, image=image23)
    wValue.image23 = image23
    xValue = image24
    xValue = Label(App, image=image24)
    xValue.image24 = image24
    yValue = image25
    yValue = Label(App, image=image25)
    yValue.image25 = image25
    zValue = image25
    zValue = Label(App, image=image26)
    zValue.image26 = image26
    aaValue = image27
    aaValue = Label(App, image=image27)
    aaValue.image27 = image27
    abValue = image28
    abValue = Label(App, image=image28)
    abValue.image28 = image28
    
    za = []
    zb = []
    zc = []
    zd = []
    ze = []
    zf = []
    zg = []
    zh = []
    zi = []
    zj = []
    zk = []
    zl = []
    zm = []
    zn = []
    zo = []
    zp = []
    zq = []
    zr = []
    zs = []
    zt = []
    zu = []
    zv = []
    zw = []
    zx = []
    zy = []
    zz = []
    aaz = []
    abz = []

    za = [value1, aValue, '\n']
    zb = [value2, bValue, '\n']
    zc = [value3, cValue, '\n']
    zd = [value4, dValue, '\n']
    ze = [value5, eValue, '\n']
    zf = [value6, fValue, '\n']
    zg = [value7, gValue, '\n']
    zh = [value8, hValue, '\n']
    zi = [value9, iValue, '\n']
    zj = [value10, jValue, '\n']
    zk = [value11, kValue, '\n']
    zl = [value12, lValue, '\n']
    zm = [value13, mValue, '\n']
    zn = [value14, nValue, '\n']
    zo = [value15, oValue, '\n']
    zp = [value16, pValue, '\n']
    zq = [value17, qValue, '\n']
    zr = [value18, rValue, '\n']
    zs = [value19, sValue, '\n']
    zt = [value20, tValue, '\n']
    zu = [value21, uValue, '\n']
    zv = [value22, vValue, '\n']
    zw = [value23, wValue, '\n']
    zx = [value24, xValue, '\n']
    zy = [value25, yValue, '\n']
    zz = [value26, zValue, '\n']
    aaz = [value27, aaValue, '\n']
    abz = [value28, abValue, '\n']

    
    ya = [za, zb, zc, zd, ze, zf, zg, zh, zi, zj, zk, zl, zm, zn, zo, zp, zq, zr, zs, zt, zu, zv, zw, zx, zy, zz, aaz, abz]
    zzzx = sorted(ya, key=itemgetter(0), reverse=False)
    zzzz = zzzx

    qa = zzzx[0]
    qb = zzzx[1]
    qc = zzzx[2]
    qd = zzzx[3]
    qe = zzzx[4]
    qf = zzzx[5]
    qg = zzzx[6]
    qh = zzzx[7]
    qi = zzzx[8]
    qj = zzzx[9]
    qk = zzzx[10]
    ql = zzzx[11]
    qm = zzzx[12]
    qn = zzzx[13]
    qo = zzzx[14]
    qp = zzzx[15]
    qq = zzzx[16]
    qr = zzzx[17]
    qs = zzzx[18]
    qt = zzzx[19]
    qu = zzzx[20]
    qv = zzzx[21]
    qw = zzzx[22]
    qx = zzzx[23]
    qy = zzzx[24]
    qz = zzzx[25]
    qaqz = zzzx[26]
    qbqz = zzzx[27]

    xa = qa[-2]
    xb = qb[-2]
    xc = qc[-2]
    xd = qd[-2]
    xe = qe[-2]
    xf = qf[-2]
    xg = qg[-2]
    xh = qh[-2]
    xi = qi[-2]
    xj = qj[-2]
    xk = qk[-2]
    xl = ql[-2]
    xm = qm[-2]
    xn = qn[-2]
    xo = qo[-2]
    xp = qp[-2]
    xq = qq[-2]
    xr = qr[-2]
    xs = qs[-2]
    xt = qt[-2]
    xu = qu[-2]
    xv = qv[-2]
    xw = qw[-2]
    xx = qx[-2]
    xy = qy[-2]
    xz = qz[-2]
    aazq = qaqz[-2]
    abzq = qbqz[-2]
    
    qq1 = xa
    qq2 = xb
    qq3 = xc
    qq4 = xd
    qq5 = xe
    qq6 = xf
    qq7 = xg
    qq8 = xh
    qq9 = xi
    qq10 = xj
    qq11 = xk
    qq12 = xl
    qq13 = xm
    qq14 = xn
    qq15 = xo
    qq16 = xp
    qq17 = xq
    qq18 = xr
    qq19 = xs
    qq20 = xt
    qq21 = xu
    qq22 = xv
    qq23 = xw
    qq24 = xx
    qq25 = xy
    qq26 = xz
    qq27 = aazq
    qq28 = abzq
    
    qq1.config(bg='#888888')
    qq1.grid(column=1, row=1)

    qq2.config(bg='#888888')
    qq2.grid(column=2, row=1)

    qq3.config(bg='#888888')
    qq3.grid(column=3, row=1)

    qq4.config(bg='#888888')
    qq4.grid(column=4, row=1)

    qq5.config(bg='#888888')
    qq5.grid(column=5, row=1)

    qq6.config(bg='#888888')
    qq6.grid(column=6, row=1)

    qq7.config(bg='#888888')
    qq7.grid(column=7, row=1)

    qq8.config(bg='#888888')
    qq8.grid(column=1, row=2)

    qq9.config(bg='#888888')
    qq9.grid(column=2, row=2)

    qq10.config(bg='#888888')
    qq10.grid(column=3, row=2)

    qq11.config(bg='#888888')
    qq11.grid(column=4, row=2)

    qq12.config(bg='#888888')
    qq12.grid(column=5, row=2)

    qq13.config(bg='#888888')
    qq13.grid(column=6, row=2)

    qq14.config(bg='#888888')
    qq14.grid(column=7, row=2)

    qq15.config(bg='#888888')
    qq15.grid(column=1, row=3)

    qq16.config(bg='#888888')
    qq16.grid(column=2, row=3)

    qq17.config(bg='#888888')
    qq17.grid(column=3, row=3)

    qq18.config(bg='#888888')
    qq18.grid(column=4, row=3)

    qq19.config(bg='#888888')
    qq19.grid(column=5, row=3)

    qq20.config(bg='#888888')
    qq20.grid(column=6, row=3)

    qq21.config(bg='#888888')
    qq21.grid(column=7, row=3)

    qq22.config(bg='#888888')
    qq22.grid(column=1, row=4)

    qq23.config(bg='#888888')
    qq23.grid(column=2, row=4)

    qq24.config(bg='#888888')
    qq24.grid(column=3, row=4)

    qq25.config(bg='#888888')
    qq25.grid(column=4, row=4)

    qq26.config(bg='#888888')
    qq26.grid(column=5, row=4)

    qq27.config(bg='#888888')
    qq27.grid(column=6, row=4)

    qq28.config(bg='#888888')
    qq28.grid(column=7, row=4)


    return

App = Tk()
App.config(bg="#000000")

updateB_text = Button(App, width=7, command=thisFunction, text="SHUFFLE")
updateB_text.grid(row=0, column=0)

App.mainloop()
