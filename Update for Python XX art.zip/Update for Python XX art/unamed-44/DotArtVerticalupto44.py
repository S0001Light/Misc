from tkinter import *
import tkinter as tk
import random
from operator import itemgetter

def thisFunction():
    global qq1, qq2, qq3, qq4, qq5, qq6, qq7, qq8, qq9, qq10, qq11, qq12, qq13, qq14, qq15, qq16, qq17, qq18, qq19, qq20, qq21, qq22, qq23, qq24, qq25, qq26, qq27, qq28, qq29, qq30, qq31, qq32, qq33, qq34, qq35, qq36, qq37, qq38, qq39, qq40, qq41, qq42, qq43, qq44
    
    value1 = str(random.randint(0, 44))
    value2 = str(random.randint(0, 44))
    value3 = str(random.randint(0, 44))
    value4 = str(random.randint(0, 44))
    value5 = str(random.randint(0, 44))
    value6 = str(random.randint(0, 44))
    value7 = str(random.randint(0, 44))
    value8 = str(random.randint(0, 44))
    value9 = str(random.randint(0, 44))
    value10 = str(random.randint(0, 44))
    value11 = str(random.randint(0, 44))
    value12 = str(random.randint(0, 44))
    value13 = str(random.randint(0, 44))
    value14 = str(random.randint(0, 44))
    value15 = str(random.randint(0, 44))
    value16 = str(random.randint(0, 44))
    value17 = str(random.randint(0, 44))
    value18 = str(random.randint(0, 44))
    value19 = str(random.randint(0, 44))
    value20 = str(random.randint(0, 44))
    value21 = str(random.randint(0, 44))
    value22 = str(random.randint(0, 44))
    value23 = str(random.randint(0, 44))
    value24 = str(random.randint(0, 44))
    value25 = str(random.randint(0, 44))
    value26 = str(random.randint(0, 44))
    value27 = str(random.randint(0, 44))
    value28 = str(random.randint(0, 44))
    value29 = str(random.randint(0, 44))
    value30 = str(random.randint(0, 44))
    value31 = str(random.randint(0, 44))
    value32 = str(random.randint(0, 44))
    value33 = str(random.randint(0, 44))
    value34 = str(random.randint(0, 44))
    value35 = str(random.randint(0, 44))
    value36 = str(random.randint(0, 44))
    value37 = str(random.randint(0, 44))
    value38 = str(random.randint(0, 44))
    value39 = str(random.randint(0, 44))
    value40 = str(random.randint(0, 44))
    value41 = str(random.randint(0, 44))
    value42 = str(random.randint(0, 44))
    value43 = str(random.randint(0, 44))
    value44 = str(random.randint(0, 44))
    
    image1 = PhotoImage(file="0001.GIF", format="GIF")

    image2 = PhotoImage(file="0002.GIF", format="GIF")

    image3 = PhotoImage(file="0003.GIF", format="GIF")

    image4 = PhotoImage(file="0004.GIF", format="GIF")

    image5 = PhotoImage(file="0005.GIF", format="GIF")

    image6 = PhotoImage(file="0006.GIF", format="GIF")

    image7 = PhotoImage(file="0007.GIF", format="GIF")

    image8 = PhotoImage(file="0008.GIF", format="GIF")

    image9 = PhotoImage(file="0009.GIF", format="GIF")

    image10 = PhotoImage(file="0010.GIF", format="GIF")

    image11 = PhotoImage(file="0011.GIF", format="GIF")

    image12 = PhotoImage(file="0012.GIF", format="GIF")

    image13 = PhotoImage(file="0013.GIF", format="GIF")

    image14 = PhotoImage(file="0014.GIF", format="GIF")

    image15 = PhotoImage(file="0015.GIF", format="GIF")

    image16 = PhotoImage(file="0016.GIF", format="GIF")

    image17 = PhotoImage(file="0017.GIF", format="GIF")

    image18 = PhotoImage(file="0001.GIF", format="GIF")

    image19 = PhotoImage(file="0002.GIF", format="GIF")

    image20 = PhotoImage(file="0003.GIF", format="GIF")

    image21 = PhotoImage(file="0004.GIF", format="GIF")

    image22 = PhotoImage(file="0005.GIF", format="GIF")

    image23 = PhotoImage(file="0006.GIF", format="GIF")

    image24 = PhotoImage(file="0007.GIF", format="GIF")

    image25 = PhotoImage(file="0008.GIF", format="GIF")

    image26 = PhotoImage(file="0009.GIF", format="GIF")

    image27 = PhotoImage(file="0010.GIF", format="GIF")

    image28 = PhotoImage(file="0011.GIF", format="GIF")

    image29 = PhotoImage(file="0012.GIF", format="GIF")

    image30 = PhotoImage(file="0013.GIF", format="GIF")

    image31 = PhotoImage(file="0014.GIF", format="GIF")

    image32 = PhotoImage(file="0015.GIF", format="GIF")

    image33 = PhotoImage(file="0016.GIF", format="GIF")

    image34 = PhotoImage(file="0017.GIF", format="GIF")

    image35 = PhotoImage(file="0001.GIF", format="GIF")

    image36 = PhotoImage(file="0002.GIF", format="GIF")

    image37 = PhotoImage(file="0003.GIF", format="GIF")

    image38 = PhotoImage(file="0004.GIF", format="GIF")

    image39 = PhotoImage(file="0005.GIF", format="GIF")

    image40 = PhotoImage(file="0006.GIF", format="GIF")

    image41 = PhotoImage(file="0007.GIF", format="GIF")

    image42 = PhotoImage(file="0008.GIF", format="GIF")

    image43 = PhotoImage(file="0009.GIF", format="GIF")

    image44 = PhotoImage(file="0010.GIF", format="GIF")

    aValue = image1
    aValue = Label(App, image=image1)
    aValue.image1 = image1
    bValue = image2
    bValue = Label(App, image=image2)
    bValue.image2 = image2
    cValue = image3
    cValue = Label(App, image=image3)
    cValue.image3 = image3
    dValue = image4
    dValue = Label(App, image=image4)
    dValue.image4 = image4
    eValue = image5
    eValue = Label(App, image=image5)
    eValue.image5 = image5
    fValue = image6
    fValue = Label(App, image=image6)
    fValue.image6 = image6
    gValue = image7
    gValue = Label(App, image=image7)
    gValue.image7 = image7
    hValue = image8
    hValue = Label(App, image=image8)
    hValue.image8 = image8
    iValue = image9
    iValue = Label(App, image=image9)
    iValue.image9 = image9
    jValue = image10
    jValue = Label(App, image=image10)
    jValue.image10 = image10
    kValue = image11
    kValue = Label(App, image=image11)
    kValue.image11 = image11
    lValue = image12
    lValue = Label(App, image=image12)
    lValue.image12 = image12
    mValue = image13
    mValue = Label(App, image=image13)
    mValue.image13 = image13
    nValue = image14
    nValue = Label(App, image=image14)
    nValue.image14 = image14
    oValue = image15
    oValue = Label(App, image=image15)
    oValue.image15 = image15
    pValue = image16
    pValue = Label(App, image=image16)
    pValue.image16 = image16
    qValue = image17
    qValue = Label(App, image=image17)
    qValue.image17 = image17
    rValue = image18
    rValue = Label(App, image=image18)
    rValue.image18 = image18
    sValue = image19
    sValue = Label(App, image=image19)
    sValue.image19 = image19
    tValue = image20
    tValue = Label(App, image=image20)
    tValue.image20 = image20
    uValue = image21
    uValue = Label(App, image=image21)
    uValue.image21 = image21
    vValue = image22
    vValue = Label(App, image=image22)
    vValue.image22 = image22
    wValue = image23
    wValue = Label(App, image=image23)
    wValue.image23 = image23
    xValue = image24
    xValue = Label(App, image=image24)
    xValue.image24 = image24
    yValue = image25
    yValue = Label(App, image=image25)
    yValue.image25 = image25
    zValue = image25
    zValue = Label(App, image=image26)
    zValue.image26 = image26
    aaValue = image27
    aaValue = Label(App, image=image27)
    aaValue.image27 = image27
    abValue = image28
    abValue = Label(App, image=image28)
    abValue.image28 = image28
    acValue = image29
    acValue = Label(App, image=image29)
    acValue.image29 = image29
    adValue = image30
    adValue = Label(App, image=image30)
    adValue.image30 = image30
    aeValue = image31
    aeValue = Label(App, image=image31)
    aeValue.image31 = image31
    afValue = image32
    afValue = Label(App, image=image32)
    afValue.image32 = image32
    agValue = image33
    agValue = Label(App, image=image33)
    agValue.image33 = image33
    ahValue = image34
    ahValue = Label(App, image=image34)
    ahValue.image34 = image34
    aiValue = image35
    aiValue = Label(App, image=image35)
    aiValue.image35 = image35
    ajValue = image36
    ajValue = Label(App, image=image36)
    ajValue.image36 = image36
    akValue = image37
    akValue = Label(App, image=image37)
    akValue.image37 = image37
    alValue = image38
    alValue = Label(App, image=image38)
    alValue.image38 = image38
    amValue = image39
    amValue = Label(App, image=image39)
    amValue.image39 = image39
    anValue = image40
    anValue = Label(App, image=image40)
    anValue.image40 = image40
    aoValue = image41
    aoValue = Label(App, image=image41)
    aoValue.image41 = image41
    apValue = image42
    apValue = Label(App, image=image42)
    apValue.image42 = image42
    aqValue = image43
    aqValue = Label(App, image=image43)
    aqValue.image43 = image43
    arValue = image44
    arValue = Label(App, image=image44)
    arValue.image44 = image44

    za = []
    zb = []
    zc = []
    zd = []
    ze = []
    zf = []
    zg = []
    zh = []
    zi = []
    zj = []
    zk = []
    zl = []
    zm = []
    zn = []
    zo = []
    zp = []
    zq = []
    zr = []
    zs = []
    zt = []
    zu = []
    zv = []
    zw = []
    zx = []
    zy = []
    zz = []
    zaa = []
    zab = []
    zac = []
    zad = []
    zae = []
    zaf = []
    zag = []
    zah = []
    zai = []
    zaj = []
    zak = []
    zal = []
    zam = []
    zan = []
    zao = []
    zam = []
    zan = []
    zao = []
    zaq = []
    zar = []

    za = [value1, aValue, '\n']
    zb = [value2, bValue, '\n']
    zc = [value3, cValue, '\n']
    zd = [value4, dValue, '\n']
    ze = [value5, eValue, '\n']
    zf = [value6, fValue, '\n']
    zg = [value7, gValue, '\n']
    zh = [value8, hValue, '\n']
    zi = [value9, iValue, '\n']
    zj = [value10, jValue, '\n']
    zk = [value11, kValue, '\n']
    zl = [value12, lValue, '\n']
    zm = [value13, mValue, '\n']
    zn = [value14, nValue, '\n']
    zo = [value15, oValue, '\n']
    zp = [value16, pValue, '\n']
    zq = [value17, qValue, '\n']
    zr = [value18, rValue, '\n']
    zs = [value19, sValue, '\n']
    zt = [value20, tValue, '\n']
    zu = [value21, uValue, '\n']
    zv = [value22, vValue, '\n']
    zw = [value23, wValue, '\n']
    zx = [value24, xValue, '\n']
    zy = [value25, yValue, '\n']
    zz = [value26, zValue, '\n']
    zaa = [value27, aaValue, '\n']
    zab = [value28, abValue, '\n']
    zac = [value29, acValue, '\n']
    zad = [value30, adValue, '\n']
    zae = [value31, aeValue, '\n']
    zaf = [value32, afValue, '\n']
    zag = [value33, agValue, '\n']
    zah = [value34, ahValue, '\n']
    zai = [value35, aiValue, '\n']
    zaj = [value36, ajValue, '\n']
    zak = [value37, akValue, '\n']
    zal = [value38, alValue, '\n']
    zam = [value39, amValue, '\n']
    zan = [value40, anValue, '\n']
    zao = [value41, aoValue, '\n']
    zap = [value42, apValue, '\n']
    zaq = [value43, aqValue, '\n']
    zar = [value44, arValue, '\n']
    
    ya = [za, zb, zc, zd, ze, zf, zg, zh, zi, zj, zk, zl, zm, zn, zo, zp, zq, zr, zs, zt, zu, zv, zw, zx, zy, zz, zaa, zab, zac, zad, zae, zaf, zag, zah, zai, zaj, zah, zai, zaj, zak, zal, zam, zan, zao, zap, zaq, zar]
    zzzx = sorted(ya, key=itemgetter(0), reverse=False)
    zzzz = zzzx

    qa = zzzx[0]
    qb = zzzx[1]
    qc = zzzx[2]
    qd = zzzx[3]
    qe = zzzx[4]
    qf = zzzx[5]
    qg = zzzx[6]
    qh = zzzx[7]
    qi = zzzx[8]
    qj = zzzx[9]
    qk = zzzx[10]
    ql = zzzx[11]
    qm = zzzx[12]
    qn = zzzx[13]
    qo = zzzx[14]
    qp = zzzx[15]
    qq = zzzx[16]
    qr = zzzx[17]
    qs = zzzx[18]
    qt = zzzx[19]
    qu = zzzx[20]
    qv = zzzx[21]
    qw = zzzx[22]
    qx = zzzx[23]
    qy = zzzx[24]
    qz = zzzx[25]
    qaa = zzzx[26]
    qab = zzzx[27]
    qac = zzzx[28]
    qad = zzzx[29]
    qae = zzzx[30]
    qaf = zzzx[31]
    qag = zzzx[32]
    qah = zzzx[33]
    qai = zzzx[34]
    qaj = zzzx[35]
    qak = zzzx[36]
    qal = zzzx[37]
    qam = zzzx[38]
    qan = zzzx[39]
    qao = zzzx[40]
    qap = zzzx[41]
    qaq = zzzx[42]
    qar = zzzx[43]

    xa = qa[-2]
    xb = qb[-2]
    xc = qc[-2]
    xd = qd[-2]
    xe = qe[-2]
    xf = qf[-2]
    xg = qg[-2]
    xh = qh[-2]
    xi = qi[-2]
    xj = qj[-2]
    xk = qk[-2]
    xl = ql[-2]
    xm = qm[-2]
    xn = qn[-2]
    xo = qo[-2]
    xp = qp[-2]
    xq = qq[-2]
    xr = qr[-2]
    xs = qs[-2]
    xt = qt[-2]
    xu = qu[-2]
    xv = qv[-2]
    xw = qw[-2]
    xx = qx[-2]
    xy = qy[-2]
    xz = qz[-2]
    xaa = qaa[-2]
    xab = qab[-2]
    xac = qac[-2]
    xad = qad[-2]
    xae = qae[-2]
    xaf = qaf[-2]
    xag = qag[-2]
    xah = qah[-2]
    xai = qai[-2]
    xaj = qaj[-2]
    xak = qak[-2]
    xal = qal[-2]
    xam = qam[-2]
    xan = qan[-2]
    xao = qao[-2]
    xap = qap[-2]
    xaq = qaq[-2]
    xar = qar[-2]

    qq1 = xa
    qq2 = xb
    qq3 = xc
    qq4 = xd
    qq5 = xe
    qq6 = xf
    qq7 = xg
    qq8 = xh
    qq9 = xi
    qq10 = xj
    qq11 = xk
    qq12 = xl
    qq13 = xm
    qq14 = xn
    qq15 = xo
    qq16 = xp
    qq17 = xq
    qq18 = xr
    qq19 = xs
    qq20 = xt
    qq21 = xu
    qq22 = xv
    qq23 = xw
    qq24 = xx
    qq25 = xy
    qq26 = xz
    qq27 = xaa
    qq28 = xab
    qq29 = xac
    qq30 = xad
    qq31 = xae
    qq32 = xaf
    qq33 = xag
    qq34 = xah
    qq35 = xai
    qq36 = xaj
    qq37 = xak
    qq38 = xal
    qq39 = xam
    qq40 = xan
    qq41 = xao
    qq42 = xap
    qq43 = xaq
    qq44 = xar
    
    y = 2

    qq1.config(bg='#000000')
    qq1.grid(column=1, row=y)

    qq2.config(bg='#000000')
    qq2.grid(column=2, row=y)

    qq3.config(bg='#000000')
    qq3.grid(column=3, row=y)

    qq4.config(bg='#000000')
    qq4.grid(column=4, row=y)

    qq5.config(bg='#000000')
    qq5.grid(column=5, row=y)

    qq6.config(bg='#000000')
    qq6.grid(column=6, row=y)

    qq7.config(bg='#000000')
    qq7.grid(column=7, row=y)

    qq8.config(bg='#000000')
    qq8.grid(column=8, row=y)

    qq9.config(bg='#000000')
    qq9.grid(column=9, row=y)

    qq10.config(bg='#000000')
    qq10.grid(column=10, row=y)

    qq11.config(bg='#000000')
    qq11.grid(column=11, row=y)

    qq12.config(bg='#000000')
    qq12.grid(column=12, row=y)

    qq13.config(bg='#000000')
    qq13.grid(column=13, row=y)

    qq14.config(bg='#000000')
    qq14.grid(column=14, row=y)

    qq15.config(bg='#000000')
    qq15.grid(column=15, row=y)

    qq16.config(bg='#000000')
    qq16.grid(column=16, row=y)

    qq17.config(bg='#000000')
    qq17.grid(column=17, row=y)

    qq18.config(bg='#000000')
    qq18.grid(column=18, row=y)

    qq19.config(bg='#000000')
    qq19.grid(column=19, row=y)

    qq20.config(bg='#000000')
    qq20.grid(column=20, row=y)

    qq21.config(bg='#000000')
    qq21.grid(column=21, row=y)

    qq22.config(bg='#000000')
    qq22.grid(column=22, row=y)

    qq23.config(bg='#000000')
    qq23.grid(column=23, row=y)

    qq24.config(bg='#000000')
    qq24.grid(column=24, row=y)

    qq25.config(bg='#000000')
    qq25.grid(column=25, row=y)

    qq26.config(bg='#000000')
    qq26.grid(column=26, row=y)

    qq27.config(bg='#000000')
    qq27.grid(column=27, row=y)

    qq28.config(bg='#000000')
    qq28.grid(column=28, row=y)

    qq29.config(bg='#000000')
    qq29.grid(column=29, row=y)

    qq30.config(bg='#000000')
    qq30.grid(column=30, row=y)

    qq31.config(bg='#000000')
    qq31.grid(column=31, row=y)

    qq32.config(bg='#000000')
    qq32.grid(column=32, row=y)

    qq33.config(bg='#000000')
    qq33.grid(column=33, row=y)

    qq34.config(bg='#000000')
    qq34.grid(column=34, row=y)

    qq35.config(bg='#000000')
    qq35.grid(column=35, row=y)

    qq36.config(bg='#000000')
    qq36.grid(column=36, row=y)

    qq37.config(bg='#000000')
    qq37.grid(column=37, row=y)

    qq38.config(bg='#000000')
    qq38.grid(column=38, row=y)

    qq39.config(bg='#000000')
    qq39.grid(column=39, row=y)

    qq40.config(bg='#000000')
    qq40.grid(column=40, row=y)

    qq41.config(bg='#000000')
    qq41.grid(column=41, row=y)

    qq42.config(bg='#000000')
    qq42.grid(column=42, row=y)

    qq43.config(bg='#000000')
    qq43.grid(column=43, row=y)

    qq44.config(bg='#000000')
    qq44.grid(column=44, row=y)

    return

App = Tk()
App.config(bg="#000000")

updateB_text = Button(App, width=4, command=thisFunction, text="REARRANGE")
updateB_text.grid(row=0, column=0)

y = 1

def qz1():
    qq1.destroy()
    return
qq1 = Button(App, width=2, text='Delete', command=qz1)
qq1.config(bg='#fdfdfd')
qq1.grid(column=1, row=y)
def qz2():
    qq2.destroy()
    return
qq2 = Button(App, width=2, text='Delete', command=qz2)
qq2.config(bg='#fdfdfd')
qq2.grid(column=2, row=y)
def qz3():
    qq3.destroy()
    return
qq3 = Button(App, width=2, text='Delete', command=qz3)
qq3.config(bg='#fdfdfd')
qq3.grid(column=3, row=y)
def qz4():
    qq4.destroy()
    return
qq4 = Button(App, width=2, text='Delete', command=qz4)
qq4.config(bg='#fdfdfd')
qq4.grid(column=4, row=y)
def qz5():
    qq5.destroy()
    return
qq5 = Button(App, width=2, text='Delete', command=qz5)
qq5.config(bg='#fdfdfd')
qq5.grid(column=5, row=y)
def qz6():
    qq6.destroy()
    return
qq6 = Button(App, width=2, text='Delete', command=qz6)
qq6.config(bg='#fdfdfd')
qq6.grid(column=6, row=y)
def qz7():
    qq7.destroy()
    return
qq7 = Button(App, width=2, text='Delete', command=qz7)
qq7.config(bg='#fdfdfd')
qq7.grid(column=7, row=y)
def qz8():
    qq8.destroy()
    return
qq8 = Button(App, width=2, text='Delete', command=qz8)
qq8.config(bg='#fdfdfd')
qq8.grid(column=8, row=y)
def qz9():
    qq9.destroy()
    return
qq9 = Button(App, width=2, text='Delete', command=qz9)
qq9.config(bg='#fdfdfd')
qq9.grid(column=9, row=y)
def qz10():
    qq10.destroy()
    return
qq10 = Button(App, width=2, text='Delete', command=qz10)
qq10.config(bg='#fdfdfd')
qq10.grid(column=10, row=y)
def qz11():
    qq11.destroy()
    return
qq11 = Button(App, width=2, text='Delete', command=qz11)
qq11.config(bg='#fdfdfd')
qq11.grid(column=11, row=y)
def qz12():
    qq12.destroy()
    return
qq12 = Button(App, width=2, text='Delete', command=qz12)
qq12.config(bg='#fdfdfd')
qq12.grid(column=12, row=y)
def qz13():
    qq13.destroy()
    return
qq13 = Button(App, width=2, text='Delete', command=qz13)
qq13.config(bg='#fdfdfd')
qq13.grid(column=13, row=y)
def qz14():
    qq14.destroy()
    return
qq14 = Button(App, width=2, text='Delete', command=qz14)
qq14.config(bg='#fdfdfd')
qq14.grid(column=14, row=y)
def qz15():
    qq15.destroy()
    return
qq15 = Button(App, width=2, text='Delete', command=qz15)
qq15.config(bg='#fdfdfd')
qq15.grid(column=15, row=y)
def qz16():
    qq16.destroy()
    return
qq16 = Button(App, width=2, text='Delete', command=qz16)
qq16.config(bg='#fdfdfd')
qq16.grid(column=16, row=y)
def qz17():
    qq17.destroy()
    return
qq17 = Button(App, width=2, text='Delete', command=qz17)
qq17.config(bg='#fdfdfd')
qq17.grid(column=17, row=y)
def qz18():
    qq18.destroy()
    return
qq18 = Button(App, width=2, text='Delete', command=qz18)
qq18.config(bg='#fdfdfd')
qq18.grid(column=18, row=y)
def qz19():
    qq19.destroy()
    return
qq19 = Button(App, width=2, text='Delete', command=qz19)
qq19.config(bg='#fdfdfd')
qq19.grid(column=19, row=y)
def qz20():
    qq20.destroy()
    return
qq20 = Button(App, width=2, text='Delete', command=qz20)
qq20.config(bg='#fdfdfd')
qq20.grid(column=20, row=y)
def qz21():
    qq21.destroy()
    return
qq21 = Button(App, width=2, text='Delete', command=qz21)
qq21.config(bg='#fdfdfd')
qq21.grid(column=21, row=y)
def qz22():
    qq22.destroy()
    return
qq22 = Button(App, width=2, text='Delete', command=qz22)
qq22.config(bg='#fdfdfd')
qq22.grid(column=22, row=y)
def qz23():
    qq23.destroy()
    return
qq23 = Button(App, width=2, text='Delete', command=qz23)
qq23.config(bg='#fdfdfd')
qq23.grid(column=23, row=y)
def qz24():
    qq24.destroy()
    return
qq24 = Button(App, width=2, text='Delete', command=qz24)
qq24.config(bg='#fdfdfd')
qq24.grid(column=24, row=y)
def qz25():
    qq25.destroy()
    return
qq25 = Button(App, width=2, text='Delete', command=qz25)
qq25.config(bg='#fdfdfd')
qq25.grid(column=25, row=y)
def qz26():
    qq26.destroy()
    return
qq26 = Button(App, width=2, text='Delete', command=qz26)
qq26.config(bg='#fdfdfd')
qq26.grid(column=26, row=y)
def qz27():
    qq27.destroy()
    return
qq27 = Button(App, width=2, text='Delete', command=qz27)
qq27.config(bg='#fdfdfd')
qq27.grid(column=27, row=y)
def qz28():
    qq28.destroy()
    return
qq28 = Button(App, width=2, text='Delete', command=qz28)
qq28.config(bg='#fdfdfd')
qq28.grid(column=28, row=y)
def qz29():
    qq29.destroy()
    return
qq29 = Button(App, width=2, text='Delete', command=qz29)
qq29.config(bg='#fdfdfd')
qq29.grid(column=29, row=y)
def qz30():
    qq30.destroy()
    return
qq30 = Button(App, width=2, text='Delete', command=qz30)
qq30.config(bg='#fdfdfd')
qq30.grid(column=30, row=y)
def qz31():
    qq31.destroy()
    return
qq31 = Button(App, width=2, text='Delete', command=qz31)
qq31.config(bg='#fdfdfd')
qq31.grid(column=31, row=y)
def qz32():
    qq32.destroy()
    return
qq32 = Button(App, width=2, text='Delete', command=qz32)
qq32.config(bg='#fdfdfd')
qq32.grid(column=32, row=y)
def qz33():
    qq33.destroy()
    return
qq33 = Button(App, width=2, text='Delete', command=qz33)
qq33.config(bg='#fdfdfd')
qq33.grid(column=33, row=y)
def qz34():
    qq34.destroy()
    return
qq34 = Button(App, width=2, text='Delete', command=qz34)
qq34.config(bg='#fdfdfd')
qq34.grid(column=34, row=y)
def qz35():
    qq35.destroy()
    return
qq35 = Button(App, width=2, text='Delete', command=qz35)
qq35.config(bg='#fdfdfd')
qq35.grid(column=35, row=y)
def qz36():
    qq36.destroy()
    return
qq36 = Button(App, width=2, text='Delete', command=qz36)
qq36.config(bg='#fdfdfd')
qq36.grid(column=36, row=y)
def qz37():
    qq37.destroy()
    return
qq37 = Button(App, width=2, text='Delete', command=qz37)
qq37.config(bg='#fdfdfd')
qq37.grid(column=37, row=y)
def qz38():
    qq38.destroy()
    return
qq38 = Button(App, width=2, text='Delete', command=qz38)
qq38.config(bg='#fdfdfd')
qq38.grid(column=38, row=y)
def qz39():
    qq39.destroy()
    return
qq39 = Button(App, width=2, text='Delete', command=qz39)
qq39.config(bg='#fdfdfd')
qq39.grid(column=39, row=y)
def qz40():
    qq40.destroy()
    return
qq40 = Button(App, width=2, text='Delete', command=qz40)
qq40.config(bg='#fdfdfd')
qq40.grid(column=40, row=y)
def qz41():
    qq41.destroy()
    return
qq41 = Button(App, width=2, text='Delete', command=qz41)
qq41.config(bg='#fdfdfd')
qq41.grid(column=41, row=y)
def qz42():
    qq42.destroy()
    return
qq42 = Button(App, width=2, text='Delete', command=qz42)
qq42.config(bg='#fdfdfd')
qq42.grid(column=42, row=y)
def qz43():
    qq43.destroy()
    return
qq43 = Button(App, width=2, text='Delete', command=qz43)
qq43.config(bg='#fdfdfd')
qq43.grid(column=43, row=y)
def qz44():
    qq44.destroy()
    return
qq44 = Button(App, width=2, text='Delete', command=qz44)
qq44.config(bg='#fdfdfd')
qq44.grid(column=44, row=y)

def clearAll():
    qz1()
    qz2()
    qz3()
    qz4()
    qz5()
    qz6()
    qz7()
    qz8()
    qz9()
    qz10()
    qz11()
    qz12()
    qz13()
    qz14()
    qz15()
    qz16()
    qz17()
    qz18()
    qz19()
    qz20()
    qz21()
    qz22()
    qz23()
    qz24()
    qz25()
    qz26()
    qz27()
    qz28()
    qz29()
    qz30()
    qz31()
    qz32()
    qz33()
    qz34()
    qz35()
    qz36()
    qz37()
    qz38()
    qz39()
    qz40()
    qz41()
    qz42()
    qz43()
    qz44()
    return

updateC_text = Button(App, width=4, command=clearAll, text="CLEAR")
updateC_text.grid(row=1, column=0)

App.mainloop()
