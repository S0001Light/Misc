from tkinter import *
import tkinter as tk
import random
from operator import itemgetter

def aFunction():
    global sa, sb, sc, sd, se, sf, sg, sh, si, sj
   
    value1 = str(random.randint(0, 11))
    value2 = str(random.randint(0, 11))
    value3 = str(random.randint(0, 11))
    value4 = str(random.randint(0, 11))
    value5 = str(random.randint(0, 11))
    value6 = str(random.randint(0, 11))
    value7 = str(random.randint(0, 11))
    value8 = str(random.randint(0, 11))
    value9 = str(random.randint(0, 11))
    value10 = str(random.randint(0, 11))

    image1 = PhotoImage(file="0001.GIF", format="GIF")

    image2 = PhotoImage(file="0002.GIF", format="GIF")

    image3 = PhotoImage(file="0003.GIF", format="GIF")

    image4 = PhotoImage(file="0004.GIF", format="GIF")

    image5 = PhotoImage(file="0005.GIF", format="GIF")

    image6 = PhotoImage(file="0005.GIF", format="GIF")

    image7 = PhotoImage(file="0004.GIF", format="GIF")

    image8 = PhotoImage(file="0003.GIF", format="GIF")

    image9 = PhotoImage(file="0002.GIF", format="GIF")

    image10 = PhotoImage(file="0001.GIF", format="GIF")


    aValue = image1
    aValue = Label(App, image=image1)
    aValue.image1 = image1
    bValue = image2
    bValue = Label(App, image=image2)
    bValue.image2 = image2
    cValue = image3
    cValue = Label(App, image=image3)
    cValue.image3 = image3
    dValue = image4
    dValue = Label(App, image=image4)
    dValue.image4 = image4
    eValue = image5
    eValue = Label(App, image=image5)
    eValue.image5 = image5
    fValue = image6
    fValue = Label(App, image=image6)
    fValue.image6 = image6
    gValue = image7
    gValue = Label(App, image=image7)
    gValue.image7 = image7
    hValue = image8
    hValue = Label(App, image=image8)
    hValue.image8 = image8
    iValue = image9
    iValue = Label(App, image=image9)
    iValue.image9 = image9
    jValue = image10
    jValue = Label(App, image=image10)
    jValue.image10 = image10

    za = []
    zb = []
    zc = []
    zd = []
    ze = []
    zf = []
    zg = []
    zh = []
    zi = []
    zj = []

    za = [value1, aValue, '\n']
    zb = [value2, bValue, '\n']
    zc = [value3, cValue, '\n']
    zd = [value4, dValue, '\n']
    ze = [value5, eValue, '\n']
    zf = [value6, fValue, '\n']
    zg = [value7, gValue, '\n']
    zh = [value8, hValue, '\n']
    zi = [value9, iValue, '\n']
    zj = [value10, jValue, '\n']
    ya = [za, zb, zc, zd, ze, zf, zg, zh, zi, zj]
    zzx = sorted(ya, key=itemgetter(0), reverse=False)
    zzz = zzx

    qa = zzx[0]
    qb = zzx[1]
    qc = zzx[2]
    qd = zzx[3]
    qe = zzx[4]
    qf = zzx[5]
    qg = zzx[6]
    qh = zzx[7]
    qi = zzx[8]
    qj = zzx[9]

    xa = qa[-2]
    xb = qb[-2]
    xc = qc[-2]
    xd = qd[-2]
    xe = qe[-2]
    xf = qf[-2]
    xg = qg[-2]
    xh = qh[-2]
    xi = qi[-2]
    xj = qj[-2]

    sa = xa
    sb = xb
    sc = xc
    sd = xd
    se = xe
    sf = xf
    sg = xg
    sh = xh
    si = xi
    sj = xj

    yy = 1

    sa.config(bg="#000000")
    sa.grid(row=1, column=yy)
    sb.config(bg="#000000")
    sb.grid(row=2, column=yy)
    sc.config(bg="#000000")
    sc.grid(row=3, column=yy)
    sd.config(bg="#000000")
    sd.grid(row=4, column=yy)
    se.config(bg="#000000")
    se.grid(row=5, column=yy)
    sf.config(bg="#000000")
    sf.grid(row=6, column=yy)
    sg.config(bg="#000000")
    sg.grid(row=7, column=yy)
    sh.config(bg="#000000")
    sh.grid(row=8, column=yy)
    si.config(bg="#000000")
    si.grid(row=9, column=yy)
    sj.config(bg="#000000")
    sj.grid(row=10, column=yy)

    return

App = Tk()
App.config(bg="#000000")

def thisFunction():
    aFunction()
    return

updateB_text = Button(App, command=thisFunction, text="REARRANGE")
updateB_text.grid(row=0, column=0)

y = 0

def qza():
    sa.destroy()
    return
qqa = Button(App, width=10, text="Delete", command=qza)
qqa.config(bg="#000000")
qqa.grid(row=1, column=y)
def qzb():
    sb.destroy()
    return
qqb = Button(App, width=10, text="Delete", command=qzb)
qqb.config(bg="#000000")
qqb.grid(row=2, column=y)
def qzc():
    sc.destroy()
    return
qqc = Button(App, width=10, text="Delete", command=qzc)
qqc.config(bg="#000000")
qqc.grid(row=3, column=y)
def qzd():
    sd.destroy()
    return
qqd = Button(App, width=10, text="Delete", command=qzd)
qqd.config(bg="#000000")
qqd.grid(row=4, column=y)
def qze():
    se.destroy()
    return
qqe = Button(App, width=10, text="Delete", command=qze)
qqe.config(bg="#000000")
qqe.grid(row=5, column=y)
def qzf():
    sf.destroy()
    return
qqf = Button(App, width=10, text="Delete", command=qzf)
qqf.config(bg="#000000")
qqf.grid(row=6, column=y)
def qzg():
    sg.destroy()
qqg = Button(App, width=10, text="Delete", command=qzg)
qqg.config(bg="#000000")
qqg.grid(row=7, column=y)
def qzh():
    sh.destroy()
    return
qqh = Button(App, width=10, text="Delete", command=qzh)
qqh.config(bg="#000000")
qqh.grid(row=8, column=y)
def qzi():
    si.destroy()
    return
qqi = Button(App, width=10, text="Delete", command=qzi)
qqi.config(bg="#000000")
qqi.grid(row=9, column=y)
def qzj():
    sj.destroy()
    return
qqj = Button(App, width=10, text="Delete", command=qzj)
qqj.config(bg="#000000")
qqj.grid(row=10, column=y)

App.mainloop()
