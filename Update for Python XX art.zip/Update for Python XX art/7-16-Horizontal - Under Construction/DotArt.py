from tkinter import *
import tkinter as tk
import random
from operator import itemgetter

App = Tk()
App.config(bg="#000000")
App.title("Dot Artwork an SCS Code")

uB_text = Label(App, text="REARRANGEin Text Box, Enter a Number: 7-16 ")
uB_text.config(bg='#000000', fg='#ffffff')
uB_text.grid(row=0, column=0)

def uxghwa16():
    global qq1, qq2, qq3, qq4, qq5, qq6, qq7, qq8, qq9, qq10, qq11, qq12, qq13, qq14, qq15, qq16

    y = 1
    
    value1 = str(random.randint(0, 33))
    value2 = str(random.randint(0, 33))
    value3 = str(random.randint(0, 33))
    value4 = str(random.randint(0, 33))
    value5 = str(random.randint(0, 33))
    value6 = str(random.randint(0, 33))
    value7 = str(random.randint(0, 33))
    value8 = str(random.randint(0, 33))
    value9 = str(random.randint(0, 33))
    value10 = str(random.randint(0, 33))
    value11 = str(random.randint(0, 33))
    value12 = str(random.randint(0, 33))
    value13 = str(random.randint(0, 33))
    value14 = str(random.randint(0, 33))
    value15 = str(random.randint(0, 33))
    value16 = str(random.randint(0, 33))

    image1 = PhotoImage(file="0001.GIF", format="GIF")

    image2 = PhotoImage(file="0002.GIF", format="GIF")

    image3 = PhotoImage(file="0003.GIF", format="GIF")

    image4 = PhotoImage(file="0004.GIF", format="GIF")

    image5 = PhotoImage(file="0005.GIF", format="GIF")

    image6 = PhotoImage(file="0006.GIF", format="GIF")

    image7 = PhotoImage(file="0007.GIF", format="GIF")

    image8 = PhotoImage(file="0008.GIF", format="GIF")

    image9 = PhotoImage(file="0009.GIF", format="GIF")

    image10 = PhotoImage(file="0010.GIF", format="GIF")

    image11 = PhotoImage(file="0011.GIF", format="GIF")

    image12 = PhotoImage(file="0012.GIF", format="GIF")

    image13 = PhotoImage(file="0013.GIF", format="GIF")

    image14 = PhotoImage(file="0014.GIF", format="GIF")

    image15 = PhotoImage(file="0015.GIF", format="GIF")

    image16 = PhotoImage(file="0016.GIF", format="GIF")

    aValue = image1
    aValue = Label(App, image=image1)
    aValue.image1 = image1
    bValue = image2
    bValue = Label(App, image=image2)
    bValue.image2 = image2
    cValue = image3
    cValue = Label(App, image=image3)
    cValue.image3 = image3
    dValue = image4
    dValue = Label(App, image=image4)
    dValue.image4 = image4
    eValue = image5
    eValue = Label(App, image=image5)
    eValue.image5 = image5
    fValue = image6
    fValue = Label(App, image=image6)
    fValue.image6 = image6
    gValue = image7
    gValue = Label(App, image=image7)
    gValue.image7 = image7
    hValue = image8
    hValue = Label(App, image=image8)
    hValue.image8 = image8
    iValue = image9
    iValue = Label(App, image=image9)
    iValue.image9 = image9
    jValue = image10
    jValue = Label(App, image=image10)
    jValue.image10 = image10
    kValue = image11
    kValue = Label(App, image=image11)
    kValue.image11 = image11
    lValue = image12
    lValue = Label(App, image=image12)
    lValue.image12 = image12
    mValue = image13
    mValue = Label(App, image=image13)
    mValue.image13 = image13
    nValue = image14
    nValue = Label(App, image=image14)
    nValue.image14 = image14
    oValue = image15
    oValue = Label(App, image=image15)
    oValue.image15 = image15
    pValue = image16
    pValue = Label(App, image=image16)
    pValue.image16 = image16


    za = []
    zb = []
    zc = []
    zd = []
    ze = []
    zf = []
    zg = []
    zh = []
    zi = []
    zj = []
    zk = []
    zl = []
    zm = []
    zn = []
    zo = []
    zp = []

    za = [value1, aValue, '\n']
    zb = [value2, bValue, '\n']
    zc = [value3, cValue, '\n']
    zd = [value4, dValue, '\n']
    ze = [value5, eValue, '\n']
    zf = [value6, fValue, '\n']
    zg = [value7, gValue, '\n']
    zh = [value8, hValue, '\n']
    zi = [value9, iValue, '\n']
    zj = [value10, jValue, '\n']
    zk = [value11, kValue, '\n']
    zl = [value12, lValue, '\n']
    zm = [value13, mValue, '\n']
    zn = [value14, nValue, '\n']
    zo = [value15, oValue, '\n']
    zp = [value16, pValue, '\n']
    ya = [za, zb, zc, zd, ze, zf, zg, zh, zi, zj, zk, zl, zm, zn, zo, zp]
    zzx = sorted(ya, key=itemgetter(0), reverse=False)
    zzz = zzx

    qa = zzx[0]
    qb = zzx[1]
    qc = zzx[2]
    qd = zzx[3]
    qe = zzx[4]
    qf = zzx[5]
    qg = zzx[6]
    qh = zzx[7]
    qi = zzx[8]
    qj = zzx[9]
    qk = zzx[10]
    ql = zzx[11]
    qm = zzx[12]
    qn = zzx[13]
    qo = zzx[14]
    qp = zzx[15]

    xa = qa[-2]
    xb = qb[-2]
    xc = qc[-2]
    xd = qd[-2]
    xe = qe[-2]
    xf = qf[-2]
    xg = qg[-2]
    xh = qh[-2]
    xi = qi[-2]
    xj = qj[-2]
    xk = qk[-2]
    xl = ql[-2]
    xm = qm[-2]
    xn = qn[-2]
    xo = qo[-2]
    xp = qp[-2]

    qq1 = xa
    qq2 = xb
    qq3 = xc
    qq4 = xd
    qq5 = xe
    qq6 = xf
    qq7 = xg
    qq8 = xh
    qq9 = xi
    qq10 = xj
    qq11 = xk
    qq12 = xl
    qq13 = xm
    qq14 = xn
    qq15 = xo
    qq16 = xp
    
    qq1.config(bg='#000000')
    qq1.grid(row=1, column=y)

    qq2.config(bg='#000000')
    qq2.grid(row=2, column=y)

    qq3.config(bg='#000000')
    qq3.grid(row=3, column=y)

    qq4.config(bg='#000000')
    qq4.grid(row=4, column=y)

    qq5.config(bg='#000000')
    qq5.grid(row=5, column=y)

    qq6.config(bg='#000000')
    qq6.grid(row=6, column=y)

    qq7.config(bg='#000000')
    qq7.grid(row=7, column=y)

    qq8.config(bg='#000000')
    qq8.grid(row=8, column=y)

    qq9.config(bg='#000000')
    qq9.grid(row=9, column=y)

    qq10.config(bg='#000000')
    qq10.grid(row=10, column=y)

    qq11.config(bg='#000000')
    qq11.grid(row=11, column=y)

    qq12.config(bg='#000000')
    qq12.grid(row=12, column=y)

    qq13.config(bg='#000000')
    qq13.grid(row=13, column=y)

    qq14.config(bg='#000000')
    qq14.grid(row=14, column=y)

    qq15.config(bg='#000000')
    qq15.grid(row=15, column=y)

    qq16.config(bg='#000000')
    qq16.grid(row=16, column=y)
    return

def uxghwa15():
    global qq1, qq2, qq3, qq4, qq5, qq6, qq7, qq8, qq9, qq10, qq11, qq12, qq13, qq14, qq15

    y = 1

    value1 = str(random.randint(0, 33))
    value2 = str(random.randint(0, 33))
    value3 = str(random.randint(0, 33))
    value4 = str(random.randint(0, 33))
    value5 = str(random.randint(0, 33))
    value6 = str(random.randint(0, 33))
    value7 = str(random.randint(0, 33))
    value8 = str(random.randint(0, 33))
    value9 = str(random.randint(0, 33))
    value10 = str(random.randint(0, 33))
    value11 = str(random.randint(0, 33))
    value12 = str(random.randint(0, 33))
    value13 = str(random.randint(0, 33))
    value14 = str(random.randint(0, 33))
    value15 = str(random.randint(0, 33))

    image1 = PhotoImage(file="0001.Gif", format="GIF")

    image2 = PhotoImage(file="0002.GIF", format="GIF")

    image3 = PhotoImage(file="0003.GIF", format="GIF")

    image4 = PhotoImage(file="0004.GIF", format="GIF")

    image5 = PhotoImage(file="0005.GIF", format="GIF")

    image6 = PhotoImage(file="0006.GIF", format="GIF")

    image7 = PhotoImage(file="0007.GIF", format="GIF")

    image8 = PhotoImage(file="0008.GIF", format="GIF")

    image9 = PhotoImage(file="0009.GIF", format="GIF")

    image10 = PhotoImage(file="0010.GIF", format="GIF")

    image11 = PhotoImage(file="0011.GIF", format="GIF")

    image12 = PhotoImage(file="0012.GIF", format="GIF")

    image13 = PhotoImage(file="0013.GIF", format="GIF")

    image14 = PhotoImage(file="0014.GIF", format="GIF")

    image15 = PhotoImage(file="0015.GIF", format="GIF")

    aValue = image1
    aValue = Label(App, image=image1)
    aValue.image1 = image1
    bValue = image2
    bValue = Label(App, image=image2)
    bValue.image2 = image2
    cValue = image3
    cValue = Label(App, image=image3)
    cValue.image3 = image3
    dValue = image4
    dValue = Label(App, image=image4)
    dValue.image4 = image4
    eValue = image5
    eValue = Label(App, image=image5)
    eValue.image5 = image5
    fValue = image6
    fValue = Label(App, image=image6)
    fValue.image6 = image6
    gValue = image7
    gValue = Label(App, image=image7)
    gValue.image7 = image7
    hValue = image8
    hValue = Label(App, image=image8)
    hValue.image8 = image8
    iValue = image9
    iValue = Label(App, image=image9)
    iValue.image9 = image9
    jValue = image10
    jValue = Label(App, image=image10)
    jValue.image10 = image10
    kValue = image11
    kValue = Label(App, image=image11)
    kValue.image11 = image11
    lValue = image12
    lValue = Label(App, image=image12)
    lValue.image12 = image12
    mValue = image13
    mValue = Label(App, image=image13)
    mValue.image13 = image13
    nValue = image14
    nValue = Label(App, image=image14)
    nValue.image14 = image14
    oValue = image15
    oValue = Label(App, image=image15)
    oValue.image15 = image15

    za = []
    zb = []
    zc = []
    zd = []
    ze = []
    zf = []
    zg = []
    zh = []
    zi = []
    zj = []
    zk = []
    zl = []
    zm = []
    zn = []
    zo = []

    za = [value1, aValue, '\n']
    zb = [value2, bValue, '\n']
    zc = [value3, cValue, '\n']
    zd = [value4, dValue, '\n']
    ze = [value5, eValue, '\n']
    zf = [value6, fValue, '\n']
    zg = [value7, gValue, '\n']
    zh = [value8, hValue, '\n']
    zi = [value9, iValue, '\n']
    zj = [value10, jValue, '\n']
    zk = [value11, kValue, '\n']
    zl = [value12, lValue, '\n']
    zm = [value13, mValue, '\n']
    zn = [value14, nValue, '\n']
    zo = [value15, oValue, '\n']

    ya = [za, zb, zc, zd, ze, zf, zg, zh, zi, zj, zk, zl, zm, zn, zo]
    zzx = sorted(ya, key=itemgetter(0), reverse=False)
    zzz = zzx

    qa = zzx[0]
    qb = zzx[1]
    qc = zzx[2]
    qd = zzx[3]
    qe = zzx[4]
    qf = zzx[5]
    qg = zzx[6]
    qh = zzx[7]
    qi = zzx[8]
    qj = zzx[9]
    qk = zzx[10]
    ql = zzx[11]
    qm = zzx[12]
    qn = zzx[13]
    qo = zzx[14]

    xa = qa[-2]
    xb = qb[-2]
    xc = qc[-2]
    xd = qd[-2]
    xe = qe[-2]
    xf = qf[-2]
    xg = qg[-2]
    xh = qh[-2]
    xi = qi[-2]
    xj = qj[-2]
    xk = qk[-2]
    xl = ql[-2]
    xm = qm[-2]
    xn = qn[-2]
    xo = qo[-2]

    qq1 = xa
    qq2 = xb
    qq3 = xc
    qq4 = xd
    qq5 = xe
    qq6 = xf
    qq7 = xg
    qq8 = xh
    qq9 = xi
    qq10 = xj
    qq11 = xk
    qq12 = xl
    qq13 = xm
    qq14 = xn
    qq15 = xo
    
    qq1.config(bg='#000000')
    qq1.grid(row=1, column=y)

    qq2.config(bg='#000000')
    qq2.grid(row=2, column=y)

    qq3.config(bg='#000000')
    qq3.grid(row=3, column=y)

    qq4.config(bg='#000000')
    qq4.grid(row=4, column=y)

    qq5.config(bg='#000000')
    qq5.grid(row=5, column=y)

    qq6.config(bg='#000000')
    qq6.grid(row=6, column=y)

    qq7.config(bg='#000000')
    qq7.grid(row=7, column=y)

    qq8.config(bg='#000000')
    qq8.grid(row=8, column=y)

    qq9.config(bg='#000000')
    qq9.grid(row=9, column=y)

    qq10.config(bg='#000000')
    qq10.grid(row=10, column=y)

    qq11.config(bg='#000000')
    qq11.grid(row=11, column=y)

    qq12.config(bg='#000000')
    qq12.grid(row=12, column=y)

    qq13.config(bg='#000000')
    qq13.grid(row=13, column=y)

    qq14.config(bg='#000000')
    qq14.grid(row=14, column=y)

    qq15.config(bg='#000000')
    qq15.grid(row=15, column=y)
    return

def uxghwa14 ():
    global qq1, qq2, qq3, qq4, qq5, qq6, qq7, qq8, qq9, qq10, qq11, qq12, qq13, qq14

    y = 1
    
    value1 = str(random.randint(0, 33))
    value2 = str(random.randint(0, 33))
    value3 = str(random.randint(0, 33))
    value4 = str(random.randint(0, 33))
    value5 = str(random.randint(0, 33))
    value6 = str(random.randint(0, 33))
    value7 = str(random.randint(0, 33))
    value8 = str(random.randint(0, 33))
    value9 = str(random.randint(0, 33))
    value10 = str(random.randint(0, 33))
    value11 = str(random.randint(0, 33))
    value12 = str(random.randint(0, 33))
    value13 = str(random.randint(0, 33))
    value14 = str(random.randint(0, 33))

    image1 = PhotoImage(file="0001.GIF", format="GIF")

    image2 = PhotoImage(file="0002.GIF", format="GIF")

    image3 = PhotoImage(file="0003.GIF", format="GIF")

    image4 = PhotoImage(file="0004.GIF", format="GIF")

    image5 = PhotoImage(file="0005.GIF", format="GIF")

    image6 = PhotoImage(file="0006.GIF", format="GIF")

    image7 = PhotoImage(file="0007.GIF", format="GIF")

    image8 = PhotoImage(file="0008.GIF", format="GIF")

    image9 = PhotoImage(file="0009.GIF", format="GIF")

    image10 = PhotoImage(file="0010.GIF", format="GIF")

    image11 = PhotoImage(file="0011.GIF", format="GIF")

    image12 = PhotoImage(file="0012.GIF", format="GIF")

    image13 = PhotoImage(file="0013.GIF", format="GIF")

    image14 = PhotoImage(file="0014.GIF", format="GIF")

    aValue = image1
    aValue = Label(App, image=image1)
    aValue.image1 = image1
    bValue = image2
    bValue = Label(App, image=image2)
    bValue.image2 = image2
    cValue = image3
    cValue = Label(App, image=image3)
    cValue.image3 = image3
    dValue = image4
    dValue = Label(App, image=image4)
    dValue.image4 = image4
    eValue = image5
    eValue = Label(App, image=image5)
    eValue.image5 = image5
    fValue = image6
    fValue = Label(App, image=image6)
    fValue.image6 = image6
    gValue = image7
    gValue = Label(App, image=image7)
    gValue.image7 = image7
    hValue = image8
    hValue = Label(App, image=image8)
    hValue.image8 = image8
    iValue = image9
    iValue = Label(App, image=image9)
    iValue.image9 = image9
    jValue = image10
    jValue = Label(App, image=image10)
    jValue.image10 = image10
    kValue = image11
    kValue = Label(App, image=image11)
    kValue.image11 = image11
    lValue = image12
    lValue = Label(App, image=image12)
    lValue.image12 = image12
    mValue = image13
    mValue = Label(App, image=image13)
    mValue.image13 = image13
    nValue = image14
    nValue = Label(App, image=image14)
    nValue.image14 = image14


    za = []
    zb = []
    zc = []
    zd = []
    ze = []
    zf = []
    zg = []
    zh = []
    zi = []
    zj = []
    zk = []
    zl = []
    zm = []
    zn = []

    za = [value1, aValue, '\n']
    zb = [value2, bValue, '\n']
    zc = [value3, cValue, '\n']
    zd = [value4, dValue, '\n']
    ze = [value5, eValue, '\n']
    zf = [value6, fValue, '\n']
    zg = [value7, gValue, '\n']
    zh = [value8, hValue, '\n']
    zi = [value9, iValue, '\n']
    zj = [value10, jValue, '\n']
    zk = [value11, kValue, '\n']
    zl = [value12, lValue, '\n']
    zm = [value13, mValue, '\n']
    zn = [value14, nValue, '\n']

    ya = [za, zb, zc, zd, ze, zf, zg, zh, zi, zj, zk, zl, zm, zn]
    zzx = sorted(ya, key=itemgetter(0), reverse=False)
    zzz = zzx

    qa = zzx[0]
    qb = zzx[1]
    qc = zzx[2]
    qd = zzx[3]
    qe = zzx[4]
    qf = zzx[5]
    qg = zzx[6]
    qh = zzx[7]
    qi = zzx[8]
    qj = zzx[9]
    qk = zzx[10]
    ql = zzx[11]
    qm = zzx[12]
    qn = zzx[13]

    xa = qa[-2]
    xb = qb[-2]
    xc = qc[-2]
    xd = qd[-2]
    xe = qe[-2]
    xf = qf[-2]
    xg = qg[-2]
    xh = qh[-2]
    xi = qi[-2]
    xj = qj[-2]
    xk = qk[-2]
    xl = ql[-2]
    xm = qm[-2]
    xn = qn[-2]

    qq1 = xa
    qq2 = xb
    qq3 = xc
    qq4 = xd
    qq5 = xe
    qq6 = xf
    qq7 = xg
    qq8 = xh
    qq9 = xi
    qq10 = xj
    qq11 = xk
    qq12 = xl
    qq13 = xm
    qq14 = xn
    
    qq1.config(bg='#000000')
    qq1.grid(row=1, column=y)

    qq2.config(bg='#000000')
    qq2.grid(row=2, column=y)

    qq3.config(bg='#000000')
    qq3.grid(row=3, column=y)

    qq4.config(bg='#000000')
    qq4.grid(row=4, column=y)

    qq5.config(bg='#000000')
    qq5.grid(row=5, column=y)

    qq6.config(bg='#000000')
    qq6.grid(row=6, column=y)

    qq7.config(bg='#000000')
    qq7.grid(row=7, column=y)

    qq8.config(bg='#000000')
    qq8.grid(row=8, column=y)

    qq9.config(bg='#000000')
    qq9.grid(row=9, column=y)

    qq10.config(bg='#000000')
    qq10.grid(row=10, column=y)

    qq11.config(bg='#000000')
    qq11.grid(row=11, column=y)

    qq12.config(bg='#000000')
    qq12.grid(row=12, column=y)

    qq13.config(bg='#000000')
    qq13.grid(row=13, column=y)

    qq14.config(bg='#000000')
    qq14.grid(row=14, column=y)
    return
def uxghwa13():
    global qq1, qq2, qq3, qq4, qq5, qq6, qq7, qq8, qq9, qq10, qq11, qq12, qq13

    y = 1

    value1 = str(random.randint(0, 33))
    value2 = str(random.randint(0, 33))
    value3 = str(random.randint(0, 33))
    value4 = str(random.randint(0, 33))
    value5 = str(random.randint(0, 33))
    value6 = str(random.randint(0, 33))
    value7 = str(random.randint(0, 33))
    value8 = str(random.randint(0, 33))
    value9 = str(random.randint(0, 33))
    value10 = str(random.randint(0, 33))
    value11 = str(random.randint(0, 33))
    value12 = str(random.randint(0, 33))
    value13 = str(random.randint(0, 33))

    image1 = PhotoImage(file="0001.GIF", format="GIF")

    image2 = PhotoImage(file="0002.GIF", format="GIF")

    image3 = PhotoImage(file="0003.GIF", format="GIF")

    image4 = PhotoImage(file="0004.GIF", format="GIF")

    image5 = PhotoImage(file="0005.GIF", format="GIF")

    image6 = PhotoImage(file="0006.GIF", format="GIF")

    image7 = PhotoImage(file="0007.GIF", format="GIF")

    image8 = PhotoImage(file="0008.GIF", format="GIF")

    image9 = PhotoImage(file="0009.GIF", format="GIF")

    image10 = PhotoImage(file="0010.GIF", format="GIF")

    image11 = PhotoImage(file="0011.GIF", format="GIF")

    image12 = PhotoImage(file="0012.GIF", format="GIF")

    image13 = PhotoImage(file="0013.GIF", format="GIF")

    aValue = image1
    aValue = Label(App, image=image1)
    aValue.image1 = image1
    bValue = image2
    bValue = Label(App, image=image2)
    bValue.image2 = image2
    cValue = image3
    cValue = Label(App, image=image3)
    cValue.image3 = image3
    dValue = image4
    dValue = Label(App, image=image4)
    dValue.image4 = image4
    eValue = image5
    eValue = Label(App, image=image5)
    eValue.image5 = image5
    fValue = image6
    fValue = Label(App, image=image6)
    fValue.image6 = image6
    gValue = image7
    gValue = Label(App, image=image7)
    gValue.image7 = image7
    hValue = image8
    hValue = Label(App, image=image8)
    hValue.image8 = image8
    iValue = image9
    iValue = Label(App, image=image9)
    iValue.image9 = image9
    jValue = image10
    jValue = Label(App, image=image10)
    jValue.image10 = image10
    kValue = image11
    kValue = Label(App, image=image11)
    kValue.image11 = image11
    lValue = image12
    lValue = Label(App, image=image12)
    lValue.image12 = image12
    mValue = image13
    mValue = Label(App, image=image13)
    mValue.image13 = image13

    za = []
    zb = []
    zc = []
    zd = []
    ze = []
    zf = []
    zg = []
    zh = []
    zi = []
    zj = []
    zk = []
    zl = []
    zm = []

    za = [value1, aValue, '\n']
    zb = [value2, bValue, '\n']
    zc = [value3, cValue, '\n']
    zd = [value4, dValue, '\n']
    ze = [value5, eValue, '\n']
    zf = [value6, fValue, '\n']
    zg = [value7, gValue, '\n']
    zh = [value8, hValue, '\n']
    zi = [value9, iValue, '\n']
    zj = [value10, jValue, '\n']
    zk = [value11, kValue, '\n']
    zl = [value12, lValue, '\n']
    zm = [value13, mValue, '\n']

    ya = [za, zb, zc, zd, ze, zf, zg, zh, zi, zj, zk, zl, zm]
    zzx = sorted(ya, key=itemgetter(0), reverse=False)
    zzz = zzx

    qa = zzx[0]
    qb = zzx[1]
    qc = zzx[2]
    qd = zzx[3]
    qe = zzx[4]
    qf = zzx[5]
    qg = zzx[6]
    qh = zzx[7]
    qi = zzx[8]
    qj = zzx[9]
    qk = zzx[10]
    ql = zzx[11]
    qm = zzx[12]

    xa = qa[-2]
    xb = qb[-2]
    xc = qc[-2]
    xd = qd[-2]
    xe = qe[-2]
    xf = qf[-2]
    xg = qg[-2]
    xh = qh[-2]
    xi = qi[-2]
    xj = qj[-2]
    xk = qk[-2]
    xl = ql[-2]
    xm = qm[-2]

    qq1 = xa
    qq2 = xb
    qq3 = xc
    qq4 = xd
    qq5 = xe
    qq6 = xf
    qq7 = xg
    qq8 = xh
    qq9 = xi
    qq10 = xj
    qq11 = xk
    qq12 = xl
    qq13 = xm
    
    qq1.config(bg='#000000')
    qq1.grid(row=1, column=y)

    qq2.config(bg='#000000')
    qq2.grid(row=2, column=y)

    qq3.config(bg='#000000')
    qq3.grid(row=3, column=y)

    qq4.config(bg='#000000')
    qq4.grid(row=4, column=y)

    qq5.config(bg='#000000')
    qq5.grid(row=5, column=y)

    qq6.config(bg='#000000')
    qq6.grid(row=6, column=y)

    qq7.config(bg='#000000')
    qq7.grid(row=7, column=y)

    qq8.config(bg='#000000')
    qq8.grid(row=8, column=y)

    qq9.config(bg='#000000')
    qq9.grid(row=9, column=y)

    qq10.config(bg='#000000')
    qq10.grid(row=10, column=y)

    qq11.config(bg='#000000')
    qq11.grid(row=11, column=y)

    qq12.config(bg='#000000')
    qq12.grid(row=12, column=y)

    qq13.config(bg='#000000')
    qq13.grid(row=13, column=y)
    return
def uxghwa12():
    global qq1, qq2, qq3, qq4, qq5, qq6, qq7, qq8, qq9, qq10, qq11, qq12

    y = 1
    
    value1 = str(random.randint(0, 33))
    value2 = str(random.randint(0, 33))
    value3 = str(random.randint(0, 33))
    value4 = str(random.randint(0, 33))
    value5 = str(random.randint(0, 33))
    value6 = str(random.randint(0, 33))
    value7 = str(random.randint(0, 33))
    value8 = str(random.randint(0, 33))
    value9 = str(random.randint(0, 33))
    value10 = str(random.randint(0, 33))
    value11 = str(random.randint(0, 33))
    value12 = str(random.randint(0, 33))

    image1 = PhotoImage(file="0001.GIF", format="GIF")

    image2 = PhotoImage(file="0002.GIF", format="GIF")

    image3 = PhotoImage(file="0003.GIF", format="GIF")

    image4 = PhotoImage(file="0004.GIF", format="GIF")

    image5 = PhotoImage(file="0005.GIF", format="GIF")

    image6 = PhotoImage(file="0006.GIF", format="GIF")

    image7 = PhotoImage(file="0007.GIF", format="GIF")

    image8 = PhotoImage(file="0008.GIF", format="GIF")

    image9 = PhotoImage(file="0009.GIF", format="GIF")

    image10 = PhotoImage(file="0010.GIF", format="GIF")

    image11 = PhotoImage(file="0011.GIF", format="GIF")

    image12 = PhotoImage(file="0012.GIF", format="GIF")

    aValue = image1
    aValue = Label(App, image=image1)
    aValue.image1 = image1
    bValue = image2
    bValue = Label(App, image=image2)
    bValue.image2 = image2
    cValue = image3
    cValue = Label(App, image=image3)
    cValue.image3 = image3
    dValue = image4
    dValue = Label(App, image=image4)
    dValue.image4 = image4
    eValue = image5
    eValue = Label(App, image=image5)
    eValue.image5 = image5
    fValue = image6
    fValue = Label(App, image=image6)
    fValue.image6 = image6
    gValue = image7
    gValue = Label(App, image=image7)
    gValue.image7 = image7
    hValue = image8
    hValue = Label(App, image=image8)
    hValue.image8 = image8
    iValue = image9
    iValue = Label(App, image=image9)
    iValue.image9 = image9
    jValue = image10
    jValue = Label(App, image=image10)
    jValue.image10 = image10
    kValue = image11
    kValue = Label(App, image=image11)
    kValue.image11 = image11
    lValue = image12
    lValue = Label(App, image=image12)
    lValue.image12 = image12

    za = []
    zb = []
    zc = []
    zd = []
    ze = []
    zf = []
    zg = []
    zh = []
    zi = []
    zj = []
    zk = []
    zl = []

    za = [value1, aValue, '\n']
    zb = [value2, bValue, '\n']
    zc = [value3, cValue, '\n']
    zd = [value4, dValue, '\n']
    ze = [value5, eValue, '\n']
    zf = [value6, fValue, '\n']
    zg = [value7, gValue, '\n']
    zh = [value8, hValue, '\n']
    zi = [value9, iValue, '\n']
    zj = [value10, jValue, '\n']
    zk = [value11, kValue, '\n']
    zl = [value12, lValue, '\n']

    ya = [za, zb, zc, zd, ze, zf, zg, zh, zi, zj, zk, zl]
    zzx = sorted(ya, key=itemgetter(0), reverse=False)
    zzz = zzx

    qa = zzx[0]
    qb = zzx[1]
    qc = zzx[2]
    qd = zzx[3]
    qe = zzx[4]
    qf = zzx[5]
    qg = zzx[6]
    qh = zzx[7]
    qi = zzx[8]
    qj = zzx[9]
    qk = zzx[10]
    ql = zzx[11]

    xa = qa[-2]
    xb = qb[-2]
    xc = qc[-2]
    xd = qd[-2]
    xe = qe[-2]
    xf = qf[-2]
    xg = qg[-2]
    xh = qh[-2]
    xi = qi[-2]
    xj = qj[-2]
    xk = qk[-2]
    xl = ql[-2]

    qq1 = xa
    qq2 = xb
    qq3 = xc
    qq4 = xd
    qq5 = xe
    qq6 = xf
    qq7 = xg
    qq8 = xh
    qq9 = xi
    qq10 = xj
    qq11 = xk
    qq12 = xl
    
    qq1.config(bg='#000000')
    qq1.grid(row=1, column=y)

    qq2.config(bg='#000000')
    qq2.grid(row=2, column=y)

    qq3.config(bg='#000000')
    qq3.grid(row=3, column=y)

    qq4.config(bg='#000000')
    qq4.grid(row=4, column=y)

    qq5.config(bg='#000000')
    qq5.grid(row=5, column=y)

    qq6.config(bg='#000000')
    qq6.grid(row=6, column=y)

    qq7.config(bg='#000000')
    qq7.grid(row=7, column=y)

    qq8.config(bg='#000000')
    qq8.grid(row=8, column=y)

    qq9.config(bg='#000000')
    qq9.grid(row=9, column=y)

    qq10.config(bg='#000000')
    qq10.grid(row=10, column=y)

    qq11.config(bg='#000000')
    qq11.grid(row=11, column=y)

    qq12.config(bg='#000000')
    qq12.grid(row=12, column=y)
    return
def uxghwa11():
    global qq1, qq2, qq3, qq4, qq5, qq6, qq7, qq8, qq9, qq10, qq11

    y = 1
    
    value1 = str(random.randint(0, 33))
    value2 = str(random.randint(0, 33))
    value3 = str(random.randint(0, 33))
    value4 = str(random.randint(0, 33))
    value5 = str(random.randint(0, 33))
    value6 = str(random.randint(0, 33))
    value7 = str(random.randint(0, 33))
    value8 = str(random.randint(0, 33))
    value9 = str(random.randint(0, 33))
    value10 = str(random.randint(0, 33))
    value11 = str(random.randint(0, 33))

    image1 = PhotoImage(file="0001.GIF", format="GIF")

    image2 = PhotoImage(file="0002.GIF", format="GIF")

    image3 = PhotoImage(file="0003.GIF", format="GIF")

    image4 = PhotoImage(file="0004.GIF", format="GIF")

    image5 = PhotoImage(file="0005.GIF", format="GIF")

    image6 = PhotoImage(file="0006.GIF", format="GIF")

    image7 = PhotoImage(file="0007.GIF", format="GIF")

    image8 = PhotoImage(file="0008.GIF", format="GIF")

    image9 = PhotoImage(file="0009.GIF", format="GIF")

    image10 = PhotoImage(file="0010.GIF", format="GIF")

    image11 = PhotoImage(file="0011.GIF", format="GIF")

    aValue = image1
    aValue = Label(App, image=image1)
    aValue.image1 = image1
    bValue = image2
    bValue = Label(App, image=image2)
    bValue.image2 = image2
    cValue = image3
    cValue = Label(App, image=image3)
    cValue.image3 = image3
    dValue = image4
    dValue = Label(App, image=image4)
    dValue.image4 = image4
    eValue = image5
    eValue = Label(App, image=image5)
    eValue.image5 = image5
    fValue = image6
    fValue = Label(App, image=image6)
    fValue.image6 = image6
    gValue = image7
    gValue = Label(App, image=image7)
    gValue.image7 = image7
    hValue = image8
    hValue = Label(App, image=image8)
    hValue.image8 = image8
    iValue = image9
    iValue = Label(App, image=image9)
    iValue.image9 = image9
    jValue = image10
    jValue = Label(App, image=image10)
    jValue.image10 = image10
    kValue = image11
    kValue = Label(App, image=image11)
    kValue.image11 = image11

    za = []
    zb = []
    zc = []
    zd = []
    ze = []
    zf = []
    zg = []
    zh = []
    zi = []
    zj = []
    zk = []

    za = [value1, aValue, '\n']
    zb = [value2, bValue, '\n']
    zc = [value3, cValue, '\n']
    zd = [value4, dValue, '\n']
    ze = [value5, eValue, '\n']
    zf = [value6, fValue, '\n']
    zg = [value7, gValue, '\n']
    zh = [value8, hValue, '\n']
    zi = [value9, iValue, '\n']
    zj = [value10, jValue, '\n']
    zk = [value11, kValue, '\n']

    ya = [za, zb, zc, zd, ze, zf, zg, zh, zi, zj, zk]
    zzx = sorted(ya, key=itemgetter(0), reverse=False)
    zzz = zzx

    qa = zzx[0]
    qb = zzx[1]
    qc = zzx[2]
    qd = zzx[3]
    qe = zzx[4]
    qf = zzx[5]
    qg = zzx[6]
    qh = zzx[7]
    qi = zzx[8]
    qj = zzx[9]
    qk = zzx[10]

    xa = qa[-2]
    xb = qb[-2]
    xc = qc[-2]
    xd = qd[-2]
    xe = qe[-2]
    xf = qf[-2]
    xg = qg[-2]
    xh = qh[-2]
    xi = qi[-2]
    xj = qj[-2]
    xk = qk[-2]

    qq1 = xa
    qq2 = xb
    qq3 = xc
    qq4 = xd
    qq5 = xe
    qq6 = xf
    qq7 = xg
    qq8 = xh
    qq9 = xi
    qq10 = xj
    qq11 = xk
    
    qq1.config(bg='#000000')
    qq1.grid(row=1, column=y)

    qq2.config(bg='#000000')
    qq2.grid(row=2, column=y)

    qq3.config(bg='#000000')
    qq3.grid(row=3, column=y)

    qq4.config(bg='#000000')
    qq4.grid(row=4, column=y)

    qq5.config(bg='#000000')
    qq5.grid(row=5, column=y)

    qq6.config(bg='#000000')
    qq6.grid(row=6, column=y)

    qq7.config(bg='#000000')
    qq7.grid(row=7, column=y)

    qq8.config(bg='#000000')
    qq8.grid(row=8, column=y)

    qq9.config(bg='#000000')
    qq9.grid(row=9, column=y)

    qq10.config(bg='#000000')
    qq10.grid(row=10, column=y)

    qq11.config(bg='#000000')
    qq11.grid(row=11, column=y)
    return
def uxghwa10():
    global qq1, qq2, qq3, qq4, qq5, qq6, qq7, qq8, qq9, qq10

    y = 1

    value1 = str(random.randint(0, 33))
    value2 = str(random.randint(0, 33))
    value3 = str(random.randint(0, 33))
    value4 = str(random.randint(0, 33))
    value5 = str(random.randint(0, 33))
    value6 = str(random.randint(0, 33))
    value7 = str(random.randint(0, 33))
    value8 = str(random.randint(0, 33))
    value9 = str(random.randint(0, 33))
    value10 = str(random.randint(0, 33))

    image1 = PhotoImage(file="0001.GIF", format="GIF")

    image2 = PhotoImage(file="0002.GIF", format="GIF")

    image3 = PhotoImage(file="0003.GIF", format="GIF")

    image4 = PhotoImage(file="0004.GIF", format="GIF")

    image5 = PhotoImage(file="0005.GIF", format="GIF")

    image6 = PhotoImage(file="0006.GIF", format="GIF")

    image7 = PhotoImage(file="0007.GIF", format="GIF")

    image8 = PhotoImage(file="0008.GIF", format="GIF")

    image9 = PhotoImage(file="0009.GIF", format="GIF")

    image10 = PhotoImage(file="0010.GIF", format="GIF")


    aValue = image1
    aValue = Label(App, image=image1)
    aValue.image1 = image1
    bValue = image2
    bValue = Label(App, image=image2)
    bValue.image2 = image2
    cValue = image3
    cValue = Label(App, image=image3)
    cValue.image3 = image3
    dValue = image4
    dValue = Label(App, image=image4)
    dValue.image4 = image4
    eValue = image5
    eValue = Label(App, image=image5)
    eValue.image5 = image5
    fValue = image6
    fValue = Label(App, image=image6)
    fValue.image6 = image6
    gValue = image7
    gValue = Label(App, image=image7)
    gValue.image7 = image7
    hValue = image8
    hValue = Label(App, image=image8)
    hValue.image8 = image8
    iValue = image9
    iValue = Label(App, image=image9)
    iValue.image9 = image9
    jValue = image10
    jValue = Label(App, image=image10)
    jValue.image10 = image10

    za = []
    zb = []
    zc = []
    zd = []
    ze = []
    zf = []
    zg = []
    zh = []
    zi = []
    zj = []

    za = [value1, aValue, '\n']
    zb = [value2, bValue, '\n']
    zc = [value3, cValue, '\n']
    zd = [value4, dValue, '\n']
    ze = [value5, eValue, '\n']
    zf = [value6, fValue, '\n']
    zg = [value7, gValue, '\n']
    zh = [value8, hValue, '\n']
    zi = [value9, iValue, '\n']
    zj = [value10, jValue, '\n']

    ya = [za, zb, zc, zd, ze, zf, zg, zh, zi, zj]
    zzx = sorted(ya, key=itemgetter(0), reverse=False)
    zzz = zzx

    qa = zzx[0]
    qb = zzx[1]
    qc = zzx[2]
    qd = zzx[3]
    qe = zzx[4]
    qf = zzx[5]
    qg = zzx[6]
    qh = zzx[7]
    qi = zzx[8]
    qj = zzx[9]

    xa = qa[-2]
    xb = qb[-2]
    xc = qc[-2]
    xd = qd[-2]
    xe = qe[-2]
    xf = qf[-2]
    xg = qg[-2]
    xh = qh[-2]
    xi = qi[-2]
    xj = qj[-2]

    qq1 = xa
    qq2 = xb
    qq3 = xc
    qq4 = xd
    qq5 = xe
    qq6 = xf
    qq7 = xg
    qq8 = xh
    qq9 = xi
    qq10 = xj
    
    qq1.config(bg='#000000')
    qq1.grid(row=1, column=y)

    qq2.config(bg='#000000')
    qq2.grid(row=2, column=y)

    qq3.config(bg='#000000')
    qq3.grid(row=3, column=y)

    qq4.config(bg='#000000')
    qq4.grid(row=4, column=y)

    qq5.config(bg='#000000')
    qq5.grid(row=5, column=y)

    qq6.config(bg='#000000')
    qq6.grid(row=6, column=y)

    qq7.config(bg='#000000')
    qq7.grid(row=7, column=y)

    qq8.config(bg='#000000')
    qq8.grid(row=8, column=y)

    qq9.config(bg='#000000')
    qq9.grid(row=9, column=y)

    qq10.config(bg='#000000')
    qq10.grid(row=10, column=y)
    return
def uxghwa9():
    global qq1, qq2, qq3, qq4, qq5, qq6, qq7, qq8, qq9

    y = 1
    
    value1 = str(random.randint(0, 33))
    value2 = str(random.randint(0, 33))
    value3 = str(random.randint(0, 33))
    value4 = str(random.randint(0, 33))
    value5 = str(random.randint(0, 33))
    value6 = str(random.randint(0, 33))
    value7 = str(random.randint(0, 33))
    value8 = str(random.randint(0, 33))
    value9 = str(random.randint(0, 33))

    image1 = PhotoImage(file="0001.GIF", format="GIF")

    image2 = PhotoImage(file="0002.GIF", format="GIF")

    image3 = PhotoImage(file="0003.GIF", format="GIF")

    image4 = PhotoImage(file="0004.GIF", format="GIF")

    image5 = PhotoImage(file="0005.GIF", format="GIF")

    image6 = PhotoImage(file="0006.GIF", format="GIF")

    image7 = PhotoImage(file="0007.GIF", format="GIF")

    image8 = PhotoImage(file="0008.GIF", format="GIF")

    image9 = PhotoImage(file="0009.GIF", format="GIF")

    aValue = image1
    aValue = Label(App, image=image1)
    aValue.image1 = image1
    bValue = image2
    bValue = Label(App, image=image2)
    bValue.image2 = image2
    cValue = image3
    cValue = Label(App, image=image3)
    cValue.image3 = image3
    dValue = image4
    dValue = Label(App, image=image4)
    dValue.image4 = image4
    eValue = image5
    eValue = Label(App, image=image5)
    eValue.image5 = image5
    fValue = image6
    fValue = Label(App, image=image6)
    fValue.image6 = image6
    gValue = image7
    gValue = Label(App, image=image7)
    gValue.image7 = image7
    hValue = image8
    hValue = Label(App, image=image8)
    hValue.image8 = image8
    iValue = image9
    iValue = Label(App, image=image9)
    iValue.image9 = image9

    za = []
    zb = []
    zc = []
    zd = []
    ze = []
    zf = []
    zg = []
    zh = []
    zi = []

    za = [value1, aValue, '\n']
    zb = [value2, bValue, '\n']
    zc = [value3, cValue, '\n']
    zd = [value4, dValue, '\n']
    ze = [value5, eValue, '\n']
    zf = [value6, fValue, '\n']
    zg = [value7, gValue, '\n']
    zh = [value8, hValue, '\n']
    zi = [value9, iValue, '\n']

    ya = [za, zb, zc, zd, ze, zf, zg, zh, zi]
    zzx = sorted(ya, key=itemgetter(0), reverse=False)
    zzz = zzx

    qa = zzx[0]
    qb = zzx[1]
    qc = zzx[2]
    qd = zzx[3]
    qe = zzx[4]
    qf = zzx[5]
    qg = zzx[6]
    qh = zzx[7]
    qi = zzx[8]

    xa = qa[-2]
    xb = qb[-2]
    xc = qc[-2]
    xd = qd[-2]
    xe = qe[-2]
    xf = qf[-2]
    xg = qg[-2]
    xh = qh[-2]
    xi = qi[-2]

    qq1 = xa
    qq2 = xb
    qq3 = xc
    qq4 = xd
    qq5 = xe
    qq6 = xf
    qq7 = xg
    qq8 = xh
    qq9 = xi
    
    qq1.config(bg='#000000')
    qq1.grid(row=1, column=y)

    qq2.config(bg='#000000')
    qq2.grid(row=2, column=y)

    qq3.config(bg='#000000')
    qq3.grid(row=3, column=y)

    qq4.config(bg='#000000')
    qq4.grid(row=4, column=y)

    qq5.config(bg='#000000')
    qq5.grid(row=5, column=y)

    qq6.config(bg='#000000')
    qq6.grid(row=6, column=y)

    qq7.config(bg='#000000')
    qq7.grid(row=7, column=y)

    qq8.config(bg='#000000')
    qq8.grid(row=8, column=y)

    qq9.config(bg='#000000')
    qq9.grid(row=9, column=y)
    return
    

def uxghwa8():
    global qq1, qq2, qq3, qq4, qq5, qq6, qq7, qq8

    y = 1

    value1 = str(random.randint(0, 33))
    value2 = str(random.randint(0, 33))
    value3 = str(random.randint(0, 33))
    value4 = str(random.randint(0, 33))
    value5 = str(random.randint(0, 33))
    value6 = str(random.randint(0, 33))
    value7 = str(random.randint(0, 33))
    value8 = str(random.randint(0, 33))

    image1 = PhotoImage(file="0001.GIF", format="GIF")

    image2 = PhotoImage(file="0002.GIF", format="GIF")

    image3 = PhotoImage(file="0003.GIF", format="GIF")

    image4 = PhotoImage(file="0004.GIF", format="GIF")

    image5 = PhotoImage(file="0005.GIF", format="GIF")

    image6 = PhotoImage(file="0006.GIF", format="GIF")

    image7 = PhotoImage(file="0007.GIF", format="GIF")

    image8 = PhotoImage(file="0008.GIF", format="GIF")

    aValue = image1
    aValue = Label(App, image=image1)
    aValue.image1 = image1
    bValue = image2
    bValue = Label(App, image=image2)
    bValue.image2 = image2
    cValue = image3
    cValue = Label(App, image=image3)
    cValue.image3 = image3
    dValue = image4
    dValue = Label(App, image=image4)
    dValue.image4 = image4
    eValue = image5
    eValue = Label(App, image=image5)
    eValue.image5 = image5
    fValue = image6
    fValue = Label(App, image=image6)
    fValue.image6 = image6
    gValue = image7
    gValue = Label(App, image=image7)
    gValue.image7 = image7
    hValue = image8
    hValue = Label(App, image=image8)
    hValue.image8 = image8

    za = []
    zb = []
    zc = []
    zd = []
    ze = []
    zf = []
    zg = []
    zh = []

    za = [value1, aValue, '\n']
    zb = [value2, bValue, '\n']
    zc = [value3, cValue, '\n']
    zd = [value4, dValue, '\n']
    ze = [value5, eValue, '\n']
    zf = [value6, fValue, '\n']
    zg = [value7, gValue, '\n']
    zh = [value8, hValue, '\n']
    ya = [za, zb, zc, zd, ze, zf, zg, zh]
    zzx = sorted(ya, key=itemgetter(0), reverse=False)
    zzz = zzx

    qa = zzx[0]
    qb = zzx[1]
    qc = zzx[2]
    qd = zzx[3]
    qe = zzx[4]
    qf = zzx[5]
    qg = zzx[6]
    qh = zzx[7]

    xa = qa[-2]
    xb = qb[-2]
    xc = qc[-2]
    xd = qd[-2]
    xe = qe[-2]
    xf = qf[-2]
    xg = qg[-2]
    xh = qh[-2]

    qq1 = xa
    qq2 = xb
    qq3 = xc
    qq4 = xd
    qq5 = xe
    qq6 = xf
    qq7 = xg
    qq8 = xh
    
    qq1.config(bg='#000000')
    qq1.grid(row=1, column=y)

    qq2.config(bg='#000000')
    qq2.grid(row=2, column=y)

    qq3.config(bg='#000000')
    qq3.grid(row=3, column=y)

    qq4.config(bg='#000000')
    qq4.grid(row=4, column=y)

    qq5.config(bg='#000000')
    qq5.grid(row=5, column=y)

    qq6.config(bg='#000000')
    qq6.grid(row=6, column=y)

    qq7.config(bg='#000000')
    qq7.grid(row=7, column=y)

    qq8.config(bg='#000000')
    qq8.grid(row=8, column=y)
    return
def uxghwa7():
    global qq1, qq2, qq3, qq4, qq5, qq6, qq7

    y = 1
    
    value1 = str(random.randint(0, 33))
    value2 = str(random.randint(0, 33))
    value3 = str(random.randint(0, 33))
    value4 = str(random.randint(0, 33))
    value5 = str(random.randint(0, 33))
    value6 = str(random.randint(0, 33))
    value7 = str(random.randint(0, 33))

    image1 = PhotoImage(file="0001.GIF", format="GIF")

    image2 = PhotoImage(file="0002.GIF", format="GIF")

    image3 = PhotoImage(file="0003.GIF", format="GIF")

    image4 = PhotoImage(file="0004.GIF", format="GIF")

    image5 = PhotoImage(file="0005.GIF", format="GIF")

    image6 = PhotoImage(file="0006.GIF", format="GIF")

    image7 = PhotoImage(file="0007.GIF", format="GIF")

    aValue = image1
    aValue = Label(App, image=image1)
    aValue.image1 = image1
    bValue = image2
    bValue = Label(App, image=image2)
    bValue.image2 = image2
    cValue = image3
    cValue = Label(App, image=image3)
    cValue.image3 = image3
    dValue = image4
    dValue = Label(App, image=image4)
    dValue.image4 = image4
    eValue = image5
    eValue = Label(App, image=image5)
    eValue.image5 = image5
    fValue = image6
    fValue = Label(App, image=image6)
    fValue.image6 = image6
    gValue = image7
    gValue = Label(App, image=image7)
    gValue.image7 = image7

    za = []
    zb = []
    zc = []
    zd = []
    ze = []
    zf = []
    zg = []

    za = [value1, aValue, '\n']
    zb = [value2, bValue, '\n']
    zc = [value3, cValue, '\n']
    zd = [value4, dValue, '\n']
    ze = [value5, eValue, '\n']
    zf = [value6, fValue, '\n']
    zg = [value7, gValue, '\n']

    ya = [za, zb, zc, zd, ze, zf, zg]
    zzx = sorted(ya, key=itemgetter(0), reverse=False)
    zzz = zzx

    qa = zzx[0]
    qb = zzx[1]
    qc = zzx[2]
    qd = zzx[3]
    qe = zzx[4]
    qf = zzx[5]
    qg = zzx[6]

    xa = qa[-2]
    xb = qb[-2]
    xc = qc[-2]
    xd = qd[-2]
    xe = qe[-2]
    xf = qf[-2]
    xg = qg[-2]

    qq1 = xa
    qq2 = xb
    qq3 = xc
    qq4 = xd
    qq5 = xe
    qq6 = xf
    qq7 = xg

    qq1.config(bg='#000000')
    qq1.grid(row=1, column=y)

    qq2.config(bg='#000000')
    qq2.grid(row=2, column=y)

    qq3.config(bg='#000000')
    qq3.grid(row=3, column=y)

    qq4.config(bg='#000000')
    qq4.grid(row=4, column=y)

    qq5.config(bg='#000000')
    qq5.grid(row=5, column=y)

    qq6.config(bg='#000000')
    qq6.grid(row=6, column=y)

    qq7.config(bg='#000000')
    qq7.grid(row=7, column=y)
    return

y = 0

def qzz1():
    qq1.destroy()
    return
qq1 = Button(App, width=10, text='Delete', command=qzz1)
qq1.config(bg='#000000', fg='#ffffff')
qq1.grid(row=1, column=y)
def qzz2():
    qq2.destroy()
    return
qq2 = Button(App, width=10, text='Delete', command=qzz2)
qq2.config(bg='#000000', fg='#ffffff')
qq2.grid(row=2, column=y)
def qzz3():
    qq3.destroy()
    return
qq3 = Button(App, width=10, text='Delete', command=qzz3)
qq3.config(bg='#000000', fg='#ffffff')
qq3.grid(row=3, column=y)
def qzz4():
    qq4.destroy()
    return
qq4 = Button(App, width=10, text='Delete', command=qzz4)
qq4.config(bg='#000000', fg='#ffffff')
qq4.grid(row=4, column=y)
def qzz5():
    qq5.destroy()
    return
qq5 = Button(App, width=10, text='Delete', command=qzz5)
qq5.config(bg='#000000', fg='#ffffff')
qq5.grid(row=5, column=y)
def qzz6():
    qq6.destroy()
    return
qq6 = Button(App, width=10, text='Delete', command=qzz6)
qq6.config(bg='#000000', fg='#ffffff')
qq6.grid(row=6, column=y)
def qzz7():
    qq7.destroy()
    return
qq7 = Button(App, width=10, text='Delete', command=qzz7)
qq7.config(bg='#000000', fg='#ffffff')
qq7.grid(row=7, column=y)
def qzz8():
    qq8.destroy()
    return
qq8 = Button(App, width=10, text='Delete', command=qzz8)
qq8.config(bg='#000000', fg='#ffffff')
qq8.grid(row=8, column=y)
def qzz9():
    qq9.destroy()
    return
qq9 = Button(App, width=10, text='Delete', command=qzz9)
qq9.config(bg='#000000', fg='#ffffff')
qq9.grid(row=9, column=y)
def qzz10():
    qq10.destroy()
    return
qq10 = Button(App, width=10, text='Delete', command=qzz10)
qq10.config(bg='#000000', fg='#ffffff')
qq10.grid(row=10, column=y)
def qzz11():
    qq11.destroy()
    return
qq11 = Button(App, width=10, text='Delete', command=qzz11)
qq11.config(bg='#000000', fg='#ffffff')
qq11.grid(row=11, column=y)
def qzz12():
    qq12.destroy()
    return
qq12 = Button(App, width=10, text='Delete', command=qzz12)
qq12.config(bg='#000000', fg='#ffffff')
qq12.grid(row=12, column=y)
def qzz13():
    qq13.destroy()
    return
qq13 = Button(App, width=10, text='Delete', command=qzz13)
qq13.config(bg='#000000', fg='#ffffff')
qq13.grid(row=13, column=y)
def qzz14():
    qq14.destroy()
    return
qq14 = Button(App, width=10, text='Delete', command=qzz14)
qq14.config(bg='#000000', fg='#ffffff')
qq14.grid(row=14, column=y)
def qzz15():
    qq15.destroy()
    return
qq15 = Button(App, width=10, text='Delete', command=qzz15)
qq15.config(bg='#000000', fg='#ffffff')
qq15.grid(row=15, column=y)
def qzz16():
    qq16.destroy()
    return

qq16 = Button(App, width=10, text='Delete', command=qzz16)
qq16.config(bg='#000000', fg='#ffffff')
qq16.grid(row=16, column=y)

qq17 = Button(App, width=16, text="7 Lines", command=uxghwa7)
qq17.config(bg='#001222', fg='#ffffff')
qq17.grid(row=17, column=y)

qq18 = Button(App, width=16, text="8 Lines", command=uxghwa8)
qq18.config(bg='#001222', fg='#ffffff')
qq18.grid(row=18, column=y)

qq19 = Button(App, width=16, text="9 Lines", command=uxghwa9)
qq19.config(bg='#001222', fg='#ffffff')
qq19.grid(row=19, column=y)

qq20 = Button(App, width=16, text="10 Lines", command=uxghwa10)
qq20.config(bg='#001222', fg='#ffffff')
qq20.grid(row=20, column=y)

qq21 = Button(App, width=16, text="11 Lines", command=uxghwa11)
qq21.config(bg='#001222', fg='#ffffff')
qq21.grid(row=21, column=y)

qq22 = Button(App, width=16, text="12 Lines", command=uxghwa12)
qq22.config(bg='#001222', fg='#ffffff')
qq22.grid(row=22, column=y)

qq23 = Button(App, width=16, text="13 Lines", command=uxghwa13)
qq23.config(bg='#001222', fg='#ffffff')
qq23.grid(row=23, column=y)

qq24 = Button(App, width=16, text="14 Lines", command=uxghwa14)
qq24.config(bg='#001222', fg='#ffffff')
qq24.grid(row=24, column=y)

qq25 = Button(App, width=16, text="15 Lines", command=uxghwa15)
qq25.config(bg='#001222', fg='#ffffff')
qq25.grid(row=25, column=y)

qq26 = Button(App, width=16, text="16 Lines", command=uxghwa16)
qq26.config(bg='#001222', fg='#ffffff')
qq26.grid(row=26, column=y)

App.mainloop()
