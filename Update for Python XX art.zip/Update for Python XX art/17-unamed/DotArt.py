from tkinter import *
import tkinter as tk
import random
from operator import itemgetter

def thisFunction():
    global qq1, qq2, qq3, qq4, qq5, qq6, qq7, qq8, qq9, qq10, qq11, qq12, qq13, qq14, qq15, qq16, qq17
   
    value1 = str(random.randint(0, 33))
    value2 = str(random.randint(0, 33))
    value3 = str(random.randint(0, 33))
    value4 = str(random.randint(0, 33))
    value5 = str(random.randint(0, 33))
    value6 = str(random.randint(0, 33))
    value7 = str(random.randint(0, 33))
    value8 = str(random.randint(0, 33))
    value9 = str(random.randint(0, 33))
    value10 = str(random.randint(0, 33))
    value11 = str(random.randint(0, 33))
    value12 = str(random.randint(0, 33))
    value13 = str(random.randint(0, 33))
    value14 = str(random.randint(0, 33))
    value15 = str(random.randint(0, 33))
    value16 = str(random.randint(0, 33))
    value17 = str(random.randint(0, 33))

    image1 = PhotoImage(file="0001.GIF", format="GIF")

    image2 = PhotoImage(file="0002.GIF", format="GIF")

    image3 = PhotoImage(file="0003.GIF", format="GIF")

    image4 = PhotoImage(file="0004.GIF", format="GIF")

    image5 = PhotoImage(file="0005.GIF", format="GIF")

    image6 = PhotoImage(file="0006.GIF", format="GIF")

    image7 = PhotoImage(file="0007.GIF", format="GIF")

    image8 = PhotoImage(file="0008.GIF", format="GIF")

    image9 = PhotoImage(file="0009.GIF", format="GIF")

    image10 = PhotoImage(file="0010.GIF", format="GIF")

    image11 = PhotoImage(file="0011.GIF", format="GIF")

    image12 = PhotoImage(file="0012.GIF", format="GIF")

    image13 = PhotoImage(file="0013.GIF", format="GIF")

    image14 = PhotoImage(file="0014.GIF", format="GIF")

    image15 = PhotoImage(file="0015.GIF", format="GIF")

    image16 = PhotoImage(file="0016.GIF", format="GIF")

    image17 = PhotoImage(file="0017.GIF", format="GIF")

    aValue = image1
    aValue = Label(App, image=image1)
    aValue.image1 = image1
    bValue = image2
    bValue = Label(App, image=image2)
    bValue.image2 = image2
    cValue = image3
    cValue = Label(App, image=image3)
    cValue.image3 = image3
    dValue = image4
    dValue = Label(App, image=image4)
    dValue.image4 = image4
    eValue = image5
    eValue = Label(App, image=image5)
    eValue.image5 = image5
    fValue = image6
    fValue = Label(App, image=image6)
    fValue.image6 = image6
    gValue = image7
    gValue = Label(App, image=image7)
    gValue.image7 = image7
    hValue = image8
    hValue = Label(App, image=image8)
    hValue.image8 = image8
    iValue = image9
    iValue = Label(App, image=image9)
    iValue.image9 = image9
    jValue = image10
    jValue = Label(App, image=image10)
    jValue.image10 = image10
    kValue = image11
    kValue = Label(App, image=image11)
    kValue.image11 = image11
    lValue = image12
    lValue = Label(App, image=image12)
    lValue.image12 = image12
    mValue = image13
    mValue = Label(App, image=image13)
    mValue.image13 = image13
    nValue = image14
    nValue = Label(App, image=image14)
    nValue.image14 = image14
    oValue = image15
    oValue = Label(App, image=image15)
    oValue.image15 = image15
    pValue = image16
    pValue = Label(App, image=image16)
    pValue.image16 = image16
    qValue = image17
    qValue = Label(App, image=image17)
    qValue.image17 = image17	

    za = []
    zb = []
    zc = []
    zd = []
    ze = []
    zf = []
    zg = []
    zh = []
    zi = []
    zj = []
    zk = []
    zl = []
    zm = []
    zn = []
    zo = []
    zp = []
    zq = []

    za = [value1, aValue, '\n']
    zb = [value2, bValue, '\n']
    zc = [value3, cValue, '\n']
    zd = [value4, dValue, '\n']
    ze = [value5, eValue, '\n']
    zf = [value6, fValue, '\n']
    zg = [value7, gValue, '\n']
    zh = [value8, hValue, '\n']
    zi = [value9, iValue, '\n']
    zj = [value10, jValue, '\n']
    zk = [value11, kValue, '\n']
    zl = [value12, lValue, '\n']
    zm = [value13, mValue, '\n']
    zn = [value14, nValue, '\n']
    zo = [value15, oValue, '\n']
    zp = [value16, pValue, '\n']
    zq = [value17, qValue, '\n']
    ya = [za, zb, zc, zd, ze, zf, zg, zh, zi, zj, zk, zl, zm, zn, zo, zp, zq]
    zzx = sorted(ya, key=itemgetter(0), reverse=False)
    zzz = zzx

    qa = zzx[0]
    qb = zzx[1]
    qc = zzx[2]
    qd = zzx[3]
    qe = zzx[4]
    qf = zzx[5]
    qg = zzx[6]
    qh = zzx[7]
    qi = zzx[8]
    qj = zzx[9]
    qk = zzx[10]
    ql = zzx[11]
    qm = zzx[12]
    qn = zzx[13]
    qo = zzx[14]
    qp = zzx[15]
    qq = zzx[16]

    xa = qa[-2]
    xb = qb[-2]
    xc = qc[-2]
    xd = qd[-2]
    xe = qe[-2]
    xf = qf[-2]
    xg = qg[-2]
    xh = qh[-2]
    xi = qi[-2]
    xj = qj[-2]
    xk = qk[-2]
    xl = ql[-2]
    xm = qm[-2]
    xn = qn[-2]
    xo = qo[-2]
    xp = qp[-2]
    xq = qq[-2]

    qq1 = xa
    qq2 = xb
    qq3 = xc
    qq4 = xd
    qq5 = xe
    qq6 = xf
    qq7 = xg
    qq8 = xh
    qq9 = xi
    qq10 = xj
    qq11 = xk
    qq12 = xl
    qq13 = xm
    qq14 = xn
    qq15 = xo
    qq16 = xp
    qq17 = xq
    
    y = 1

    qq1.config(bg='#000000')
    qq1.grid(row=1, column=y)

    qq2.config(bg='#000000')
    qq2.grid(row=2, column=y)

    qq3.config(bg='#000000')
    qq3.grid(row=3, column=y)

    qq4.config(bg='#000000')
    qq4.grid(row=4, column=y)

    qq5.config(bg='#000000')
    qq5.grid(row=5, column=y)

    qq6.config(bg='#000000')
    qq6.grid(row=6, column=y)

    qq7.config(bg='#000000')
    qq7.grid(row=7, column=y)

    qq8.config(bg='#000000')
    qq8.grid(row=8, column=y)

    qq9.config(bg='#000000')
    qq9.grid(row=9, column=y)

    qq10.config(bg='#000000')
    qq10.grid(row=10, column=y)

    qq11.config(bg='#000000')
    qq11.grid(row=11, column=y)

    qq12.config(bg='#000000')
    qq12.grid(row=12, column=y)

    qq13.config(bg='#000000')
    qq13.grid(row=13, column=y)

    qq14.config(bg='#000000')
    qq14.grid(row=14, column=y)

    qq15.config(bg='#000000')
    qq15.grid(row=15, column=y)

    qq16.config(bg='#000000')
    qq16.grid(row=16, column=y)

    qq17.config(bg='#000000')
    qq17.grid(row=17, column=y)

    return

App = Tk()
App.config(bg="#000000")

updateB_text = Button(App, command=thisFunction, text="REARRANGE")
updateB_text.grid(row=0, column=0)

y = 0

def qz1():
    qq1.destroy()
    return
qq1 = Button(App, width=10, text='Delete', command=qz1)
qq1.config(bg='#000000')
qq1.grid(row=1, column=y)
def qz2():
    qq2.destroy()
    return
qq2 = Button(App, width=10, text='Delete', command=qz2)
qq2.config(bg='#000000')
qq2.grid(row=2, column=y)
def qz3():
    qq3.destroy()
    return
qq3 = Button(App, width=10, text='Delete', command=qz3)
qq3.config(bg='#000000')
qq3.grid(row=3, column=y)
def qz4():
    qq4.destroy()
    return
qq4 = Button(App, width=10, text='Delete', command=qz4)
qq4.config(bg='#000000')
qq4.grid(row=4, column=y)
def qz5():
    qq5.destroy()
    return
qq5 = Button(App, width=10, text='Delete', command=qz5)
qq5.config(bg='#000000')
qq5.grid(row=5, column=y)
def qz6():
    qq6.destroy()
    return
qq6 = Button(App, width=10, text='Delete', command=qz6)
qq6.config(bg='#000000')
qq6.grid(row=6, column=y)
def qz7():
    qq7.destroy()
    return
qq7 = Button(App, width=10, text='Delete', command=qz7)
qq7.config(bg='#000000')
qq7.grid(row=7, column=y)
def qz8():
    qq8.destroy()
    return
qq8 = Button(App, width=10, text='Delete', command=qz8)
qq8.config(bg='#000000')
qq8.grid(row=8, column=y)
def qz9():
    qq9.destroy()
    return
qq9 = Button(App, width=10, text='Delete', command=qz9)
qq9.config(bg='#000000')
qq9.grid(row=9, column=y)
def qz10():
    qq10.destroy()
    return
qq10 = Button(App, width=10, text='Delete', command=qz10)
qq10.config(bg='#000000')
qq10.grid(row=10, column=y)
def qz11():
    qq11.destroy()
    return
qq11 = Button(App, width=10, text='Delete', command=qz11)
qq11.config(bg='#000000')
qq11.grid(row=11, column=y)
def qz12():
    qq12.destroy()
    return
qq12 = Button(App, width=10, text='Delete', command=qz12)
qq12.config(bg='#000000')
qq12.grid(row=12, column=y)
def qz13():
    qq13.destroy()
    return
qq13 = Button(App, width=10, text='Delete', command=qz13)
qq13.config(bg='#000000')
qq13.grid(row=13, column=y)
def qz14():
    qq14.destroy()
    return
qq14 = Button(App, width=10, text='Delete', command=qz14)
qq14.config(bg='#000000')
qq14.grid(row=14, column=y)
def qz15():
    qq15.destroy()
    return
qq15 = Button(App, width=10, text='Delete', command=qz15)
qq15.config(bg='#000000')
qq15.grid(row=15, column=y)
def qz16():
    qq16.destroy()
    return
qq16 = Button(App, width=10, text='Delete', command=qz16)
qq16.config(bg='#000000')
qq16.grid(row=16, column=y)
def qz17():
    qq17.destroy()
    return
qq17 = Button(App, width=10, text='Delete', command=qz17)
qq17.config(bg='#000000')
qq17.grid(row=17, column=y)

App.mainloop()
