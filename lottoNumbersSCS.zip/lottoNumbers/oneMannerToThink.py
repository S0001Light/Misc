b = 1
for b in range(0, 81):
    print((str(b) + ',')*80)
