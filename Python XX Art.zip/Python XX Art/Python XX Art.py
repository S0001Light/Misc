from tkinter import *
import tkinter as tk
import random
from operator import itemgetter

def aFunction():

    global sa, sb, sc, sd, se, sf, sg, sh, si, sj, sk
       
    if sa:
        sa.destroy()
    if sb:
        sb.destroy()
    if sc:
        sc.destroy()
    if sd:
        sd.destroy()
    if se:
        se.destroy()
    if sf:
        sf.destroy()
    if sg:
        sg.destroy()
    if sh:
        sh.destroy()
    if si:
        si.destroy()
    if sj:
        sj.destroy()
    if sk:
        sk.destroy()
   
    value1 = str(random.randint(0, 11))
    value2 = str(random.randint(0, 11))
    value3 = str(random.randint(0, 11))
    value4 = str(random.randint(0, 11))
    value5 = str(random.randint(0, 11))
    value6 = str(random.randint(0, 11))
    value7 = str(random.randint(0, 11))
    value8 = str(random.randint(0, 11))
    value9 = str(random.randint(0, 11))
    value10 = str(random.randint(0, 11))
    value11 = str(random.randint(0, 11))

    image1 = PhotoImage(file="0001.GIF", format="GIF")

    image2 = PhotoImage(file="0002.GIF", format="GIF")

    image3 = PhotoImage(file="0003.GIF", format="GIF")

    image4 = PhotoImage(file="0004.GIF", format="GIF")

    image5 = PhotoImage(file="0005.GIF", format="GIF")

    image6 = PhotoImage(file="0006.GIF", format="GIF")

    image7 = PhotoImage(file="0007.GIF", format="GIF")

    image8 = PhotoImage(file="0008.GIF", format="GIF")

    image9 = PhotoImage(file="0009.GIF", format="GIF")

    image10 = PhotoImage(file="0010.GIF", format="GIF")

    image11 = PhotoImage(file="0011.GIF", format="GIF")


    aValue = image1
    aValue = Label(App, image=image1)
    aValue.image1 = image1
    bValue = image2
    bValue = Label(App, image=image2)
    bValue.image2 = image2
    cValue = image3
    cValue = Label(App, image=image3)
    cValue.image3 = image3
    dValue = image4
    dValue = Label(App, image=image4)
    dValue.image4 = image4
    eValue = image5
    eValue = Label(App, image=image5)
    eValue.image5 = image5
    fValue = image6
    fValue = Label(App, image=image6)
    fValue.image6 = image6
    gValue = image7
    gValue = Label(App, image=image7)
    gValue.image7 = image7
    hValue = image8
    hValue = Label(App, image=image8)
    hValue.image8 = image8
    iValue = image9
    iValue = Label(App, image=image9)
    iValue.image9 = image9
    jValue = image10
    jValue = Label(App, image=image10)
    jValue.image10 = image10
    kValue = image11
    kValue = Label(App, image=image11)
    kValue.image11 = image11

    za = []
    zb = []
    zc = []
    zd = []
    ze = []
    zf = []
    zg = []
    zh = []
    zi = []
    zj = []
    zk = []

    za = [value1, aValue, '\n']
    zb = [value2, bValue, '\n']
    zc = [value3, cValue, '\n']
    zd = [value4, dValue, '\n']
    ze = [value5, eValue, '\n']
    zf = [value6, fValue, '\n']
    zg = [value7, gValue, '\n']
    zh = [value8, hValue, '\n']
    zi = [value9, iValue, '\n']
    zj = [value10, jValue, '\n']
    zk = [value11, kValue, '\n']
    ya = [za, zb, zc, zd, ze, zf, zg, zh, zi, zj, zk]
    zzx = sorted(ya, key=itemgetter(0), reverse=False)
    zzz = zzx

    qa = zzx[0]
    qb = zzx[1]
    qc = zzx[2]
    qd = zzx[3]
    qe = zzx[4]
    qf = zzx[5]
    qg = zzx[6]
    qh = zzx[7]
    qi = zzx[8]
    qj = zzx[9]
    qk = zzx[10]

    xa = qa[-2]
    xb = qb[-2]
    xc = qc[-2]
    xd = qd[-2]
    xe = qe[-2]
    xf = qf[-2]
    xg = qg[-2]
    xh = qh[-2]
    xi = qi[-2]
    xj = qj[-2]
    xk = qk[-2]

    sa = xa
    sb = xb
    sc = xc
    sd = xd
    se = xe
    sf = xf
    sg = xg
    sh = xh
    si = xi
    sj = xj
    sk = xk

    sa.config(bg="#000000")
    sa.grid(row=1, column=0)
    sb.config(bg="#000000")
    sb.grid(row=2, column=0)
    sc.config(bg="#000000")
    sc.grid(row=3, column=0)
    sd.config(bg="#000000")
    sd.grid(row=4, column=0)
    se.config(bg="#000000")
    se.grid(row=5, column=0)
    sf.config(bg="#000000")
    sf.grid(row=6, column=0)
    sg.config(bg="#000000")
    sg.grid(row=7, column=0)
    sh.config(bg="#000000")
    sh.grid(row=8, column=0)
    si.config(bg="#000000")
    si.grid(row=9, column=0)
    sj.config(bg="#000000")
    sj.grid(row=10, column=0)
    sk.config(bg="#000000")
    sk.grid(row=11, column=0)

    return

def bFunction():
    
    global sa, sb, sc, sd, se, sf, sg, sh, si, sj, sk
   
    value1 = str(random.randint(0, 11))
    value2 = str(random.randint(0, 11))
    value3 = str(random.randint(0, 11))
    value4 = str(random.randint(0, 11))
    value5 = str(random.randint(0, 11))
    value6 = str(random.randint(0, 11))
    value7 = str(random.randint(0, 11))
    value8 = str(random.randint(0, 11))
    value9 = str(random.randint(0, 11))
    value10 = str(random.randint(0, 11))
    value11 = str(random.randint(0, 11))

    image1 = PhotoImage(file="0001.GIF", format="GIF")

    image2 = PhotoImage(file="0002.GIF", format="GIF")

    image3 = PhotoImage(file="0003.GIF", format="GIF")

    image4 = PhotoImage(file="0004.GIF", format="GIF")

    image5 = PhotoImage(file="0005.GIF", format="GIF")

    image6 = PhotoImage(file="0006.GIF", format="GIF")

    image7 = PhotoImage(file="0007.GIF", format="GIF")

    image8 = PhotoImage(file="0008.GIF", format="GIF")

    image9 = PhotoImage(file="0009.GIF", format="GIF")

    image10 = PhotoImage(file="0010.GIF", format="GIF")

    image11 = PhotoImage(file="0011.GIF", format="GIF")


    aValue = image1
    aValue = Label(App, image=image1)
    aValue.image1 = image1
    bValue = image2
    bValue = Label(App, image=image2)
    bValue.image2 = image2
    cValue = image3
    cValue = Label(App, image=image3)
    cValue.image3 = image3
    dValue = image4
    dValue = Label(App, image=image4)
    dValue.image4 = image4
    eValue = image5
    eValue = Label(App, image=image5)
    eValue.image5 = image5
    fValue = image6
    fValue = Label(App, image=image6)
    fValue.image6 = image6
    gValue = image7
    gValue = Label(App, image=image7)
    gValue.image7 = image7
    hValue = image8
    hValue = Label(App, image=image8)
    hValue.image8 = image8
    iValue = image9
    iValue = Label(App, image=image9)
    iValue.image9 = image9
    jValue = image10
    jValue = Label(App, image=image10)
    jValue.image10 = image10
    kValue = image11
    kValue = Label(App, image=image11)
    kValue.image11 = image11

    za = []
    zb = []
    zc = []
    zd = []
    ze = []
    zf = []
    zg = []
    zh = []
    zi = []
    zj = []
    zk = []

    za = [value1, aValue, '\n']
    zb = [value2, bValue, '\n']
    zc = [value3, cValue, '\n']
    zd = [value4, dValue, '\n']
    ze = [value5, eValue, '\n']
    zf = [value6, fValue, '\n']
    zg = [value7, gValue, '\n']
    zh = [value8, hValue, '\n']
    zi = [value9, iValue, '\n']
    zj = [value10, jValue, '\n']
    zk = [value11, kValue, '\n']
    ya = [za, zb, zc, zd, ze, zf, zg, zh, zi, zj, zk]
    zzx = sorted(ya, key=itemgetter(0), reverse=False)
    zzz = zzx

    qa = zzx[0]
    qb = zzx[1]
    qc = zzx[2]
    qd = zzx[3]
    qe = zzx[4]
    qf = zzx[5]
    qg = zzx[6]
    qh = zzx[7]
    qi = zzx[8]
    qj = zzx[9]
    qk = zzx[10]

    xa = qa[-2]
    xb = qb[-2]
    xc = qc[-2]
    xd = qd[-2]
    xe = qe[-2]
    xf = qf[-2]
    xg = qg[-2]
    xh = qh[-2]
    xi = qi[-2]
    xj = qj[-2]
    xk = qk[-2]

    sa = xa
    sb = xb
    sc = xc
    sd = xd
    se = xe
    sf = xf
    sg = xg
    sh = xh
    si = xi
    sj = xj
    sk = xk

    sa.config(bg="#000000")
    sa.grid(row=1, column=0)
    sb.config(bg="#000000")
    sb.grid(row=2, column=0)
    sc.config(bg="#000000")
    sc.grid(row=3, column=0)
    sd.config(bg="#000000")
    sd.grid(row=4, column=0)
    se.config(bg="#000000")
    se.grid(row=5, column=0)
    sf.config(bg="#000000")
    sf.grid(row=6, column=0)
    sg.config(bg="#000000")
    sg.grid(row=7, column=0)
    sh.config(bg="#000000")
    sh.grid(row=8, column=0)
    si.config(bg="#000000")
    si.grid(row=9, column=0)
    sj.config(bg="#000000")
    sj.grid(row=10, column=0)
    sk.config(bg="#000000")
    sk.grid(row=11, column=0)

    return

def cFunction():

    global sa, sb, sc, sd, se, sf, sg, sh, si, sj, sk
   
    value1 = str(random.randint(0, 11))
    value2 = str(random.randint(0, 11))
    value3 = str(random.randint(0, 11))
    value4 = str(random.randint(0, 11))
    value5 = str(random.randint(0, 11))
    value6 = str(random.randint(0, 11))
    value7 = str(random.randint(0, 11))
    value8 = str(random.randint(0, 11))
    value9 = str(random.randint(0, 11))
    value10 = str(random.randint(0, 11))
    value11 = str(random.randint(0, 11))

    image1 = PhotoImage(file="0001.GIF", format="GIF")

    image2 = PhotoImage(file="0002.GIF", format="GIF")

    image3 = PhotoImage(file="0003.GIF", format="GIF")

    image4 = PhotoImage(file="0004.GIF", format="GIF")

    image5 = PhotoImage(file="0005.GIF", format="GIF")

    image6 = PhotoImage(file="0006.GIF", format="GIF")

    image7 = PhotoImage(file="0007.GIF", format="GIF")

    image8 = PhotoImage(file="0008.GIF", format="GIF")

    image9 = PhotoImage(file="0009.GIF", format="GIF")

    image10 = PhotoImage(file="0010.GIF", format="GIF")

    image11 = PhotoImage(file="0011.GIF", format="GIF")


    aValue = image1
    aValue = Label(App, image=image1)
    aValue.image1 = image1
    bValue = image2
    bValue = Label(App, image=image2)
    bValue.image2 = image2
    cValue = image3
    cValue = Label(App, image=image3)
    cValue.image3 = image3
    dValue = image4
    dValue = Label(App, image=image4)
    dValue.image4 = image4
    eValue = image5
    eValue = Label(App, image=image5)
    eValue.image5 = image5
    fValue = image6
    fValue = Label(App, image=image6)
    fValue.image6 = image6
    gValue = image7
    gValue = Label(App, image=image7)
    gValue.image7 = image7
    hValue = image8
    hValue = Label(App, image=image8)
    hValue.image8 = image8
    iValue = image9
    iValue = Label(App, image=image9)
    iValue.image9 = image9
    jValue = image10
    jValue = Label(App, image=image10)
    jValue.image10 = image10
    kValue = image11
    kValue = Label(App, image=image11)
    kValue.image11 = image11

    za = []
    zb = []
    zc = []
    zd = []
    ze = []
    zf = []
    zg = []
    zh = []
    zi = []
    zj = []
    zk = []

    za = [value1, aValue, '\n']
    zb = [value2, bValue, '\n']
    zc = [value3, cValue, '\n']
    zd = [value4, dValue, '\n']
    ze = [value5, eValue, '\n']
    zf = [value6, fValue, '\n']
    zg = [value7, gValue, '\n']
    zh = [value8, hValue, '\n']
    zi = [value9, iValue, '\n']
    zj = [value10, jValue, '\n']
    zk = [value11, kValue, '\n']
    ya = [za, zb, zc, zd, ze, zf, zg, zh, zi, zj, zk]
    zzx = sorted(ya, key=itemgetter(0), reverse=False)
    zzz = zzx

    qa = zzx[0]
    qb = zzx[1]
    qc = zzx[2]
    qd = zzx[3]
    qe = zzx[4]
    qf = zzx[5]
    qg = zzx[6]
    qh = zzx[7]
    qi = zzx[8]
    qj = zzx[9]
    qk = zzx[10]

    xa = qa[-2]
    xb = qb[-2]
    xc = qc[-2]
    xd = qd[-2]
    xe = qe[-2]
    xf = qf[-2]
    xg = qg[-2]
    xh = qh[-2]
    xi = qi[-2]
    xj = qj[-2]
    xk = qk[-2]

    sa = xa
    sb = xb
    sc = xc
    sd = xd
    se = xe
    sf = xf
    sg = xg
    sh = xh
    si = xi
    sj = xj
    sk = xk

    sa.config(bg="#000000")
    sa.grid(row=1, column=1)
    sb.config(bg="#000000")
    sb.grid(row=2, column=1)
    sc.config(bg="#000000")
    sc.grid(row=3, column=1)
    sd.config(bg="#000000")
    sd.grid(row=4, column=1)
    se.config(bg="#000000")
    se.grid(row=5, column=1)
    sf.config(bg="#000000")
    sf.grid(row=6, column=1)
    sg.config(bg="#000000")
    sg.grid(row=7, column=1)
    sh.config(bg="#000000")
    sh.grid(row=8, column=1)
    si.config(bg="#000000")
    si.grid(row=9, column=1)
    sj.config(bg="#000000")
    sj.grid(row=10, column=1)
    sk.config(bg="#000000")
    sk.grid(row=11, column=1)

    return

def dFunction():
    
    global sa, sb, sc, sd, se, sf, sg, sh, si, sj, sk
   
    value1 = str(random.randint(0, 11))
    value2 = str(random.randint(0, 11))
    value3 = str(random.randint(0, 11))
    value4 = str(random.randint(0, 11))
    value5 = str(random.randint(0, 11))
    value6 = str(random.randint(0, 11))
    value7 = str(random.randint(0, 11))
    value8 = str(random.randint(0, 11))
    value9 = str(random.randint(0, 11))
    value10 = str(random.randint(0, 11))
    value11 = str(random.randint(0, 11))

    image1 = PhotoImage(file="0001.GIF", format="GIF")

    image2 = PhotoImage(file="0002.GIF", format="GIF")

    image3 = PhotoImage(file="0003.GIF", format="GIF")

    image4 = PhotoImage(file="0004.GIF", format="GIF")

    image5 = PhotoImage(file="0005.GIF", format="GIF")

    image6 = PhotoImage(file="0006.GIF", format="GIF")

    image7 = PhotoImage(file="0007.GIF", format="GIF")

    image8 = PhotoImage(file="0008.GIF", format="GIF")

    image9 = PhotoImage(file="0009.GIF", format="GIF")

    image10 = PhotoImage(file="0010.GIF", format="GIF")

    image11 = PhotoImage(file="0011.GIF", format="GIF")


    aValue = image1
    aValue = Label(App, image=image1)
    aValue.image1 = image1
    bValue = image2
    bValue = Label(App, image=image2)
    bValue.image2 = image2
    cValue = image3
    cValue = Label(App, image=image3)
    cValue.image3 = image3
    dValue = image4
    dValue = Label(App, image=image4)
    dValue.image4 = image4
    eValue = image5
    eValue = Label(App, image=image5)
    eValue.image5 = image5
    fValue = image6
    fValue = Label(App, image=image6)
    fValue.image6 = image6
    gValue = image7
    gValue = Label(App, image=image7)
    gValue.image7 = image7
    hValue = image8
    hValue = Label(App, image=image8)
    hValue.image8 = image8
    iValue = image9
    iValue = Label(App, image=image9)
    iValue.image9 = image9
    jValue = image10
    jValue = Label(App, image=image10)
    jValue.image10 = image10
    kValue = image11
    kValue = Label(App, image=image11)
    kValue.image11 = image11

    za = []
    zb = []
    zc = []
    zd = []
    ze = []
    zf = []
    zg = []
    zh = []
    zi = []
    zj = []
    zk = []

    za = [value1, aValue, '\n']
    zb = [value2, bValue, '\n']
    zc = [value3, cValue, '\n']
    zd = [value4, dValue, '\n']
    ze = [value5, eValue, '\n']
    zf = [value6, fValue, '\n']
    zg = [value7, gValue, '\n']
    zh = [value8, hValue, '\n']
    zi = [value9, iValue, '\n']
    zj = [value10, jValue, '\n']
    zk = [value11, kValue, '\n']
    ya = [za, zb, zc, zd, ze, zf, zg, zh, zi, zj, zk]
    zzx = sorted(ya, key=itemgetter(0), reverse=False)
    zzz = zzx

    qa = zzx[0]
    qb = zzx[1]
    qc = zzx[2]
    qd = zzx[3]
    qe = zzx[4]
    qf = zzx[5]
    qg = zzx[6]
    qh = zzx[7]
    qi = zzx[8]
    qj = zzx[9]
    qk = zzx[10]

    xa = qa[-2]
    xb = qb[-2]
    xc = qc[-2]
    xd = qd[-2]
    xe = qe[-2]
    xf = qf[-2]
    xg = qg[-2]
    xh = qh[-2]
    xi = qi[-2]
    xj = qj[-2]
    xk = qk[-2]

    sa = xa
    sb = xb
    sc = xc
    sd = xd
    se = xe
    sf = xf
    sg = xg
    sh = xh
    si = xi
    sj = xj
    sk = xk

    sa.config(bg="#000000")
    sa.grid(row=1, column=1)
    sb.config(bg="#000000")
    sb.grid(row=2, column=1)
    sc.config(bg="#000000")
    sc.grid(row=3, column=1)
    sd.config(bg="#000000")
    sd.grid(row=4, column=1)
    se.config(bg="#000000")
    se.grid(row=5, column=1)
    sf.config(bg="#000000")
    sf.grid(row=6, column=1)
    sg.config(bg="#000000")
    sg.grid(row=7, column=1)
    sh.config(bg="#000000")
    sh.grid(row=8, column=1)
    si.config(bg="#000000")
    si.grid(row=9, column=1)
    sj.config(bg="#000000")
    sj.grid(row=10, column=1)
    sk.config(bg="#000000")
    sk.grid(row=11, column=1)

    return

def eFunction():

    global sa, sb, sc, sd, se, sf, sg, sh, si, sj, sk
   
    value1 = str(random.randint(0, 11))
    value2 = str(random.randint(0, 11))
    value3 = str(random.randint(0, 11))
    value4 = str(random.randint(0, 11))
    value5 = str(random.randint(0, 11))
    value6 = str(random.randint(0, 11))
    value7 = str(random.randint(0, 11))
    value8 = str(random.randint(0, 11))
    value9 = str(random.randint(0, 11))
    value10 = str(random.randint(0, 11))
    value11 = str(random.randint(0, 11))

    image1 = PhotoImage(file="0001.GIF", format="GIF")

    image2 = PhotoImage(file="0002.GIF", format="GIF")

    image3 = PhotoImage(file="0003.GIF", format="GIF")

    image4 = PhotoImage(file="0004.GIF", format="GIF")

    image5 = PhotoImage(file="0005.GIF", format="GIF")

    image6 = PhotoImage(file="0006.GIF", format="GIF")

    image7 = PhotoImage(file="0007.GIF", format="GIF")

    image8 = PhotoImage(file="0008.GIF", format="GIF")

    image9 = PhotoImage(file="0009.GIF", format="GIF")

    image10 = PhotoImage(file="0010.GIF", format="GIF")

    image11 = PhotoImage(file="0011.GIF", format="GIF")


    aValue = image1
    aValue = Label(App, image=image1)
    aValue.image1 = image1
    bValue = image2
    bValue = Label(App, image=image2)
    bValue.image2 = image2
    cValue = image3
    cValue = Label(App, image=image3)
    cValue.image3 = image3
    dValue = image4
    dValue = Label(App, image=image4)
    dValue.image4 = image4
    eValue = image5
    eValue = Label(App, image=image5)
    eValue.image5 = image5
    fValue = image6
    fValue = Label(App, image=image6)
    fValue.image6 = image6
    gValue = image7
    gValue = Label(App, image=image7)
    gValue.image7 = image7
    hValue = image8
    hValue = Label(App, image=image8)
    hValue.image8 = image8
    iValue = image9
    iValue = Label(App, image=image9)
    iValue.image9 = image9
    jValue = image10
    jValue = Label(App, image=image10)
    jValue.image10 = image10
    kValue = image11
    kValue = Label(App, image=image11)
    kValue.image11 = image11

    za = []
    zb = []
    zc = []
    zd = []
    ze = []
    zf = []
    zg = []
    zh = []
    zi = []
    zj = []
    zk = []

    za = [value1, aValue, '\n']
    zb = [value2, bValue, '\n']
    zc = [value3, cValue, '\n']
    zd = [value4, dValue, '\n']
    ze = [value5, eValue, '\n']
    zf = [value6, fValue, '\n']
    zg = [value7, gValue, '\n']
    zh = [value8, hValue, '\n']
    zi = [value9, iValue, '\n']
    zj = [value10, jValue, '\n']
    zk = [value11, kValue, '\n']
    ya = [za, zb, zc, zd, ze, zf, zg, zh, zi, zj, zk]
    zzx = sorted(ya, key=itemgetter(0), reverse=False)
    zzz = zzx

    qa = zzx[0]
    qb = zzx[1]
    qc = zzx[2]
    qd = zzx[3]
    qe = zzx[4]
    qf = zzx[5]
    qg = zzx[6]
    qh = zzx[7]
    qi = zzx[8]
    qj = zzx[9]
    qk = zzx[10]

    xa = qa[-2]
    xb = qb[-2]
    xc = qc[-2]
    xd = qd[-2]
    xe = qe[-2]
    xf = qf[-2]
    xg = qg[-2]
    xh = qh[-2]
    xi = qi[-2]
    xj = qj[-2]
    xk = qk[-2]

    sa = xa
    sb = xb
    sc = xc
    sd = xd
    se = xe
    sf = xf
    sg = xg
    sh = xh
    si = xi
    sj = xj
    sk = xk

    sa.config(bg="#000000")
    sa.grid(row=1, column=2)
    sb.config(bg="#000000")
    sb.grid(row=2, column=2)
    sc.config(bg="#000000")
    sc.grid(row=3, column=2)
    sd.config(bg="#000000")
    sd.grid(row=4, column=2)
    se.config(bg="#000000")
    se.grid(row=5, column=2)
    sf.config(bg="#000000")
    sf.grid(row=6, column=2)
    sg.config(bg="#000000")
    sg.grid(row=7, column=2)
    sh.config(bg="#000000")
    sh.grid(row=8, column=2)
    si.config(bg="#000000")
    si.grid(row=9, column=2)
    sj.config(bg="#000000")
    sj.grid(row=10, column=2)
    sk.config(bg="#000000")
    sk.grid(row=11, column=2)

    return

def fFunction():
    
    global sa, sb, sc, sd, se, sf, sg, sh, si, sj, sk
   
    value1 = str(random.randint(0, 11))
    value2 = str(random.randint(0, 11))
    value3 = str(random.randint(0, 11))
    value4 = str(random.randint(0, 11))
    value5 = str(random.randint(0, 11))
    value6 = str(random.randint(0, 11))
    value7 = str(random.randint(0, 11))
    value8 = str(random.randint(0, 11))
    value9 = str(random.randint(0, 11))
    value10 = str(random.randint(0, 11))
    value11 = str(random.randint(0, 11))

    image1 = PhotoImage(file="0001.GIF", format="GIF")

    image2 = PhotoImage(file="0002.GIF", format="GIF")

    image3 = PhotoImage(file="0003.GIF", format="GIF")

    image4 = PhotoImage(file="0004.GIF", format="GIF")

    image5 = PhotoImage(file="0005.GIF", format="GIF")

    image6 = PhotoImage(file="0006.GIF", format="GIF")

    image7 = PhotoImage(file="0007.GIF", format="GIF")

    image8 = PhotoImage(file="0008.GIF", format="GIF")

    image9 = PhotoImage(file="0009.GIF", format="GIF")

    image10 = PhotoImage(file="0010.GIF", format="GIF")

    image11 = PhotoImage(file="0011.GIF", format="GIF")


    aValue = image1
    aValue = Label(App, image=image1)
    aValue.image1 = image1
    bValue = image2
    bValue = Label(App, image=image2)
    bValue.image2 = image2
    cValue = image3
    cValue = Label(App, image=image3)
    cValue.image3 = image3
    dValue = image4
    dValue = Label(App, image=image4)
    dValue.image4 = image4
    eValue = image5
    eValue = Label(App, image=image5)
    eValue.image5 = image5
    fValue = image6
    fValue = Label(App, image=image6)
    fValue.image6 = image6
    gValue = image7
    gValue = Label(App, image=image7)
    gValue.image7 = image7
    hValue = image8
    hValue = Label(App, image=image8)
    hValue.image8 = image8
    iValue = image9
    iValue = Label(App, image=image9)
    iValue.image9 = image9
    jValue = image10
    jValue = Label(App, image=image10)
    jValue.image10 = image10
    kValue = image11
    kValue = Label(App, image=image11)
    kValue.image11 = image11

    za = []
    zb = []
    zc = []
    zd = []
    ze = []
    zf = []
    zg = []
    zh = []
    zi = []
    zj = []
    zk = []

    za = [value1, aValue, '\n']
    zb = [value2, bValue, '\n']
    zc = [value3, cValue, '\n']
    zd = [value4, dValue, '\n']
    ze = [value5, eValue, '\n']
    zf = [value6, fValue, '\n']
    zg = [value7, gValue, '\n']
    zh = [value8, hValue, '\n']
    zi = [value9, iValue, '\n']
    zj = [value10, jValue, '\n']
    zk = [value11, kValue, '\n']
    ya = [za, zb, zc, zd, ze, zf, zg, zh, zi, zj, zk]
    zzx = sorted(ya, key=itemgetter(0), reverse=False)
    zzz = zzx

    qa = zzx[0]
    qb = zzx[1]
    qc = zzx[2]
    qd = zzx[3]
    qe = zzx[4]
    qf = zzx[5]
    qg = zzx[6]
    qh = zzx[7]
    qi = zzx[8]
    qj = zzx[9]
    qk = zzx[10]

    xa = qa[-2]
    xb = qb[-2]
    xc = qc[-2]
    xd = qd[-2]
    xe = qe[-2]
    xf = qf[-2]
    xg = qg[-2]
    xh = qh[-2]
    xi = qi[-2]
    xj = qj[-2]
    xk = qk[-2]

    sa = xa
    sb = xb
    sc = xc
    sd = xd
    se = xe
    sf = xf
    sg = xg
    sh = xh
    si = xi
    sj = xj
    sk = xk

    sa.config(bg="#000000")
    sa.grid(row=1, column=2)
    sb.config(bg="#000000")
    sb.grid(row=2, column=2)
    sc.config(bg="#000000")
    sc.grid(row=3, column=2)
    sd.config(bg="#000000")
    sd.grid(row=4, column=2)
    se.config(bg="#000000")
    se.grid(row=5, column=2)
    sf.config(bg="#000000")
    sf.grid(row=6, column=2)
    sg.config(bg="#000000")
    sg.grid(row=7, column=2)
    sh.config(bg="#000000")
    sh.grid(row=8, column=2)
    si.config(bg="#000000")
    si.grid(row=9, column=2)
    sj.config(bg="#000000")
    sj.grid(row=10, column=2)
    sk.config(bg="#000000")
    sk.grid(row=11, column=2)

    return

def gFunction():

    global sa, sb, sc, sd, se, sf, sg, sh, si, sj, sk
   
    value1 = str(random.randint(0, 11))
    value2 = str(random.randint(0, 11))
    value3 = str(random.randint(0, 11))
    value4 = str(random.randint(0, 11))
    value5 = str(random.randint(0, 11))
    value6 = str(random.randint(0, 11))
    value7 = str(random.randint(0, 11))
    value8 = str(random.randint(0, 11))
    value9 = str(random.randint(0, 11))
    value10 = str(random.randint(0, 11))
    value11 = str(random.randint(0, 11))

    image1 = PhotoImage(file="0001.GIF", format="GIF")

    image2 = PhotoImage(file="0002.GIF", format="GIF")

    image3 = PhotoImage(file="0003.GIF", format="GIF")

    image4 = PhotoImage(file="0004.GIF", format="GIF")

    image5 = PhotoImage(file="0005.GIF", format="GIF")

    image6 = PhotoImage(file="0006.GIF", format="GIF")

    image7 = PhotoImage(file="0007.GIF", format="GIF")

    image8 = PhotoImage(file="0008.GIF", format="GIF")

    image9 = PhotoImage(file="0009.GIF", format="GIF")

    image10 = PhotoImage(file="0010.GIF", format="GIF")

    image11 = PhotoImage(file="0011.GIF", format="GIF")


    aValue = image1
    aValue = Label(App, image=image1)
    aValue.image1 = image1
    bValue = image2
    bValue = Label(App, image=image2)
    bValue.image2 = image2
    cValue = image3
    cValue = Label(App, image=image3)
    cValue.image3 = image3
    dValue = image4
    dValue = Label(App, image=image4)
    dValue.image4 = image4
    eValue = image5
    eValue = Label(App, image=image5)
    eValue.image5 = image5
    fValue = image6
    fValue = Label(App, image=image6)
    fValue.image6 = image6
    gValue = image7
    gValue = Label(App, image=image7)
    gValue.image7 = image7
    hValue = image8
    hValue = Label(App, image=image8)
    hValue.image8 = image8
    iValue = image9
    iValue = Label(App, image=image9)
    iValue.image9 = image9
    jValue = image10
    jValue = Label(App, image=image10)
    jValue.image10 = image10
    kValue = image11
    kValue = Label(App, image=image11)
    kValue.image11 = image11

    za = []
    zb = []
    zc = []
    zd = []
    ze = []
    zf = []
    zg = []
    zh = []
    zi = []
    zj = []
    zk = []

    za = [value1, aValue, '\n']
    zb = [value2, bValue, '\n']
    zc = [value3, cValue, '\n']
    zd = [value4, dValue, '\n']
    ze = [value5, eValue, '\n']
    zf = [value6, fValue, '\n']
    zg = [value7, gValue, '\n']
    zh = [value8, hValue, '\n']
    zi = [value9, iValue, '\n']
    zj = [value10, jValue, '\n']
    zk = [value11, kValue, '\n']
    ya = [za, zb, zc, zd, ze, zf, zg, zh, zi, zj, zk]
    zzx = sorted(ya, key=itemgetter(0), reverse=False)
    zzz = zzx

    qa = zzx[0]
    qb = zzx[1]
    qc = zzx[2]
    qd = zzx[3]
    qe = zzx[4]
    qf = zzx[5]
    qg = zzx[6]
    qh = zzx[7]
    qi = zzx[8]
    qj = zzx[9]
    qk = zzx[10]

    xa = qa[-2]
    xb = qb[-2]
    xc = qc[-2]
    xd = qd[-2]
    xe = qe[-2]
    xf = qf[-2]
    xg = qg[-2]
    xh = qh[-2]
    xi = qi[-2]
    xj = qj[-2]
    xk = qk[-2]

    sa = xa
    sb = xb
    sc = xc
    sd = xd
    se = xe
    sf = xf
    sg = xg
    sh = xh
    si = xi
    sj = xj
    sk = xk

    sa.config(bg="#000000")
    sa.grid(row=1, column=3)
    sb.config(bg="#000000")
    sb.grid(row=2, column=3)
    sc.config(bg="#000000")
    sc.grid(row=3, column=3)
    sd.config(bg="#000000")
    sd.grid(row=4, column=3)
    se.config(bg="#000000")
    se.grid(row=5, column=3)
    sf.config(bg="#000000")
    sf.grid(row=6, column=3)
    sg.config(bg="#000000")
    sg.grid(row=7, column=3)
    sh.config(bg="#000000")
    sh.grid(row=8, column=3)
    si.config(bg="#000000")
    si.grid(row=9, column=3)
    sj.config(bg="#000000")
    sj.grid(row=10, column=3)
    sk.config(bg="#000000")
    sk.grid(row=11, column=3)

    return

def hFunction():
    
    global sa, sb, sc, sd, se, sf, sg, sh, si, sj, sk
   
    value1 = str(random.randint(0, 11))
    value2 = str(random.randint(0, 11))
    value3 = str(random.randint(0, 11))
    value4 = str(random.randint(0, 11))
    value5 = str(random.randint(0, 11))
    value6 = str(random.randint(0, 11))
    value7 = str(random.randint(0, 11))
    value8 = str(random.randint(0, 11))
    value9 = str(random.randint(0, 11))
    value10 = str(random.randint(0, 11))
    value11 = str(random.randint(0, 11))

    image1 = PhotoImage(file="0001.GIF", format="GIF")

    image2 = PhotoImage(file="0002.GIF", format="GIF")

    image3 = PhotoImage(file="0003.GIF", format="GIF")

    image4 = PhotoImage(file="0004.GIF", format="GIF")

    image5 = PhotoImage(file="0005.GIF", format="GIF")

    image6 = PhotoImage(file="0006.GIF", format="GIF")

    image7 = PhotoImage(file="0007.GIF", format="GIF")

    image8 = PhotoImage(file="0008.GIF", format="GIF")

    image9 = PhotoImage(file="0009.GIF", format="GIF")

    image10 = PhotoImage(file="0010.GIF", format="GIF")

    image11 = PhotoImage(file="0011.GIF", format="GIF")


    aValue = image1
    aValue = Label(App, image=image1)
    aValue.image1 = image1
    bValue = image2
    bValue = Label(App, image=image2)
    bValue.image2 = image2
    cValue = image3
    cValue = Label(App, image=image3)
    cValue.image3 = image3
    dValue = image4
    dValue = Label(App, image=image4)
    dValue.image4 = image4
    eValue = image5
    eValue = Label(App, image=image5)
    eValue.image5 = image5
    fValue = image6
    fValue = Label(App, image=image6)
    fValue.image6 = image6
    gValue = image7
    gValue = Label(App, image=image7)
    gValue.image7 = image7
    hValue = image8
    hValue = Label(App, image=image8)
    hValue.image8 = image8
    iValue = image9
    iValue = Label(App, image=image9)
    iValue.image9 = image9
    jValue = image10
    jValue = Label(App, image=image10)
    jValue.image10 = image10
    kValue = image11
    kValue = Label(App, image=image11)
    kValue.image11 = image11

    za = []
    zb = []
    zc = []
    zd = []
    ze = []
    zf = []
    zg = []
    zh = []
    zi = []
    zj = []
    zk = []

    za = [value1, aValue, '\n']
    zb = [value2, bValue, '\n']
    zc = [value3, cValue, '\n']
    zd = [value4, dValue, '\n']
    ze = [value5, eValue, '\n']
    zf = [value6, fValue, '\n']
    zg = [value7, gValue, '\n']
    zh = [value8, hValue, '\n']
    zi = [value9, iValue, '\n']
    zj = [value10, jValue, '\n']
    zk = [value11, kValue, '\n']
    ya = [za, zb, zc, zd, ze, zf, zg, zh, zi, zj, zk]
    zzx = sorted(ya, key=itemgetter(0), reverse=False)
    zzz = zzx

    qa = zzx[0]
    qb = zzx[1]
    qc = zzx[2]
    qd = zzx[3]
    qe = zzx[4]
    qf = zzx[5]
    qg = zzx[6]
    qh = zzx[7]
    qi = zzx[8]
    qj = zzx[9]
    qk = zzx[10]

    xa = qa[-2]
    xb = qb[-2]
    xc = qc[-2]
    xd = qd[-2]
    xe = qe[-2]
    xf = qf[-2]
    xg = qg[-2]
    xh = qh[-2]
    xi = qi[-2]
    xj = qj[-2]
    xk = qk[-2]

    sa = xa
    sb = xb
    sc = xc
    sd = xd
    se = xe
    sf = xf
    sg = xg
    sh = xh
    si = xi
    sj = xj
    sk = xk

    sa.config(bg="#000000")
    sa.grid(row=1, column=3)
    sb.config(bg="#000000")
    sb.grid(row=2, column=3)
    sc.config(bg="#000000")
    sc.grid(row=3, column=3)
    sd.config(bg="#000000")
    sd.grid(row=4, column=3)
    se.config(bg="#000000")
    se.grid(row=5, column=3)
    sf.config(bg="#000000")
    sf.grid(row=6, column=3)
    sg.config(bg="#000000")
    sg.grid(row=7, column=3)
    sh.config(bg="#000000")
    sh.grid(row=8, column=3)
    si.config(bg="#000000")
    si.grid(row=9, column=3)
    sj.config(bg="#000000")
    sj.grid(row=10, column=3)
    sk.config(bg="#000000")
    sk.grid(row=11, column=3)

    return

def iFunction():

    global sa, sb, sc, sd, se, sf, sg, sh, si, sj, sk
   
    value1 = str(random.randint(0, 11))
    value2 = str(random.randint(0, 11))
    value3 = str(random.randint(0, 11))
    value4 = str(random.randint(0, 11))
    value5 = str(random.randint(0, 11))
    value6 = str(random.randint(0, 11))
    value7 = str(random.randint(0, 11))
    value8 = str(random.randint(0, 11))
    value9 = str(random.randint(0, 11))
    value10 = str(random.randint(0, 11))
    value11 = str(random.randint(0, 11))

    image1 = PhotoImage(file="0001.GIF", format="GIF")

    image2 = PhotoImage(file="0002.GIF", format="GIF")

    image3 = PhotoImage(file="0003.GIF", format="GIF")

    image4 = PhotoImage(file="0004.GIF", format="GIF")

    image5 = PhotoImage(file="0005.GIF", format="GIF")

    image6 = PhotoImage(file="0006.GIF", format="GIF")

    image7 = PhotoImage(file="0007.GIF", format="GIF")

    image8 = PhotoImage(file="0008.GIF", format="GIF")

    image9 = PhotoImage(file="0009.GIF", format="GIF")

    image10 = PhotoImage(file="0010.GIF", format="GIF")

    image11 = PhotoImage(file="0011.GIF", format="GIF")


    aValue = image1
    aValue = Label(App, image=image1)
    aValue.image1 = image1
    bValue = image2
    bValue = Label(App, image=image2)
    bValue.image2 = image2
    cValue = image3
    cValue = Label(App, image=image3)
    cValue.image3 = image3
    dValue = image4
    dValue = Label(App, image=image4)
    dValue.image4 = image4
    eValue = image5
    eValue = Label(App, image=image5)
    eValue.image5 = image5
    fValue = image6
    fValue = Label(App, image=image6)
    fValue.image6 = image6
    gValue = image7
    gValue = Label(App, image=image7)
    gValue.image7 = image7
    hValue = image8
    hValue = Label(App, image=image8)
    hValue.image8 = image8
    iValue = image9
    iValue = Label(App, image=image9)
    iValue.image9 = image9
    jValue = image10
    jValue = Label(App, image=image10)
    jValue.image10 = image10
    kValue = image11
    kValue = Label(App, image=image11)
    kValue.image11 = image11

    za = []
    zb = []
    zc = []
    zd = []
    ze = []
    zf = []
    zg = []
    zh = []
    zi = []
    zj = []
    zk = []

    za = [value1, aValue, '\n']
    zb = [value2, bValue, '\n']
    zc = [value3, cValue, '\n']
    zd = [value4, dValue, '\n']
    ze = [value5, eValue, '\n']
    zf = [value6, fValue, '\n']
    zg = [value7, gValue, '\n']
    zh = [value8, hValue, '\n']
    zi = [value9, iValue, '\n']
    zj = [value10, jValue, '\n']
    zk = [value11, kValue, '\n']
    ya = [za, zb, zc, zd, ze, zf, zg, zh, zi, zj, zk]
    zzx = sorted(ya, key=itemgetter(0), reverse=False)
    zzz = zzx

    qa = zzx[0]
    qb = zzx[1]
    qc = zzx[2]
    qd = zzx[3]
    qe = zzx[4]
    qf = zzx[5]
    qg = zzx[6]
    qh = zzx[7]
    qi = zzx[8]
    qj = zzx[9]
    qk = zzx[10]

    xa = qa[-2]
    xb = qb[-2]
    xc = qc[-2]
    xd = qd[-2]
    xe = qe[-2]
    xf = qf[-2]
    xg = qg[-2]
    xh = qh[-2]
    xi = qi[-2]
    xj = qj[-2]
    xk = qk[-2]

    sa = xa
    sb = xb
    sc = xc
    sd = xd
    se = xe
    sf = xf
    sg = xg
    sh = xh
    si = xi
    sj = xj
    sk = xk

    sa.config(bg="#000000")
    sa.grid(row=12, column=0)
    sb.config(bg="#000000")
    sb.grid(row=13, column=0)
    sc.config(bg="#000000")
    sc.grid(row=14, column=0)
    sd.config(bg="#000000")
    sd.grid(row=15, column=0)
    se.config(bg="#000000")
    se.grid(row=16, column=0)
    sf.config(bg="#000000")
    sf.grid(row=17, column=0)
    sg.config(bg="#000000")
    sg.grid(row=18, column=0)
    sh.config(bg="#000000")
    sh.grid(row=19, column=0)
    si.config(bg="#000000")
    si.grid(row=20, column=0)
    sj.config(bg="#000000")
    sj.grid(row=21, column=0)
    sk.config(bg="#000000")
    sk.grid(row=22, column=0)

    return

def jFunction():
    
    global sa, sb, sc, sd, se, sf, sg, sh, si, sj, sk
   
    value1 = str(random.randint(0, 11))
    value2 = str(random.randint(0, 11))
    value3 = str(random.randint(0, 11))
    value4 = str(random.randint(0, 11))
    value5 = str(random.randint(0, 11))
    value6 = str(random.randint(0, 11))
    value7 = str(random.randint(0, 11))
    value8 = str(random.randint(0, 11))
    value9 = str(random.randint(0, 11))
    value10 = str(random.randint(0, 11))
    value11 = str(random.randint(0, 11))

    image1 = PhotoImage(file="0001.GIF", format="GIF")

    image2 = PhotoImage(file="0002.GIF", format="GIF")

    image3 = PhotoImage(file="0003.GIF", format="GIF")

    image4 = PhotoImage(file="0004.GIF", format="GIF")

    image5 = PhotoImage(file="0005.GIF", format="GIF")

    image6 = PhotoImage(file="0006.GIF", format="GIF")

    image7 = PhotoImage(file="0007.GIF", format="GIF")

    image8 = PhotoImage(file="0008.GIF", format="GIF")

    image9 = PhotoImage(file="0009.GIF", format="GIF")

    image10 = PhotoImage(file="0010.GIF", format="GIF")

    image11 = PhotoImage(file="0011.GIF", format="GIF")


    aValue = image1
    aValue = Label(App, image=image1)
    aValue.image1 = image1
    bValue = image2
    bValue = Label(App, image=image2)
    bValue.image2 = image2
    cValue = image3
    cValue = Label(App, image=image3)
    cValue.image3 = image3
    dValue = image4
    dValue = Label(App, image=image4)
    dValue.image4 = image4
    eValue = image5
    eValue = Label(App, image=image5)
    eValue.image5 = image5
    fValue = image6
    fValue = Label(App, image=image6)
    fValue.image6 = image6
    gValue = image7
    gValue = Label(App, image=image7)
    gValue.image7 = image7
    hValue = image8
    hValue = Label(App, image=image8)
    hValue.image8 = image8
    iValue = image9
    iValue = Label(App, image=image9)
    iValue.image9 = image9
    jValue = image10
    jValue = Label(App, image=image10)
    jValue.image10 = image10
    kValue = image11
    kValue = Label(App, image=image11)
    kValue.image11 = image11

    za = []
    zb = []
    zc = []
    zd = []
    ze = []
    zf = []
    zg = []
    zh = []
    zi = []
    zj = []
    zk = []

    za = [value1, aValue, '\n']
    zb = [value2, bValue, '\n']
    zc = [value3, cValue, '\n']
    zd = [value4, dValue, '\n']
    ze = [value5, eValue, '\n']
    zf = [value6, fValue, '\n']
    zg = [value7, gValue, '\n']
    zh = [value8, hValue, '\n']
    zi = [value9, iValue, '\n']
    zj = [value10, jValue, '\n']
    zk = [value11, kValue, '\n']
    ya = [za, zb, zc, zd, ze, zf, zg, zh, zi, zj, zk]
    zzx = sorted(ya, key=itemgetter(0), reverse=False)
    zzz = zzx

    qa = zzx[0]
    qb = zzx[1]
    qc = zzx[2]
    qd = zzx[3]
    qe = zzx[4]
    qf = zzx[5]
    qg = zzx[6]
    qh = zzx[7]
    qi = zzx[8]
    qj = zzx[9]
    qk = zzx[10]

    xa = qa[-2]
    xb = qb[-2]
    xc = qc[-2]
    xd = qd[-2]
    xe = qe[-2]
    xf = qf[-2]
    xg = qg[-2]
    xh = qh[-2]
    xi = qi[-2]
    xj = qj[-2]
    xk = qk[-2]

    sa = xa
    sb = xb
    sc = xc
    sd = xd
    se = xe
    sf = xf
    sg = xg
    sh = xh
    si = xi
    sj = xj
    sk = xk

    sa.config(bg="#000000")
    sa.grid(row=12, column=0)
    sb.config(bg="#000000")
    sb.grid(row=13, column=0)
    sc.config(bg="#000000")
    sc.grid(row=14, column=0)
    sd.config(bg="#000000")
    sd.grid(row=15, column=0)
    se.config(bg="#000000")
    se.grid(row=16, column=0)
    sf.config(bg="#000000")
    sf.grid(row=17, column=0)
    sg.config(bg="#000000")
    sg.grid(row=18, column=0)
    sh.config(bg="#000000")
    sh.grid(row=19, column=0)
    si.config(bg="#000000")
    si.grid(row=20, column=0)
    sj.config(bg="#000000")
    sj.grid(row=21, column=0)
    sk.config(bg="#000000")
    sk.grid(row=22, column=0)

    return

def kFunction():

    global sa, sb, sc, sd, se, sf, sg, sh, si, sj, sk
   
    value1 = str(random.randint(0, 11))
    value2 = str(random.randint(0, 11))
    value3 = str(random.randint(0, 11))
    value4 = str(random.randint(0, 11))
    value5 = str(random.randint(0, 11))
    value6 = str(random.randint(0, 11))
    value7 = str(random.randint(0, 11))
    value8 = str(random.randint(0, 11))
    value9 = str(random.randint(0, 11))
    value10 = str(random.randint(0, 11))
    value11 = str(random.randint(0, 11))

    image1 = PhotoImage(file="0001.GIF", format="GIF")

    image2 = PhotoImage(file="0002.GIF", format="GIF")

    image3 = PhotoImage(file="0003.GIF", format="GIF")

    image4 = PhotoImage(file="0004.GIF", format="GIF")

    image5 = PhotoImage(file="0005.GIF", format="GIF")

    image6 = PhotoImage(file="0006.GIF", format="GIF")

    image7 = PhotoImage(file="0007.GIF", format="GIF")

    image8 = PhotoImage(file="0008.GIF", format="GIF")

    image9 = PhotoImage(file="0009.GIF", format="GIF")

    image10 = PhotoImage(file="0010.GIF", format="GIF")

    image11 = PhotoImage(file="0011.GIF", format="GIF")


    aValue = image1
    aValue = Label(App, image=image1)
    aValue.image1 = image1
    bValue = image2
    bValue = Label(App, image=image2)
    bValue.image2 = image2
    cValue = image3
    cValue = Label(App, image=image3)
    cValue.image3 = image3
    dValue = image4
    dValue = Label(App, image=image4)
    dValue.image4 = image4
    eValue = image5
    eValue = Label(App, image=image5)
    eValue.image5 = image5
    fValue = image6
    fValue = Label(App, image=image6)
    fValue.image6 = image6
    gValue = image7
    gValue = Label(App, image=image7)
    gValue.image7 = image7
    hValue = image8
    hValue = Label(App, image=image8)
    hValue.image8 = image8
    iValue = image9
    iValue = Label(App, image=image9)
    iValue.image9 = image9
    jValue = image10
    jValue = Label(App, image=image10)
    jValue.image10 = image10
    kValue = image11
    kValue = Label(App, image=image11)
    kValue.image11 = image11

    za = []
    zb = []
    zc = []
    zd = []
    ze = []
    zf = []
    zg = []
    zh = []
    zi = []
    zj = []
    zk = []

    za = [value1, aValue, '\n']
    zb = [value2, bValue, '\n']
    zc = [value3, cValue, '\n']
    zd = [value4, dValue, '\n']
    ze = [value5, eValue, '\n']
    zf = [value6, fValue, '\n']
    zg = [value7, gValue, '\n']
    zh = [value8, hValue, '\n']
    zi = [value9, iValue, '\n']
    zj = [value10, jValue, '\n']
    zk = [value11, kValue, '\n']
    ya = [za, zb, zc, zd, ze, zf, zg, zh, zi, zj, zk]
    zzx = sorted(ya, key=itemgetter(0), reverse=False)
    zzz = zzx

    qa = zzx[0]
    qb = zzx[1]
    qc = zzx[2]
    qd = zzx[3]
    qe = zzx[4]
    qf = zzx[5]
    qg = zzx[6]
    qh = zzx[7]
    qi = zzx[8]
    qj = zzx[9]
    qk = zzx[10]

    xa = qa[-2]
    xb = qb[-2]
    xc = qc[-2]
    xd = qd[-2]
    xe = qe[-2]
    xf = qf[-2]
    xg = qg[-2]
    xh = qh[-2]
    xi = qi[-2]
    xj = qj[-2]
    xk = qk[-2]

    sa = xa
    sb = xb
    sc = xc
    sd = xd
    se = xe
    sf = xf
    sg = xg
    sh = xh
    si = xi
    sj = xj
    sk = xk

    sa.config(bg="#000000")
    sa.grid(row=12, column=1)
    sb.config(bg="#000000")
    sb.grid(row=13, column=1)
    sc.config(bg="#000000")
    sc.grid(row=14, column=1)
    sd.config(bg="#000000")
    sd.grid(row=15, column=1)
    se.config(bg="#000000")
    se.grid(row=16, column=1)
    sf.config(bg="#000000")
    sf.grid(row=17, column=1)
    sg.config(bg="#000000")
    sg.grid(row=18, column=1)
    sh.config(bg="#000000")
    sh.grid(row=19, column=1)
    si.config(bg="#000000")
    si.grid(row=20, column=1)
    sj.config(bg="#000000")
    sj.grid(row=21, column=1)
    sk.config(bg="#000000")
    sk.grid(row=22, column=1)

    return

def lFunction():
    
    global sa, sb, sc, sd, se, sf, sg, sh, si, sj, sk
   
    value1 = str(random.randint(0, 11))
    value2 = str(random.randint(0, 11))
    value3 = str(random.randint(0, 11))
    value4 = str(random.randint(0, 11))
    value5 = str(random.randint(0, 11))
    value6 = str(random.randint(0, 11))
    value7 = str(random.randint(0, 11))
    value8 = str(random.randint(0, 11))
    value9 = str(random.randint(0, 11))
    value10 = str(random.randint(0, 11))
    value11 = str(random.randint(0, 11))

    image1 = PhotoImage(file="0001.GIF", format="GIF")

    image2 = PhotoImage(file="0002.GIF", format="GIF")

    image3 = PhotoImage(file="0003.GIF", format="GIF")

    image4 = PhotoImage(file="0004.GIF", format="GIF")

    image5 = PhotoImage(file="0005.GIF", format="GIF")

    image6 = PhotoImage(file="0006.GIF", format="GIF")

    image7 = PhotoImage(file="0007.GIF", format="GIF")

    image8 = PhotoImage(file="0008.GIF", format="GIF")

    image9 = PhotoImage(file="0009.GIF", format="GIF")

    image10 = PhotoImage(file="0010.GIF", format="GIF")

    image11 = PhotoImage(file="0011.GIF", format="GIF")


    aValue = image1
    aValue = Label(App, image=image1)
    aValue.image1 = image1
    bValue = image2
    bValue = Label(App, image=image2)
    bValue.image2 = image2
    cValue = image3
    cValue = Label(App, image=image3)
    cValue.image3 = image3
    dValue = image4
    dValue = Label(App, image=image4)
    dValue.image4 = image4
    eValue = image5
    eValue = Label(App, image=image5)
    eValue.image5 = image5
    fValue = image6
    fValue = Label(App, image=image6)
    fValue.image6 = image6
    gValue = image7
    gValue = Label(App, image=image7)
    gValue.image7 = image7
    hValue = image8
    hValue = Label(App, image=image8)
    hValue.image8 = image8
    iValue = image9
    iValue = Label(App, image=image9)
    iValue.image9 = image9
    jValue = image10
    jValue = Label(App, image=image10)
    jValue.image10 = image10
    kValue = image11
    kValue = Label(App, image=image11)
    kValue.image11 = image11

    za = []
    zb = []
    zc = []
    zd = []
    ze = []
    zf = []
    zg = []
    zh = []
    zi = []
    zj = []
    zk = []

    za = [value1, aValue, '\n']
    zb = [value2, bValue, '\n']
    zc = [value3, cValue, '\n']
    zd = [value4, dValue, '\n']
    ze = [value5, eValue, '\n']
    zf = [value6, fValue, '\n']
    zg = [value7, gValue, '\n']
    zh = [value8, hValue, '\n']
    zi = [value9, iValue, '\n']
    zj = [value10, jValue, '\n']
    zk = [value11, kValue, '\n']
    ya = [za, zb, zc, zd, ze, zf, zg, zh, zi, zj, zk]
    zzx = sorted(ya, key=itemgetter(0), reverse=False)
    zzz = zzx

    qa = zzx[0]
    qb = zzx[1]
    qc = zzx[2]
    qd = zzx[3]
    qe = zzx[4]
    qf = zzx[5]
    qg = zzx[6]
    qh = zzx[7]
    qi = zzx[8]
    qj = zzx[9]
    qk = zzx[10]

    xa = qa[-2]
    xb = qb[-2]
    xc = qc[-2]
    xd = qd[-2]
    xe = qe[-2]
    xf = qf[-2]
    xg = qg[-2]
    xh = qh[-2]
    xi = qi[-2]
    xj = qj[-2]
    xk = qk[-2]

    sa = xa
    sb = xb
    sc = xc
    sd = xd
    se = xe
    sf = xf
    sg = xg
    sh = xh
    si = xi
    sj = xj
    sk = xk

    sa.config(bg="#000000")
    sa.grid(row=12, column=1)
    sb.config(bg="#000000")
    sb.grid(row=13, column=1)
    sc.config(bg="#000000")
    sc.grid(row=14, column=1)
    sd.config(bg="#000000")
    sd.grid(row=15, column=1)
    se.config(bg="#000000")
    se.grid(row=16, column=1)
    sf.config(bg="#000000")
    sf.grid(row=17, column=1)
    sg.config(bg="#000000")
    sg.grid(row=18, column=1)
    sh.config(bg="#000000")
    sh.grid(row=19, column=1)
    si.config(bg="#000000")
    si.grid(row=20, column=1)
    sj.config(bg="#000000")
    sj.grid(row=21, column=1)
    sk.config(bg="#000000")
    sk.grid(row=22, column=1)

    return

def mFunction():

    global sa, sb, sc, sd, se, sf, sg, sh, si, sj, sk
   
    value1 = str(random.randint(0, 11))
    value2 = str(random.randint(0, 11))
    value3 = str(random.randint(0, 11))
    value4 = str(random.randint(0, 11))
    value5 = str(random.randint(0, 11))
    value6 = str(random.randint(0, 11))
    value7 = str(random.randint(0, 11))
    value8 = str(random.randint(0, 11))
    value9 = str(random.randint(0, 11))
    value10 = str(random.randint(0, 11))
    value11 = str(random.randint(0, 11))

    image1 = PhotoImage(file="0001.GIF", format="GIF")

    image2 = PhotoImage(file="0002.GIF", format="GIF")

    image3 = PhotoImage(file="0003.GIF", format="GIF")

    image4 = PhotoImage(file="0004.GIF", format="GIF")

    image5 = PhotoImage(file="0005.GIF", format="GIF")

    image6 = PhotoImage(file="0006.GIF", format="GIF")

    image7 = PhotoImage(file="0007.GIF", format="GIF")

    image8 = PhotoImage(file="0008.GIF", format="GIF")

    image9 = PhotoImage(file="0009.GIF", format="GIF")

    image10 = PhotoImage(file="0010.GIF", format="GIF")

    image11 = PhotoImage(file="0011.GIF", format="GIF")


    aValue = image1
    aValue = Label(App, image=image1)
    aValue.image1 = image1
    bValue = image2
    bValue = Label(App, image=image2)
    bValue.image2 = image2
    cValue = image3
    cValue = Label(App, image=image3)
    cValue.image3 = image3
    dValue = image4
    dValue = Label(App, image=image4)
    dValue.image4 = image4
    eValue = image5
    eValue = Label(App, image=image5)
    eValue.image5 = image5
    fValue = image6
    fValue = Label(App, image=image6)
    fValue.image6 = image6
    gValue = image7
    gValue = Label(App, image=image7)
    gValue.image7 = image7
    hValue = image8
    hValue = Label(App, image=image8)
    hValue.image8 = image8
    iValue = image9
    iValue = Label(App, image=image9)
    iValue.image9 = image9
    jValue = image10
    jValue = Label(App, image=image10)
    jValue.image10 = image10
    kValue = image11
    kValue = Label(App, image=image11)
    kValue.image11 = image11

    za = []
    zb = []
    zc = []
    zd = []
    ze = []
    zf = []
    zg = []
    zh = []
    zi = []
    zj = []
    zk = []

    za = [value1, aValue, '\n']
    zb = [value2, bValue, '\n']
    zc = [value3, cValue, '\n']
    zd = [value4, dValue, '\n']
    ze = [value5, eValue, '\n']
    zf = [value6, fValue, '\n']
    zg = [value7, gValue, '\n']
    zh = [value8, hValue, '\n']
    zi = [value9, iValue, '\n']
    zj = [value10, jValue, '\n']
    zk = [value11, kValue, '\n']
    ya = [za, zb, zc, zd, ze, zf, zg, zh, zi, zj, zk]
    zzx = sorted(ya, key=itemgetter(0), reverse=False)
    zzz = zzx

    qa = zzx[0]
    qb = zzx[1]
    qc = zzx[2]
    qd = zzx[3]
    qe = zzx[4]
    qf = zzx[5]
    qg = zzx[6]
    qh = zzx[7]
    qi = zzx[8]
    qj = zzx[9]
    qk = zzx[10]

    xa = qa[-2]
    xb = qb[-2]
    xc = qc[-2]
    xd = qd[-2]
    xe = qe[-2]
    xf = qf[-2]
    xg = qg[-2]
    xh = qh[-2]
    xi = qi[-2]
    xj = qj[-2]
    xk = qk[-2]

    sa = xa
    sb = xb
    sc = xc
    sd = xd
    se = xe
    sf = xf
    sg = xg
    sh = xh
    si = xi
    sj = xj
    sk = xk

    sa.config(bg="#000000")
    sa.grid(row=12, column=2)
    sb.config(bg="#000000")
    sb.grid(row=13, column=2)
    sc.config(bg="#000000")
    sc.grid(row=14, column=2)
    sd.config(bg="#000000")
    sd.grid(row=15, column=2)
    se.config(bg="#000000")
    se.grid(row=16, column=2)
    sf.config(bg="#000000")
    sf.grid(row=17, column=2)
    sg.config(bg="#000000")
    sg.grid(row=18, column=2)
    sh.config(bg="#000000")
    sh.grid(row=19, column=2)
    si.config(bg="#000000")
    si.grid(row=20, column=2)
    sj.config(bg="#000000")
    sj.grid(row=21, column=2)
    sk.config(bg="#000000")
    sk.grid(row=22, column=2)

    return

def nFunction():
    
    global sa, sb, sc, sd, se, sf, sg, sh, si, sj, sk
   
    value1 = str(random.randint(0, 11))
    value2 = str(random.randint(0, 11))
    value3 = str(random.randint(0, 11))
    value4 = str(random.randint(0, 11))
    value5 = str(random.randint(0, 11))
    value6 = str(random.randint(0, 11))
    value7 = str(random.randint(0, 11))
    value8 = str(random.randint(0, 11))
    value9 = str(random.randint(0, 11))
    value10 = str(random.randint(0, 11))
    value11 = str(random.randint(0, 11))

    image1 = PhotoImage(file="0001.GIF", format="GIF")

    image2 = PhotoImage(file="0002.GIF", format="GIF")

    image3 = PhotoImage(file="0003.GIF", format="GIF")

    image4 = PhotoImage(file="0004.GIF", format="GIF")

    image5 = PhotoImage(file="0005.GIF", format="GIF")

    image6 = PhotoImage(file="0006.GIF", format="GIF")

    image7 = PhotoImage(file="0007.GIF", format="GIF")

    image8 = PhotoImage(file="0008.GIF", format="GIF")

    image9 = PhotoImage(file="0009.GIF", format="GIF")

    image10 = PhotoImage(file="0010.GIF", format="GIF")

    image11 = PhotoImage(file="0011.GIF", format="GIF")


    aValue = image1
    aValue = Label(App, image=image1)
    aValue.image1 = image1
    bValue = image2
    bValue = Label(App, image=image2)
    bValue.image2 = image2
    cValue = image3
    cValue = Label(App, image=image3)
    cValue.image3 = image3
    dValue = image4
    dValue = Label(App, image=image4)
    dValue.image4 = image4
    eValue = image5
    eValue = Label(App, image=image5)
    eValue.image5 = image5
    fValue = image6
    fValue = Label(App, image=image6)
    fValue.image6 = image6
    gValue = image7
    gValue = Label(App, image=image7)
    gValue.image7 = image7
    hValue = image8
    hValue = Label(App, image=image8)
    hValue.image8 = image8
    iValue = image9
    iValue = Label(App, image=image9)
    iValue.image9 = image9
    jValue = image10
    jValue = Label(App, image=image10)
    jValue.image10 = image10
    kValue = image11
    kValue = Label(App, image=image11)
    kValue.image11 = image11

    za = []
    zb = []
    zc = []
    zd = []
    ze = []
    zf = []
    zg = []
    zh = []
    zi = []
    zj = []
    zk = []

    za = [value1, aValue, '\n']
    zb = [value2, bValue, '\n']
    zc = [value3, cValue, '\n']
    zd = [value4, dValue, '\n']
    ze = [value5, eValue, '\n']
    zf = [value6, fValue, '\n']
    zg = [value7, gValue, '\n']
    zh = [value8, hValue, '\n']
    zi = [value9, iValue, '\n']
    zj = [value10, jValue, '\n']
    zk = [value11, kValue, '\n']
    ya = [za, zb, zc, zd, ze, zf, zg, zh, zi, zj, zk]
    zzx = sorted(ya, key=itemgetter(0), reverse=False)
    zzz = zzx

    qa = zzx[0]
    qb = zzx[1]
    qc = zzx[2]
    qd = zzx[3]
    qe = zzx[4]
    qf = zzx[5]
    qg = zzx[6]
    qh = zzx[7]
    qi = zzx[8]
    qj = zzx[9]
    qk = zzx[10]

    xa = qa[-2]
    xb = qb[-2]
    xc = qc[-2]
    xd = qd[-2]
    xe = qe[-2]
    xf = qf[-2]
    xg = qg[-2]
    xh = qh[-2]
    xi = qi[-2]
    xj = qj[-2]
    xk = qk[-2]

    sa = xa
    sb = xb
    sc = xc
    sd = xd
    se = xe
    sf = xf
    sg = xg
    sh = xh
    si = xi
    sj = xj
    sk = xk

    sa.config(bg="#000000")
    sa.grid(row=12, column=2)
    sb.config(bg="#000000")
    sb.grid(row=13, column=2)
    sc.config(bg="#000000")
    sc.grid(row=14, column=2)
    sd.config(bg="#000000")
    sd.grid(row=15, column=2)
    se.config(bg="#000000")
    se.grid(row=16, column=2)
    sf.config(bg="#000000")
    sf.grid(row=17, column=2)
    sg.config(bg="#000000")
    sg.grid(row=18, column=2)
    sh.config(bg="#000000")
    sh.grid(row=19, column=2)
    si.config(bg="#000000")
    si.grid(row=20, column=2)
    sj.config(bg="#000000")
    sj.grid(row=21, column=2)
    sk.config(bg="#000000")
    sk.grid(row=22, column=2)

    return

def oFunction():

    global sa, sb, sc, sd, se, sf, sg, sh, si, sj, sk
   
    value1 = str(random.randint(0, 11))
    value2 = str(random.randint(0, 11))
    value3 = str(random.randint(0, 11))
    value4 = str(random.randint(0, 11))
    value5 = str(random.randint(0, 11))
    value6 = str(random.randint(0, 11))
    value7 = str(random.randint(0, 11))
    value8 = str(random.randint(0, 11))
    value9 = str(random.randint(0, 11))
    value10 = str(random.randint(0, 11))
    value11 = str(random.randint(0, 11))

    image1 = PhotoImage(file="0001.GIF", format="GIF")

    image2 = PhotoImage(file="0002.GIF", format="GIF")

    image3 = PhotoImage(file="0003.GIF", format="GIF")

    image4 = PhotoImage(file="0004.GIF", format="GIF")

    image5 = PhotoImage(file="0005.GIF", format="GIF")

    image6 = PhotoImage(file="0006.GIF", format="GIF")

    image7 = PhotoImage(file="0007.GIF", format="GIF")

    image8 = PhotoImage(file="0008.GIF", format="GIF")

    image9 = PhotoImage(file="0009.GIF", format="GIF")

    image10 = PhotoImage(file="0010.GIF", format="GIF")

    image11 = PhotoImage(file="0011.GIF", format="GIF")


    aValue = image1
    aValue = Label(App, image=image1)
    aValue.image1 = image1
    bValue = image2
    bValue = Label(App, image=image2)
    bValue.image2 = image2
    cValue = image3
    cValue = Label(App, image=image3)
    cValue.image3 = image3
    dValue = image4
    dValue = Label(App, image=image4)
    dValue.image4 = image4
    eValue = image5
    eValue = Label(App, image=image5)
    eValue.image5 = image5
    fValue = image6
    fValue = Label(App, image=image6)
    fValue.image6 = image6
    gValue = image7
    gValue = Label(App, image=image7)
    gValue.image7 = image7
    hValue = image8
    hValue = Label(App, image=image8)
    hValue.image8 = image8
    iValue = image9
    iValue = Label(App, image=image9)
    iValue.image9 = image9
    jValue = image10
    jValue = Label(App, image=image10)
    jValue.image10 = image10
    kValue = image11
    kValue = Label(App, image=image11)
    kValue.image11 = image11

    za = []
    zb = []
    zc = []
    zd = []
    ze = []
    zf = []
    zg = []
    zh = []
    zi = []
    zj = []
    zk = []

    za = [value1, aValue, '\n']
    zb = [value2, bValue, '\n']
    zc = [value3, cValue, '\n']
    zd = [value4, dValue, '\n']
    ze = [value5, eValue, '\n']
    zf = [value6, fValue, '\n']
    zg = [value7, gValue, '\n']
    zh = [value8, hValue, '\n']
    zi = [value9, iValue, '\n']
    zj = [value10, jValue, '\n']
    zk = [value11, kValue, '\n']
    ya = [za, zb, zc, zd, ze, zf, zg, zh, zi, zj, zk]
    zzx = sorted(ya, key=itemgetter(0), reverse=False)
    zzz = zzx

    qa = zzx[0]
    qb = zzx[1]
    qc = zzx[2]
    qd = zzx[3]
    qe = zzx[4]
    qf = zzx[5]
    qg = zzx[6]
    qh = zzx[7]
    qi = zzx[8]
    qj = zzx[9]
    qk = zzx[10]

    xa = qa[-2]
    xb = qb[-2]
    xc = qc[-2]
    xd = qd[-2]
    xe = qe[-2]
    xf = qf[-2]
    xg = qg[-2]
    xh = qh[-2]
    xi = qi[-2]
    xj = qj[-2]
    xk = qk[-2]

    sa = xa
    sb = xb
    sc = xc
    sd = xd
    se = xe
    sf = xf
    sg = xg
    sh = xh
    si = xi
    sj = xj
    sk = xk

    sa.config(bg="#000000")
    sa.grid(row=12, column=3)
    sb.config(bg="#000000")
    sb.grid(row=13, column=3)
    sc.config(bg="#000000")
    sc.grid(row=14, column=3)
    sd.config(bg="#000000")
    sd.grid(row=15, column=3)
    se.config(bg="#000000")
    se.grid(row=16, column=3)
    sf.config(bg="#000000")
    sf.grid(row=17, column=3)
    sg.config(bg="#000000")
    sg.grid(row=18, column=3)
    sh.config(bg="#000000")
    sh.grid(row=19, column=3)
    si.config(bg="#000000")
    si.grid(row=20, column=3)
    sj.config(bg="#000000")
    sj.grid(row=21, column=3)
    sk.config(bg="#000000")
    sk.grid(row=22, column=3)

    return

def pFunction():
    
    global sa, sb, sc, sd, se, sf, sg, sh, si, sj, sk
   
    value1 = str(random.randint(0, 11))
    value2 = str(random.randint(0, 11))
    value3 = str(random.randint(0, 11))
    value4 = str(random.randint(0, 11))
    value5 = str(random.randint(0, 11))
    value6 = str(random.randint(0, 11))
    value7 = str(random.randint(0, 11))
    value8 = str(random.randint(0, 11))
    value9 = str(random.randint(0, 11))
    value10 = str(random.randint(0, 11))
    value11 = str(random.randint(0, 11))

    image1 = PhotoImage(file="0001.GIF", format="GIF")

    image2 = PhotoImage(file="0002.GIF", format="GIF")

    image3 = PhotoImage(file="0003.GIF", format="GIF")

    image4 = PhotoImage(file="0004.GIF", format="GIF")

    image5 = PhotoImage(file="0005.GIF", format="GIF")

    image6 = PhotoImage(file="0006.GIF", format="GIF")

    image7 = PhotoImage(file="0007.GIF", format="GIF")

    image8 = PhotoImage(file="0008.GIF", format="GIF")

    image9 = PhotoImage(file="0009.GIF", format="GIF")

    image10 = PhotoImage(file="0010.GIF", format="GIF")

    image11 = PhotoImage(file="0011.GIF", format="GIF")


    aValue = image1
    aValue = Label(App, image=image1)
    aValue.image1 = image1
    bValue = image2
    bValue = Label(App, image=image2)
    bValue.image2 = image2
    cValue = image3
    cValue = Label(App, image=image3)
    cValue.image3 = image3
    dValue = image4
    dValue = Label(App, image=image4)
    dValue.image4 = image4
    eValue = image5
    eValue = Label(App, image=image5)
    eValue.image5 = image5
    fValue = image6
    fValue = Label(App, image=image6)
    fValue.image6 = image6
    gValue = image7
    gValue = Label(App, image=image7)
    gValue.image7 = image7
    hValue = image8
    hValue = Label(App, image=image8)
    hValue.image8 = image8
    iValue = image9
    iValue = Label(App, image=image9)
    iValue.image9 = image9
    jValue = image10
    jValue = Label(App, image=image10)
    jValue.image10 = image10
    kValue = image11
    kValue = Label(App, image=image11)
    kValue.image11 = image11

    za = []
    zb = []
    zc = []
    zd = []
    ze = []
    zf = []
    zg = []
    zh = []
    zi = []
    zj = []
    zk = []

    za = [value1, aValue, '\n']
    zb = [value2, bValue, '\n']
    zc = [value3, cValue, '\n']
    zd = [value4, dValue, '\n']
    ze = [value5, eValue, '\n']
    zf = [value6, fValue, '\n']
    zg = [value7, gValue, '\n']
    zh = [value8, hValue, '\n']
    zi = [value9, iValue, '\n']
    zj = [value10, jValue, '\n']
    zk = [value11, kValue, '\n']
    ya = [za, zb, zc, zd, ze, zf, zg, zh, zi, zj, zk]
    zzx = sorted(ya, key=itemgetter(0), reverse=False)
    zzz = zzx

    qa = zzx[0]
    qb = zzx[1]
    qc = zzx[2]
    qd = zzx[3]
    qe = zzx[4]
    qf = zzx[5]
    qg = zzx[6]
    qh = zzx[7]
    qi = zzx[8]
    qj = zzx[9]
    qk = zzx[10]

    xa = qa[-2]
    xb = qb[-2]
    xc = qc[-2]
    xd = qd[-2]
    xe = qe[-2]
    xf = qf[-2]
    xg = qg[-2]
    xh = qh[-2]
    xi = qi[-2]
    xj = qj[-2]
    xk = qk[-2]

    sa = xa
    sb = xb
    sc = xc
    sd = xd
    se = xe
    sf = xf
    sg = xg
    sh = xh
    si = xi
    sj = xj
    sk = xk

    sa.config(bg="#000000")
    sa.grid(row=12, column=3)
    sb.config(bg="#000000")
    sb.grid(row=13, column=3)
    sc.config(bg="#000000")
    sc.grid(row=14, column=3)
    sd.config(bg="#000000")
    sd.grid(row=15, column=3)
    se.config(bg="#000000")
    se.grid(row=16, column=3)
    sf.config(bg="#000000")
    sf.grid(row=17, column=3)
    sg.config(bg="#000000")
    sg.grid(row=18, column=3)
    sh.config(bg="#000000")
    sh.grid(row=19, column=3)
    si.config(bg="#000000")
    si.grid(row=20, column=3)
    sj.config(bg="#000000")
    sj.grid(row=21, column=3)
    sk.config(bg="#000000")
    sk.grid(row=22, column=3)

    return

App = Tk()
App.config(bg="#000000")

def thisFunction():
    aFunction()
    cFunction()
    eFunction()
    gFunction()
    iFunction()
    kFunction()
    mFunction()
    oFunction()

updateB_text = Button(App, command=thisFunction, text="REARRANGE")
updateB_text.grid(row=0, column=0)

bFunction()
dFunction()
fFunction()
hFunction()
jFunction()
lFunction()
nFunction()
pFunction()

App.mainloop()
