setTimeout(mySnd01(), 250);

function mySnd01() {

var msc13 = '<audio autoplay>' + '<source src="sound.mp3" type="audio/mpeg">' + '</audio>';
document.getElementById('snd').innerHTML = msc13;
}