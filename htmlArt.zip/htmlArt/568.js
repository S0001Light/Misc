function myImg01() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9];
    document.getElementById("ImgL1").innerHTML = getImg1.sort();
}

function myImg02() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';

var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9];
    document.getElementById("ImgL2").innerHTML = getImg1.sort();
}

function myImg03() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';

var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9];
    document.getElementById("ImgL3").innerHTML = getImg1.sort();
}

function myImg04() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';

var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9];
    document.getElementById("ImgL4").innerHTML = getImg1.sort();
}

function myImg05() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';

var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9];
    document.getElementById("ImgL5").innerHTML = getImg1.sort();
}

function myImg06() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';

var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9];
    document.getElementById("ImgL6").innerHTML = getImg1.sort();
}

function myImg07() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';

var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9];
    document.getElementById("ImgL7").innerHTML = getImg1.sort();
}

function myImg08() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';

var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9];
    document.getElementById("ImgL8").innerHTML = getImg1.sort();
}

function myImg09() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';

var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9];
    document.getElementById("ImgL9").innerHTML = getImg1.sort();
}

function myImg010() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';

var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9];
    document.getElementById("ImgL10").innerHTML = getImg1.sort();
}

function myImg011() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';

var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9];
    document.getElementById("ImgL11").innerHTML = getImg1.sort();
}

function myImg012() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';

var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9];
    document.getElementById("ImgL12").innerHTML = getImg1.sort();
}

function myImg013() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';

var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9];
    document.getElementById("ImgL13").innerHTML = getImg1.sort();
}

function myImg014() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';

var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9];
    document.getElementById("ImgL14").innerHTML = getImg1.sort();
}

function myImg015() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';

var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9];
    document.getElementById("ImgL15").innerHTML = getImg1.sort();
}

function myImg016() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';

var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9];
    document.getElementById("ImgL16").innerHTML = getImg1.sort();
}

function myImg017() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';

var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9];
    document.getElementById("ImgL17").innerHTML = getImg1.sort();
}

function myImg018() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';

var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9];
    document.getElementById("ImgL18").innerHTML = getImg1.sort();
}

function myImg019() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';

var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9];
    document.getElementById("ImgL19").innerHTML = getImg1.sort();
}

function myImg020() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';

var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9];
    document.getElementById("ImgL20").innerHTML = getImg1.sort();
}

function myImg021() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';

var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9];
    document.getElementById("ImgL21").innerHTML = getImg1.sort();
}

function myImg022() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';

var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9];
    document.getElementById("ImgL22").innerHTML = getImg1.sort();
}

function myImg023() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';

var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9];
    document.getElementById("ImgL23").innerHTML = getImg1.sort();
}

function myImg024() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';

var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9];
    document.getElementById("ImgL24").innerHTML = getImg1.sort();
}

function myImg025() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';

var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9];
    document.getElementById("ImgL25").innerHTML = getImg1.sort();
}

function myImg026() {

var numRand1 = Math.floor((Math.random() * 10) + 1);
var numRand2 = Math.floor((Math.random() * 10) + 1);
var numRand3 = Math.floor((Math.random() * 10) + 1);
var numRand4 = Math.floor((Math.random() * 10) + 1);
var numRand5 = Math.floor((Math.random() * 10) + 1);
var numRand6 = Math.floor((Math.random() * 10) + 1);
var numRand7 = Math.floor((Math.random() * 10) + 1);
var numRand8 = Math.floor((Math.random() * 10) + 1);
var numRand9 = Math.floor((Math.random() * 10) + 1);

var ig1 = document.getElementById("az2").src;
var ig2 = document.getElementById("bz2").src;

var image1 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand1 + '</p>' + '<img src="' + ig2 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image2 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand2 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image3 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand3 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image4 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand4 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image5 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand5 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image6 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand6 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image7 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand7 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image8 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand8 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';
var image9 = '</p>' + '<p style="visibility:hidden;margin:-11px 0px;">' + numRand9 + '</p>' + '<img src="' + ig1 + '">' + '<p style="visibility:hidden;margin:-11px 0px;">';

var getImg1 = [image1, image2, image3, image4, image5, image6, image7, image8, image9];
    document.getElementById("ImgL26").innerHTML = getImg1.sort();
}

function aRefresh() {
    location.reload();
}