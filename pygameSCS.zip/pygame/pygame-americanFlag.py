import pygame
from pygame.locals import *
import datetime
from sys import exit
from random import randint

pygame.init()
screen = pygame.display.set_mode((402,262), 0, 32)

while True:
    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()
            exit()
        word = 'americanFlag/USA_Flag_'
        dthm = datetime.datetime.now()
        m = str(dthm.strftime('%m'))
        day = str(dthm.strftime('%d'))
        y = str(dthm.strftime('%Y'))
        h = str(dthm.strftime('%I'))
        mins = str(dthm.strftime('%M'))
        amPm = str(dthm.strftime('%p'))
        sec = str(dthm.strftime('%S'))
        dash = '-'
        d = str(m + dash + day + dash + y + dash + h + dash + mins + dash + sec + dash + amPm)
        zS = word + d + ".bmp"
        getImage = screen
        aL = 0
        if aL in range(0, 10):
            e = int(randint(0, 11))
            rand_color3 = (e, randint(0, 105), randint(20,200))
            a = 1
            for a in range(-1, 400):
                a += 1
                pos_1 = a
                b = 1
                for b in range(-150, 150):
                    b += 1
                    c = (a, b)
                    screen.set_at(c,rand_color3)
            rand_color5 = (randint(50, 211), randint(0, 1), randint(20,40))
            a = 1
            for a in range(-1, 400):
                a += 1
                pos_1 = a
                b = 1
                for b in range(-260, 260):
                    b += 1
                    c = (a, b)
                    screen.set_at(c,rand_color5)
            rand_color4 = (randint(240, 250), randint(240, 250), randint(240,250))
            rand_color5 = (randint(50, 211), randint(0, 1), randint(20,40))
            a = 1
            for a in range(-1, 400):
                a += 1
                pos_1 = a
                b = 1
                for b in range(-240, 240):
                    b += 1
                    c = (a, b)
                    screen.set_at(c,rand_color4)
            a = 1
            for a in range(-1, 400):
                a += 1
                pos_1 = a
                b = 1
                for b in range(-220, 220):
                    b += 1
                    c = (a, b)
                    screen.set_at(c,rand_color5)
                            

            rand_color4 = (randint(240, 250), randint(240, 250), randint(240,250))
            rand_color5 = (randint(50, 211), randint(0, 1), randint(20,40))
            a = 1
            for a in range(-1, 400):
                a += 1
                pos_1 = a
                b = 1
                for b in range(-200, 200):
                    b += 1
                    c = (a, b)
                    screen.set_at(c,rand_color4)
            a = 1
            for a in range(-1, 400):
                a += 1
                pos_1 = a
                b = 1
                for b in range(-180, 180):
                    b += 1
                    c = (a, b)
                    screen.set_at(c,rand_color5)
            rand_color4 = (randint(240, 250), randint(240, 250), randint(240,250))
            rand_color5 = (randint(50, 211), randint(0, 1), randint(20,40))
            a = 1
            for a in range(-1, 400):
                a += 1
                pos_1 = a
                b = 1
                for b in range(-160, 160):
                    b += 1
                    c = (a, b)
                    screen.set_at(c,rand_color4)
            a = 1
            for a in range(-1, 400):
                a += 1
                pos_1 = a
                b = 1
                for b in range(-140, 140):
                    b += 1
                    c = (a, b)
                    screen.set_at(c,rand_color5)
            rand_color4 = (randint(240, 250), randint(240, 250), randint(240,250))
            rand_color5 = (randint(50, 211), randint(0, 1), randint(20,40))
            a = 1
            for a in range(-1, 400):
                a += 1
                pos_1 = a
                b = 1
                for b in range(-120, 120):
                    b += 1
                    c = (a, b)
                    screen.set_at(c,rand_color4)
            a = 1
            for a in range(-1, 400):
                a += 1
                pos_1 = a
                b = 1
                for b in range(-100, 100):
                    b += 1
                    c = (a, b)
                    screen.set_at(c,rand_color5)
            rand_color4 = (randint(240, 250), randint(240, 250), randint(240,250))
            rand_color5 = (randint(50, 211), randint(0, 1), randint(20,40))
            a = 1
            for a in range(-1, 400):
                a += 1
                pos_1 = a
                b = 1
                for b in range(-80, 80):
                    b += 1
                    c = (a, b)
                    screen.set_at(c,rand_color4)
            a = 1
            for a in range(-1, 400):
                a += 1
                pos_1 = a
                b = 1
                for b in range(-60, 60):
                    b += 1
                    c = (a, b)
                    screen.set_at(c,rand_color5)
            rand_color4 = (randint(240, 250), randint(240, 250), randint(240,250))
            rand_color5 = (randint(50, 211), randint(0, 1), randint(20,40))
            a = 1
            for a in range(-1, 400):
                a += 1
                pos_1 = a
                b = 1
                for b in range(-40, 40):
                    b += 1
                    c = (a, b)
                    screen.set_at(c,rand_color4)
            a = 1
            for a in range(-1, 400):
                a += 1
                pos_1 = a
                b = 1
                for b in range(-20, 20):
                    b += 1
                    c = (a, b)
                    screen.set_at(c,rand_color5)
            rand_color2 = (randint(0, 11), randint(0, 5), randint(20,200))
            a = 1
            for a in range(-1, 190):
                a += 1
                pos_1 = a
                b = 1
                for b in range(-120, 120):
                    b += 1
                    c = (a, b)
                    screen.set_at(c,rand_color2)
            star_color = (randint(240, 254), randint(240, 254), randint(0, 4))
            a = 1
            for a in range(-1, 190):
                a += 1
                b = 1
                c = (a, b)
                screen.set_at(c,star_color)
            a = 1
            for a in range(-1, 190):
                a += 1
                b = 119
                c = (a, b)
                screen.set_at(c,star_color)
            a = 1
            for a in range(-1, 120):
                a += 1
                b = 1
                c = (b, a)
                screen.set_at(c,star_color)
            a = 1
            for a in range(-1, 120):
                a += 1
                b = 189
                c = (b, a)
                screen.set_at(c,star_color)
            xZ1 = 15, 20
            xZ2 = 33, 20
            xZ3 = 51, 20
            xZ4 = 69, 20
            xZ5 = 87, 20
            xZ6 = 105, 20
            xZ7 = 123, 20
            xZ8 = 141, 20
            xZ9 = 159, 20
            xZ10 = 177, 20
            xZ11 = 15, 40
            xZ12 = 33, 40
            xZ13 = 51, 40
            xZ14 = 69, 40
            xZ15 = 87, 40
            xZ16 = 105, 40
            xZ17 = 123, 40
            xZ18 = 141, 40
            xZ19 = 159, 40
            xZ20 = 177, 40
            xZ21 = 15, 60
            xZ22 = 33, 60
            xZ23 = 51, 60
            xZ24 = 69, 60
            xZ25 = 87, 60
            xZ26 = 105, 60
            xZ27 = 123, 60
            xZ28 = 141, 60
            xZ29 = 159, 60
            xZ30 = 177, 60
            xZ31 = 15, 80
            xZ32 = 33, 80
            xZ33 = 51, 80
            xZ34 = 69, 80
            xZ35 = 87, 80
            xZ36 = 105, 80
            xZ37 = 123, 80
            xZ38 = 141, 80
            xZ39 = 159, 80
            xZ40 = 177, 80
            xZ41 = 15, 100
            xZ42 = 33, 100
            xZ43 = 51, 100
            xZ44 = 69, 100
            xZ45 = 87, 100
            xZ46 = 105, 100
            xZ47 = 123, 100
            xZ48 = 141, 100
            xZ49 = 159, 100
            xZ50 = 177, 100
            
            screen.set_at(xZ1, star_color)
            screen.set_at(xZ2, star_color)
            screen.set_at(xZ3, star_color)
            screen.set_at(xZ4, star_color)
            screen.set_at(xZ5, star_color)
            screen.set_at(xZ6, star_color)
            screen.set_at(xZ7, star_color)
            screen.set_at(xZ8, star_color)
            screen.set_at(xZ9, star_color)
            screen.set_at(xZ10, star_color)
            screen.set_at(xZ11, star_color)
            screen.set_at(xZ12, star_color)
            screen.set_at(xZ13, star_color)
            screen.set_at(xZ14, star_color)
            screen.set_at(xZ15, star_color)
            screen.set_at(xZ16, star_color)
            screen.set_at(xZ17, star_color)
            screen.set_at(xZ18, star_color)
            screen.set_at(xZ19, star_color)
            screen.set_at(xZ20, star_color)
            screen.set_at(xZ21, star_color)
            screen.set_at(xZ22, star_color)
            screen.set_at(xZ23, star_color)
            screen.set_at(xZ24, star_color)
            screen.set_at(xZ25, star_color)
            screen.set_at(xZ26, star_color)
            screen.set_at(xZ27, star_color)
            screen.set_at(xZ28, star_color)
            screen.set_at(xZ29, star_color)
            screen.set_at(xZ30, star_color)
            screen.set_at(xZ31, star_color)
            screen.set_at(xZ32, star_color)
            screen.set_at(xZ33, star_color)
            screen.set_at(xZ34, star_color)
            screen.set_at(xZ35, star_color)
            screen.set_at(xZ36, star_color)
            screen.set_at(xZ37, star_color)
            screen.set_at(xZ38, star_color)
            screen.set_at(xZ39, star_color)
            screen.set_at(xZ40, star_color)
            screen.set_at(xZ41, star_color)
            screen.set_at(xZ42, star_color)
            screen.set_at(xZ43, star_color)
            screen.set_at(xZ44, star_color)
            screen.set_at(xZ45, star_color)
            screen.set_at(xZ46, star_color)
            screen.set_at(xZ47, star_color)
            screen.set_at(xZ48, star_color)
            screen.set_at(xZ49, star_color)
            screen.set_at(xZ50, star_color)
            pygame.image.save(getImage, zS)
            aL = aL + 1
        pygame.display.update()
