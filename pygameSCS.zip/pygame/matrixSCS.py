import pygame
from pygame import *
from pygame.locals import *
import pygame.image
import random
from sys import exit

pygame.init()
screenSize = (320, 240)
screen = pygame.display.set_mode(screenSize, RESIZABLE, 32)
x = 1
y = 1
while True:
    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()
    sd = pygame.Surface((320, 240))
    for x in range(0, 320):
        for y in range(0, 240):
            pygame.draw.aaline(sd, (0,200,255), (x,y),(x,y), blend=1)
            screen.blit(sd, (x,y))
    for x in range(0, 240):
        for y in range(0, 240):
            pygame.draw.aaline(sd, (245,245,245), (x,y),(x,y), blend=1)
            screen.blit(sd, (x,y))
    pygame.draw.aaline(sd, (0,0,0), (1,1),(239,1), blend=1)
    pygame.draw.aaline(sd, (0,0,0), (1,21),(239,21), blend=1)
    pygame.draw.aaline(sd, (0,0,0), (1,239),(239,239), blend=1)
    pygame.draw.aaline(sd, (0,0,0), (1,1),(1,239), blend=1)
    pygame.draw.aaline(sd, (0,0,0), (239,1),(239,239), blend=1)
    for x in range(2, 239):
        for y in range(2, 20):
            pygame.draw.aaline(sd, (0,255,0), (x,y),(x,y), blend=1)
            screen.blit(sd, (x,y))
    pygame.draw.aaline(sd, (255,255,255), (1,1),(1,1), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (1,2),(1,2), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (1,3),(1,3), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (1,4),(1,4), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (1,5),(1,5), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (1,6),(1,6), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (1,7),(1,7), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (1,8),(1,8), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (1,9),(1,9), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (1,10),(1,10), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (1,11),(1,11), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (1,12),(1,12), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (1,13),(1,13), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (1,14),(1,14), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (1,15),(1,15), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (1,16),(1,16), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (1,17),(1,17), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (1,18),(1,18), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (1,19),(1,19), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (1,20),(1,20), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (1,21),(1,21), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (1,22),(1,22), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (1,23),(1,23), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (1,24),(1,24), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (1,25),(1,25), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (2,1),(2,1), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (2,2),(2,2), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (2,3),(2,3), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (2,4),(2,4), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (2,5),(2,5), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (2,6),(2,6), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (2,7),(2,7), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (2,8),(2,8), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (2,9),(2,9), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (2,10),(2,10), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (2,11),(2,11), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (2,12),(2,12), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (2,13),(2,13), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (2,14),(2,14), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (2,15),(2,15), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (2,16),(2,16), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (2,17),(2,17), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (2,18),(2,18), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (2,19),(2,19), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (2,20),(2,20), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (2,21),(2,21), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (2,22),(2,22), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (2,23),(2,23), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (2,24),(2,24), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (2,25),(2,25), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (3,1),(3,1), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (3,2),(3,2), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (3,3),(3,3), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (3,4),(3,4), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (3,5),(3,5), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (3,6),(3,6), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (3,7),(3,7), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (3,8),(3,8), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (3,9),(3,9), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (3,10),(3,10), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (3,11),(3,11), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (3,12),(3,12), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (3,13),(3,13), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (3,14),(3,14), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (3,15),(3,15), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (3,16),(3,16), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (3,17),(3,17), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (3,18),(3,18), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (3,19),(3,19), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (3,20),(3,20), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (3,21),(3,21), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (3,22),(3,22), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (3,23),(3,23), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (3,24),(3,24), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (3,25),(3,25), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (4,1),(4,1), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (4,2),(4,2), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (4,3),(4,3), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (4,4),(4,4), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (4,5),(4,5), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (4,6),(4,6), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (4,7),(4,7), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (4,8),(4,8), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (4,9),(4,9), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (4,10),(4,10), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (4,11),(4,11), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (4,12),(4,12), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (4,13),(4,13), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (4,14),(4,14), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (4,15),(4,15), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (4,16),(4,16), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (4,17),(4,17), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (4,18),(4,18), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (4,19),(4,19), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (4,20),(4,20), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (4,21),(4,21), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (4,22),(4,22), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (4,23),(4,23), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (4,24),(4,24), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (4,25),(4,25), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (5,1),(5,1), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (5,2),(5,2), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (5,3),(5,3), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (5,4),(5,4), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (5,5),(5,5), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (5,6),(5,6), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (5,7),(5,7), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (5,8),(5,8), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (5,9),(5,9), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (5,10),(5,10), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (5,11),(5,11), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (5,12),(5,12), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (5,13),(5,13), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (5,14),(5,14), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (5,15),(5,15), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (5,16),(5,16), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (5,17),(5,17), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (5,18),(5,18), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (5,19),(5,19), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (5,20),(5,20), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (5,21),(5,21), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (5,22),(5,22), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (5,23),(5,23), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (5,24),(5,24), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (5,25),(5,25), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (6,1),(6,1), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (6,2),(6,2), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (6,3),(6,3), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (6,4),(6,4), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (6,5),(6,5), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (6,6),(6,6), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (6,7),(6,7), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (6,8),(6,8), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (6,9),(6,9), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (6,10),(6,10), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (6,11),(6,11), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (6,12),(6,12), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (6,13),(6,13), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (6,14),(6,14), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (6,15),(6,15), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (6,16),(6,16), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (6,17),(6,17), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (6,18),(6,18), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (6,19),(6,19), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (6,20),(6,20), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (6,21),(6,21), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (6,22),(6,22), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (6,23),(6,23), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (6,24),(6,24), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (6,25),(6,25), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (7,1),(7,1), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (7,2),(7,2), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (7,3),(7,3), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (7,4),(7,4), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (7,5),(7,5), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (7,6),(7,6), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (7,7),(7,7), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (7,8),(7,8), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (7,9),(7,9), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (7,10),(7,10), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (7,11),(7,11), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (7,12),(7,12), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (7,13),(7,13), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (7,14),(7,14), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (7,15),(7,15), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (7,16),(7,16), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (7,17),(7,17), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (7,18),(7,18), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (7,19),(7,19), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (7,20),(7,20), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (7,21),(7,21), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (7,22),(7,22), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (7,23),(7,23), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (7,24),(7,24), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (7,25),(7,25), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (8,1),(8,1), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (8,2),(8,2), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (8,3),(8,3), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (8,4),(8,4), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (8,5),(8,5), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (8,6),(8,6), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (8,7),(8,7), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (8,8),(8,8), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (8,9),(8,9), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (8,10),(8,10), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (8,11),(8,11), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (8,12),(8,12), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (8,13),(8,13), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (8,14),(8,14), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (8,15),(8,15), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (8,16),(8,16), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (8,17),(8,17), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (8,18),(8,18), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (8,19),(8,19), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (8,20),(8,20), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (8,21),(8,21), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (8,22),(8,22), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (8,23),(8,23), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (8,24),(8,24), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (8,25),(8,25), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (9,1),(9,1), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (9,2),(9,2), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (9,3),(9,3), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (9,4),(9,4), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (9,5),(9,5), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (9,6),(9,6), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (9,7),(9,7), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (9,8),(9,8), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (9,9),(9,9), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (9,10),(9,10), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (9,11),(9,11), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (9,12),(9,12), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (9,13),(9,13), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (9,14),(9,14), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (9,15),(9,15), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (9,16),(9,16), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (9,17),(9,17), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (9,18),(9,18), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (9,19),(9,19), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (9,20),(9,20), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (9,21),(9,21), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (9,22),(9,22), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (9,23),(9,23), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (9,24),(9,24), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (9,25),(9,25), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (10,1),(10,1), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (10,2),(10,2), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (10,3),(10,3), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (10,4),(10,4), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (10,5),(10,5), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (10,6),(10,6), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (10,7),(10,7), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (10,8),(10,8), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (10,9),(10,9), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (10,10),(10,10), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (10,11),(10,11), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (10,12),(10,12), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (10,13),(10,13), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (10,14),(10,14), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (10,15),(10,15), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (10,16),(10,16), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (10,17),(10,17), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (10,18),(10,18), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (10,19),(10,19), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (10,20),(10,20), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (10,21),(10,21), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (10,22),(10,22), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (10,23),(10,23), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (10,24),(10,24), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (10,25),(10,25), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (11,1),(11,1), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (11,2),(11,2), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (11,3),(11,3), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (11,4),(11,4), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (11,5),(11,5), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (11,6),(11,6), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (11,7),(11,7), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (11,8),(11,8), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (11,9),(11,9), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (11,10),(11,10), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (11,11),(11,11), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (11,12),(11,12), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (11,13),(11,13), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (11,14),(11,14), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (11,15),(11,15), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (11,16),(11,16), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (11,17),(11,17), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (11,18),(11,18), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (11,19),(11,19), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (11,20),(11,20), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (11,21),(11,21), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (11,22),(11,22), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (11,23),(11,23), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (11,24),(11,24), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (11,25),(11,25), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (12,1),(12,1), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (12,2),(12,2), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (12,3),(12,3), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (12,4),(12,4), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (12,5),(12,5), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (12,6),(12,6), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (12,7),(12,7), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (12,8),(12,8), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (12,9),(12,9), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (12,10),(12,10), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (12,11),(12,11), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (12,12),(12,12), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (12,13),(12,13), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (12,14),(12,14), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (12,15),(12,15), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (12,16),(12,16), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (12,17),(12,17), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (12,18),(12,18), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (12,19),(12,19), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (12,20),(12,20), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (12,21),(12,21), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (12,22),(12,22), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (12,23),(12,23), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (12,24),(12,24), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (12,25),(12,25), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (13,1),(13,1), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (13,2),(13,2), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (13,3),(13,3), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (13,4),(13,4), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (13,5),(13,5), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (13,6),(13,6), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (13,7),(13,7), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (13,8),(13,8), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (13,9),(13,9), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (13,10),(13,10), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (13,11),(13,11), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (13,12),(13,12), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (13,13),(13,13), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (13,14),(13,14), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (13,15),(13,15), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (13,16),(13,16), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (13,17),(13,17), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (13,18),(13,18), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (13,19),(13,19), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (13,20),(13,20), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (13,21),(13,21), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (13,22),(13,22), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (13,23),(13,23), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (13,24),(13,24), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (13,25),(13,25), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (14,1),(14,1), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (14,2),(14,2), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (14,3),(14,3), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (14,4),(14,4), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (14,5),(14,5), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (14,6),(14,6), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (14,7),(14,7), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (14,8),(14,8), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (14,9),(14,9), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (14,10),(14,10), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (14,11),(14,11), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (14,12),(14,12), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (14,13),(14,13), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (14,14),(14,14), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (14,15),(14,15), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (14,16),(14,16), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (14,17),(14,17), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (14,18),(14,18), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (14,19),(14,19), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (14,20),(14,20), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (14,21),(14,21), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (14,22),(14,22), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (14,23),(14,23), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (14,24),(14,24), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (14,25),(14,25), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (15,1),(15,1), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (15,2),(15,2), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (15,3),(15,3), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (15,4),(15,4), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (15,5),(15,5), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (15,6),(15,6), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (15,7),(15,7), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (15,8),(15,8), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (15,9),(15,9), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (15,10),(15,10), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (15,11),(15,11), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (15,12),(15,12), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (15,13),(15,13), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (15,14),(15,14), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (15,15),(15,15), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (15,16),(15,16), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (15,17),(15,17), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (15,18),(15,18), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (15,19),(15,19), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (15,20),(15,20), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (15,21),(15,21), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (15,22),(15,22), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (15,23),(15,23), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (15,24),(15,24), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (15,25),(15,25), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (16,1),(16,1), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (16,2),(16,2), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (16,3),(16,3), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (16,4),(16,4), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (16,5),(16,5), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (16,6),(16,6), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (16,7),(16,7), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (16,8),(16,8), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (16,9),(16,9), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (16,10),(16,10), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (16,11),(16,11), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (16,12),(16,12), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (16,13),(16,13), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (16,14),(16,14), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (16,15),(16,15), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (16,16),(16,16), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (16,17),(16,17), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (16,18),(16,18), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (16,19),(16,19), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (16,20),(16,20), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (16,21),(16,21), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (16,22),(16,22), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (16,23),(16,23), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (16,24),(16,24), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (16,25),(16,25), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (17,1),(17,1), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (17,2),(17,2), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (17,3),(17,3), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (17,4),(17,4), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (17,5),(17,5), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (17,6),(17,6), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (17,7),(17,7), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (17,8),(17,8), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (17,9),(17,9), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (17,10),(17,10), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (17,11),(17,11), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (17,12),(17,12), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (17,13),(17,13), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (17,14),(17,14), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (17,15),(17,15), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (17,16),(17,16), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (17,17),(17,17), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (17,18),(17,18), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (17,19),(17,19), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (17,20),(17,20), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (17,21),(17,21), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (17,22),(17,22), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (17,23),(17,23), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (17,24),(17,24), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (17,25),(17,25), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (18,1),(18,1), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (18,2),(18,2), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (18,3),(18,3), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (18,4),(18,4), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (18,5),(18,5), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (18,6),(18,6), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (18,7),(18,7), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (18,8),(18,8), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (18,9),(18,9), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (18,10),(18,10), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (18,11),(18,11), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (18,12),(18,12), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (18,13),(18,13), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (18,14),(18,14), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (18,15),(18,15), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (18,16),(18,16), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (18,17),(18,17), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (18,18),(18,18), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (18,19),(18,19), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (18,20),(18,20), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (18,21),(18,21), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (18,22),(18,22), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (18,23),(18,23), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (18,24),(18,24), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (18,25),(18,25), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (19,1),(19,1), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (19,2),(19,2), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (19,3),(19,3), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (19,4),(19,4), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (19,5),(19,5), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (19,6),(19,6), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (19,7),(19,7), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (19,8),(19,8), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (19,9),(19,9), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (19,10),(19,10), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (19,11),(19,11), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (19,12),(19,12), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (19,13),(19,13), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (19,14),(19,14), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (19,15),(19,15), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (19,16),(19,16), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (19,17),(19,17), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (19,18),(19,18), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (19,19),(19,19), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (19,20),(19,20), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (19,21),(19,21), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (19,22),(19,22), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (19,23),(19,23), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (19,24),(19,24), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (19,25),(19,25), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (20,1),(20,1), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (20,2),(20,2), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (20,3),(20,3), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (20,4),(20,4), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (20,5),(20,5), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (20,6),(20,6), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (20,7),(20,7), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (20,8),(20,8), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (20,9),(20,9), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (20,10),(20,10), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (20,11),(20,11), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (20,12),(20,12), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (20,13),(20,13), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (20,14),(20,14), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (20,15),(20,15), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (20,16),(20,16), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (20,17),(20,17), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (20,18),(20,18), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (20,19),(20,19), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (20,20),(20,20), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (20,21),(20,21), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (20,22),(20,22), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (20,23),(20,23), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (20,24),(20,24), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (20,25),(20,25), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (20,1),(20,1), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (20,2),(20,2), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (20,3),(20,3), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (20,4),(20,4), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (20,5),(20,5), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (21,6),(21,6), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (21,7),(21,7), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (21,8),(21,8), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (21,9),(21,9), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (21,10),(21,10), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (21,11),(21,11), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (21,12),(21,12), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (21,13),(21,13), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (21,14),(21,14), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (21,15),(21,15), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (21,16),(21,16), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (21,17),(21,17), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (21,18),(21,18), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (21,19),(21,19), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (21,20),(21,20), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (21,21),(21,21), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (21,22),(21,22), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (21,23),(21,23), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (21,24),(21,24), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (21,25),(21,25), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (21,1),(21,1), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (21,2),(21,2), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (21,3),(21,3), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (21,4),(21,4), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (21,5),(21,5), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (22,6),(22,6), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (22,7),(22,7), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (22,8),(22,8), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (22,9),(22,9), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (22,10),(22,10), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (22,11),(22,11), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (22,12),(22,12), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (22,13),(22,13), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (22,14),(22,14), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (22,15),(22,15), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (22,16),(22,16), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (22,17),(22,17), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (22,18),(22,18), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (22,19),(22,19), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (22,20),(22,20), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (22,21),(22,21), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (22,22),(22,22), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (22,23),(22,23), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (22,24),(22,24), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (22,25),(22,25), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (22,1),(22,1), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (22,2),(22,2), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (22,3),(22,3), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (22,4),(22,4), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (22,5),(22,5), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (23,6),(23,6), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (23,7),(23,7), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (23,8),(23,8), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (23,9),(23,9), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (23,10),(23,10), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (23,11),(23,11), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (23,12),(23,12), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (23,13),(23,13), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (23,14),(23,14), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (23,15),(23,15), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (23,16),(23,16), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (23,17),(23,17), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (23,18),(23,18), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (23,19),(23,19), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (23,20),(23,20), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (23,21),(23,21), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (23,22),(23,22), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (23,23),(23,23), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (23,24),(23,24), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (23,25),(23,25), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (23,1),(23,1), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (23,2),(23,2), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (23,3),(23,3), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (23,4),(23,4), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (23,5),(23,5), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (24,6),(24,6), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (24,7),(24,7), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (24,8),(24,8), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (24,9),(24,9), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (24,10),(24,10), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (24,11),(24,11), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (24,12),(24,12), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (24,13),(24,13), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (24,14),(24,14), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (24,15),(24,15), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (24,16),(24,16), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (24,17),(24,17), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (24,18),(24,18), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (24,19),(24,19), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (24,20),(24,20), blend=1)


    pygame.draw.aaline(sd, (0,0,0), (24,21),(24,21), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (24,22),(24,22), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (24,23),(24,23), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (24,24),(24,24), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (24,25),(24,25), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (24,1),(24,1), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (24,2),(24,2), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (24,3),(24,3), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (24,4),(24,4), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (24,5),(24,5), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (25,6),(25,6), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (25,7),(25,7), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (25,8),(25,8), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (25,9),(25,9), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (25,10),(25,10), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (25,11),(25,11), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (25,12),(25,12), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (25,13),(25,13), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (25,14),(25,14), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (25,15),(25,15), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (25,16),(25,16), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (25,17),(25,17), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (25,18),(25,18), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (25,19),(25,19), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (25,20),(25,20), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (25,21),(25,21), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (25,22),(25,22), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (25,23),(25,23), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (25,24),(25,24), blend=1)


    pygame.draw.aaline(sd, (255,255,255), (25,25),(25,25), blend=1)
    screen.blit(sd, (1,1))
    pygame.display.update()
