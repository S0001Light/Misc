import random

with open("Page_001.csv", "r") as opn:
    contents = opn.read()
    print(contents)


sector_a = []
sector_b = []

with open("Page_001.csv", "r") as opn2:
    for line in opn2:
        word = line.split(",")
        sector_a.append(word[0].strip())
        sector_b.append(word[1].strip())
print(sector_a)
print(sector_b)
        
def pickArandom():
    aword = random.choice(sector_a)
    mword = random.choice(sector_b)
    diff = "This " + aword + " " + mword
    print(diff)

pickArandom()
